---
title: "finance-act-2025-enacted.pdf"
source_type: official-pdf-plaintext
source_pdf_sha256: "91983a9e58c6a6751ac5b2f19752b08f456a33692d798fd3e03ee10313ed9d36"
conversion: pdftotext-layout
retrieved: 2026-09-25
---

Number 18 of 2025



Finance Act 2025
                                     Number 18 of 2025

                                   FINANCE ACT 2025


                                        CONTENTS


                                           PART 1
          UNIVERSAL SOCIAL CHARGE, INCOME TAX, CORPORATION TAX AND CAPITAL GAINS TAX
                                          CHAPTER 1
                                        Interpretation
Section
    1. Definition (Part 1)
                                          CHAPTER 2
                                  Universal Social Charge
    2. Amendment of section 531AN of Principal Act (rate of charge)
                                          CHAPTER 3
                                         Income Tax
    3. Amendment of section 473B of Principal Act (rent tax credit)
    4. Amendment of section 473C of Principal Act (mortgage interest tax relief)
    5. Amendment of section 477C of Principal Act (Help to Buy)
    6. Amendment of section 204B of Principal Act (exemption in respect of compensation for
          certain living donors)
    7. Amendment of section 208B of Principal Act (charities - miscellaneous)
    8. Amendment of section 235 of Principal Act (bodies established for promotion of athletic
          or amateur games or sports)
    9. Amendment of section 847A of Principal Act (donations to certain sports bodies)
    10. Amendment of section 531AM of Principal Act (charge to universal social charge)
    11. Amendment of section 847AA of Principal Act (deduction for donations to National
          Governing Bodies)
    12. Amendment of section 216D of Principal Act (certain profits of micro-generation of
          electricity)

    13. Amendment of section 216F of Principal Act (exemption of certain profits arising from
          production, maintenance and repair of certain musical instruments)


                                              1
[No. 18.]                             Finance Act 2025.                               [2025.]

   14. Annual returns by qualifying fund managers
   15. Repeal of section 14 of Finance Act 2024
   16. Automatic enrolment retirement savings system
   17. Repeal of section 15 of Finance Act 2024
   18. Automatic enrolment retirement savings system (amendments consequential on
         insertion of Chapter 2E in Part 30)
   19. Amendment of section 128F of Principal Act (key employee engagement programme)
   20. Amendment of Schedule 13 to Principal Act (accountable persons for purposes of
         Chapter 1 of Part 18)
   21. Amendment of section 530A of Principal Act (principal to whom relevant contracts tax
         applies)
   22. Amendment of section 823A of Principal Act (deduction for income earned in certain
         foreign states)
   23. Amendment of section 825C of Principal Act (special assignee relief programme)
   24. Amendment of section 121 of Principal Act (benefit of use of car)
   25. Amendment of section 121A of Principal Act (benefit of use of van)
                                          CHAPTER 4
                    Income Tax, Corporation Tax and Capital Gains Tax
   26. Amendment of section 285A of Principal Act (acceleration of wear and tear allowances
         for certain energy-efficient equipment)
   27. Amendment of section 285C of Principal Act (acceleration of wear and tear allowances
         for gas vehicles and refuelling equipment)
   28. Amendment of section 285D of Principal Act (acceleration of wear and tear allowances
         for farm safety equipment)
   29. Amendment of section 658A of Principal Act (farming: accelerated allowances for
         capital expenditure on slurry storage)
   30. Living City Initiative
   31. Amendment of section 97B of Principal Act (deduction for retrofitting expenditure)
   32. Estimate of tax due
   33. Exemption of certain profits or gains arising from cost rental properties
   34. Amendment of Schedule 4 to Principal Act (Exemption of Specified Non-Commercial
         State Sponsored Bodies from Certain Tax Provisions)
   35. Amendment of Chapter 2 of Part 29 of Principal Act (scientific and certain other
         research)
   36. Taxation of certain foreign body corporates
   37. Life assurance policies and investment funds
   38. Amendment of section 731 of Principal Act (chargeable gains accruing to unit trusts)
   39. Exemption from dividend withholding tax for certain investment limited partnerships
   40. Amendment to section 835AVB of Principal Act (collective investment scheme)



                                              2
[2025.]                               Finance Act 2025.                              [No. 18.]

    41. Amendments relating to group payments
                                          CHAPTER 5
                                       Corporation Tax
    42. Enhanced deduction for eligible construction expenditure
    43. Amendment of section 291A of Principal Act (intangible assets)
    44. Amendment of section 400 of Principal Act (company reconstructions without change
          of ownership)
    45. Amendment of section 481 of Principal Act (relief for investment in films)
    46. Amendment of section 481A of Principal Act (relief for investment in digital games)
    47. Amendment of section 831B of Principal Act (participation exemption for certain
          foreign distributions)
    48. Amendment of section 835AY of Principal Act (interpretation (Part 35D))
    49. Amendment of section 840A of Principal Act (interest on loans to defray money
          applied for certain purposes)
    50. Amendment of section 891H of Principal Act (country-by-country reporting)
                                          CHAPTER 6
                                      Capital Gains Tax
    51. Amendment of section 597AA of Principal Act (revised entrepreneur relief)
    52. Amendment of section 604B of Principal Act (relief for farm restructuring)

                                           PART 2
                                            EXCISE
    53. Amendment of Chapter 1 of Part 2 of Finance Act 1999 (Mineral Oil Tax)
    54. Amendment of section 71 of Finance Act 2010 (reliefs from natural gas carbon tax)
    55. Amendment of section 82 of Finance Act 2010 (reliefs from solid fuel carbon tax)
    56. Amendment of Schedule 2 to Finance Act 2005 (rates of tobacco products tax)
    57. Amendment of section 64 of Finance Act 2002 (interpretation)
    58. Time when duty becomes due
    59. Amendment of section 70 of Finance Act 2002 (returns)
    60. Amendment of section 71 of Finance Act 2002 (payment of duty with bet)
    61. Amendment of section 77 of Finance Act 2002 (regulations for payment of duty on
          bets)
    62. De-registration of bookmaking premises
    63. Repeal of Chapter III of Part II of Finance Act 1992 (Amusement Machine Licence
          Duty)
    64. Amendment of section 68A of Finance Act 2002
    65. Amendment of section 135 of Finance Act 1992 (temporary exemption from
          registration)


                                              3
[No. 18.]                            Finance Act 2025.                                   [2025.]

   66. Amendment of section 135C of Finance Act 1992 (remission or repayment in respect
         of vehicle registration tax, etc.)

                                          PART 3
                                      VALUE-ADDED TAX
   67. Definition (Part 3)
   68. Persons not accountable persons unless they so elect
   69. Amendment of section 46 of Principal Act (reduced rate for electricity and gas)
   70. Amendment of section 46 of, and Schedule 3 to, Principal Act (reduced rate for
         housing as part of a social policy)
   71. Amendment of section 46 of Principal Act (reduced rate for food and drink for human
         consumption and hairdressing services)
   72. Amendment of sections 60 and 120 of, and paragraph 11 of Schedule 3 to, Principal
         Act
   73. Amendment of section 86 of Principal Act (special provisions for tax invoiced by flat-
         rate farmers)
   74. Amendment of section 96 of Principal Act (waiver of exemption under old rules)
   75. Amendments consequential on amendment of section 96 of Principal Act
   76. Amendment of section 115 of Principal Act (penalties generally)
   77. Amendment of paragraph 6(2) of Schedule 1 to Principal Act (financial services)

                                          PART 4
                                        STAMP DUTIES
   78. Definition (Part 4)
   79. Amendment of section 83D of Principal Act (repayment of stamp duty where land used
         for residential development)
   80. Miscellaneous amendments to Principal Act
   81. Land: special provisions
   82. Amendment of Part 7 of Principal Act (Exemptions and Reliefs from Stamp Duty)
   83. Amendment of section 126AB of Principal Act (further levy on certain financial
         institutions)
   84. Levy on authorised insurers
   85. Amendment of section 81AA of Principal Act (transfers to young trained farmers)
   86. Amendment of section 81C of Principal Act (further farm consolidation relief)

                                          PART 5
                                  CAPITAL ACQUISITIONS TAX
   87. Definition (Part 5)
   88. Amendment of section 41 of Principal Act (when interest in assurance policy becomes
         interest in possession)


                                              4
[2025.]                               Finance Act 2025.                               [No. 18.]

    89. Amendment of Chapter 2 of Part 10 of Principal Act (business relief)
    90. Assessment of executors and administrators



                                           PART 6
                                        MISCELLANEOUS
    91. Definition (Part 6)
    92. Implementation of Part I of OECD (2023) International Standards for Automatic
           Exchange of Information in Tax Matters: Crypto-Asset Reporting Framework
    93. Amendment of section 811C of Principal Act (transactions to avoid liability to tax)
    94. Amendment of section 891F of Principal Act (returns of certain information by
          financial institutions)
    95. Amendment of Part 4A of Principal Act (Implementation of Council Directive (EU)
          2022/2523 of 15 December 2022 on ensuring a global minimum level of taxation
          for multinational enterprise groups and large-scale domestic groups in the Union)
    96. Amendment of section 638A of Principal Act (company mergers and divisions)
    97. Amendment of section 851A of Principal Act (confidentiality of taxpayer information)
    98. Amendment of section 869 of Principal Act (delivery, service and evidence of notices
          and forms)
    99. Amendment of section 959AA of Principal Act (chargeable persons: time limit on
          assessment made or amended by Revenue officer)
    100. Amendment of section 959AP of Principal Act (payment of preliminary tax by direct
          debit)
    101. Amendment of section 959AU of Principal Act (date for payment of tax: amended
          assessments)
    102. Amendment of section 959I of Principal Act (obligation to make a return)
    103. Residential zoned land tax
    104. Technical amendments to de minimis aid provisions
    105. Miscellaneous technical amendments in relation to tax
    106. Care and management of taxes and duties
    107. Short title, construction and commencement

                                         SCHEDULE
                    MISCELLANEOUS TECHNICAL AMENDMENTS IN RELATION TO TAX




                                               5
[No. 18.]                             Finance Act 2025.                              [2025.]

                                        ACTS REFERRED TO


 Affordable Housing Act 2021 (No. 25)
 Automatic Enrolment Retirement Savings System Act 2024 (No. 20)
 Betting Act 1931 (No. 27)
 Capital Acquisitions Tax Consolidation Act 2003 (No. 1)
 Companies Act 2014 (No. 38)
 Finance Act 1992 (No. 9)
 Finance Act 1999 (No. 2)
 Finance Act 2002 (No. 5)
 Finance Act 2005 (No. 5)
 Finance Act 2008 (No. 3)
 Finance Act 2010 (No. 5)
 Finance Act 2024 (No. 43)
 Gambling Regulation Act 2024 (No. 35)
 Greyhound Industry Act 1958 (No. 12)
 Housing (Miscellaneous Provisions) Act, 1979 (No. 27)
 Housing Act 1966 (No. 21)
 Human Tissue (Transplantation, Post-Mortem, Anatomical Examination and Public Display) Act
  2024 (No. 5)
 Investment Limited Partnerships Act 1994 (No. 24)
 Irish Horseracing Industry Act 1994 (No. 18)
 Local Government Rates and Other Matters Act 2019 (No. 24)
 Planning and Development Act 2000 (No. 30)
 Planning and Development Act 2024 (No. 34)
 Stamp Duties Consolidation Act 1999 (No. 31)
 Taxes Consolidation Act 1997 (No. 39)
 Valuation Act 2001 (No. 13)
 Value-Added Tax Consolidation Act 2010 (No. 31)




                                                6
                                      Number 18 of 2025

                                    FINANCE ACT 2025


An Act to provide for the imposition, repeal, remission, alteration and regulation of
taxation, of stamp duties and of duties relating to excise and otherwise to make further
provision in connection with finance; and to provide for related matters.
                                                                   [23rd December, 2025]


Be it enacted by the Oireachtas as follows:



                                            PART 1

          UNIVERSAL SOCIAL CHARGE, INCOME TAX, CORPORATION TAX AND CAPITAL GAINS TAX



                                           CHAPTER 1

                                         Interpretation


Definition (Part 1)
1.    In this Part, “Principal Act” means the Taxes Consolidation Act 1997.



                                           CHAPTER 2

                                   Universal Social Charge


Amendment of section 531AN of Principal Act (rate of charge)
2.   (1) Section 531AN of the Principal Act is amended—
         (a) in subsection (3), by the substitution of “€28,700” for “€27,382”,
         (b) in subsection (4), by the substitution of “2028” for “2026”, and
         (c) by the substitution of the following for Part 1 of the Table to that section:




                                                7
PT.1 S.2 [No. 18.]                        Finance Act 2025.                                 [2025.]

                                                     “PART 1

                         Part of aggregate income              Rate of universal social charge
                                    (1)                                      (2)
                             The first €12,012                           0.5 per cent
                             The next €16,688                             2 per cent
                             The next €41,344                             3 per cent
                              The remainder                               8 per cent
                                                                                         ”.
     (2) Subsection (1) applies for the year of assessment 2026 and each subsequent year of
         assessment.

                                              CHAPTER 3

                                             Income Tax


Amendment of section 473B of Principal Act (rent tax credit)
3.    Section 473B of the Principal Act is amended by the substitution of the following
      subsection for subsection (14):
                     “(14) This section shall apply in respect of the years of assessment 2022 to
                           2028 (both years inclusive).”.


Amendment of section 473C of Principal Act (mortgage interest tax relief)
4.    Section 473C of the Principal Act is amended—
          (a) in subsection (1)—
               (i) by the substitution of the following definition for the definition of “qualifying
                   period”:
                          “ ‘qualifying period’ means—
                          (a) for the purposes of subsection (4), the period commencing on
                              1 January 2023 and ending on 31 December 2023,
                          (b) for the purposes of subsection (4A), the period commencing on
                              1 January 2024 and ending on 31 December 2024,
                          (c) for the purposes of subsection (4B), the period commencing on
                              1 January 2025 and ending on 31 December 2025, and
                          (d) for the purposes of subsection (4C), the period commencing on
                              1 January 2026 and ending on 31 December 2026;”,
              (ii) by the substitution of the following definition for the definition of “relievable
                   interest”:
                          “ ‘relievable interest’ has the meaning given to it—


                                                 8
[2025.]                                Finance Act 2025.                         [No. 18.] PT.1 S.4

                        (a) by subsection (4), in the case of the year of assessment 2023,
                        (b) by subsection (4A), in the case of the year of assessment 2024,
                        (c) by subsection (4B), in the case of the year of assessment 2025, and
                        (d) by subsection (4C), in the case of the year of assessment 2026;”,
                  and
             (iii) by the substitution of the following definition for the definition of “upper
                   limit”:
                        “ ‘upper limit’ means—
                        (a) €6,250 for the years of assessment 2023, 2024 and 2025,
                        (b) €3,125 for the year of assessment 2026, or
                        (c) where subsection (5), (5A), (5B) or (5C) apply, the amount determined
                            in accordance with paragraph (a)(i), (a)(ii) or (b), as the case may be,
                            of the subsection concerned.”,
          (b) in subsection (2), by the substitution of “a qualifying period referred to in
              paragraph (a), (b), (c) or (d), as the case may be, of the definition, in
              subsection (1), of that term” for “a qualifying period referred to in paragraph (a)
              or (b), as the case may be, of the definition of that term in subsection (1)”,
          (c) by the insertion of the following subsections after subsection (4A):
                 “(4B) (a) For the purposes of this section, in respect of a claim under
                           subsection (2) for the year of assessment 2025, relievable interest,
                           in relation to an individual, shall be an amount determined by the
                           formula—

                                                          A–B

                            where—
                            A    is the amount of qualifying interest for the year of assessment
                                 2025, and
                            B    is the amount of qualifying interest for the year of assessment
                                 2022.

                        (b) Where qualifying interest paid for a year of assessment referred to
                            in paragraph (a) is for a period where the number of days in the
                            years of assessment to which ‘A’ and ‘B’ in the formula in
                            paragraph (a) relate are not the same, the amount of qualifying
                            interest represented by ‘A’ or ‘B’, as the case may be, in the
                            formula in paragraph (a) shall—

                            (i) where the number of days in the year of assessment to which ‘A’
                                relates is greater than the number of days in the year of


                                                9
PT.1 S.4 [No. 18.]                         Finance Act 2025.                                 [2025.]

                                  assessment to which ‘B’ relates, be determined by the following
                                  formula—

                                                             A x D/E

                                  and
                             (ii) where the number of days in the year of assessment to which ‘B’
                                  relates is greater than the number of days in the year of
                                  assessment to which ‘A’ relates, be determined by the following
                                  formula—

                                                            B x D/E

                                  where—
                                  D     is the number of days in the year of assessment with the
                                        lesser number of days, and
                                  E     is the number of days in the year of assessment with the
                                        greatest number of days.
                     (4C) (a) For the purposes of this section, in respect of a claim under
                              subsection (2) for the year of assessment 2026, relievable interest,
                              in relation to an individual, shall be an amount determined by the
                              formula—

                                                     (A – B) x 50 per cent

                              where—
                              A       is the amount of qualifying interest for the year of assessment
                                      2026, and
                              B       is the amount of qualifying interest for the year of assessment
                                      2022.
                          (b) Where qualifying interest paid for a year of assessment referred to
                              in paragraph (a) is for a period where the number of days in the
                              years of assessment to which ‘A’ and ‘B’ in the formula in
                              paragraph (a) relate are not the same, the amount of qualifying
                              interest represented by ‘A’ or ‘B’, as the case may be, in the
                              formula in paragraph (a) shall—
                             (i) where the number of days in the year of assessment to which ‘A’
                                 relates is greater than the number of days in the year of
                                 assessment to which ‘B’ relates, be determined by the following
                                 formula—

                                                             A x D/E

                                  and


                                                   10
[2025.]                                Finance Act 2025.                       [No. 18.] PT.1 S.4

                           (ii) where the number of days in the year of assessment to which ‘B’
                                relates is greater than the number of days in the year of
                                assessment to which ‘A’ relates, be determined by the following
                                formula—

                                                         B x D/E

                                 where—
                                 D   is the number of days in the year of assessment with the
                                     lesser number of days, and
                                 E   is the number of days in the year of assessment with the
                                     greatest number of days.”,
          (d) by the insertion of the following subsections after subsection (5A):
                  “(5B) Where, for the year of assessment 2025, qualifying interest referred to
                        in subsection (4B) is for a period of less than 365 days, then—
                        (a) where—
                            (i) the number of days in the year of assessment to which ‘A’ in the
                                formula in subsection (4B) relates is less than 365 and the
                                number of days in the year of assessment to which ‘B’ in the
                                formula in subsection (4B) relates is equal to 365, or
                           (ii) the number of days in the year of assessment to which ‘B’ in the
                                formula in subsection (4B) relates is less than 365 and the
                                number of days in the year of assessment to which ‘A’ in the
                                formula in subsection (4B) relates is equal to 365,
                            the upper limit shall be determined by the formula—

                                                      F x G/H

                            or
                        (b) where the number of days in the year of assessment to which ‘A’ in
                            the formula in subsection (4B) relates is less than 365 and the
                            number of days in the year of assessment to which ‘B’ in the
                            formula in subsection (4B) relates is less than 365, then, the upper
                            limit shall be determined by the formula—

                                                         F x I/J

                            where—

                            F is €6,250,

                            G is the number of days in the year of assessment with the lesser
                              number of days,


                                               11
PT.1 S.4 [No. 18.]                       Finance Act 2025.                               [2025.]

                              H is the number of days in the year of assessment with the greater
                                number of days,
                              I   is the number of days in the year of assessment with the lesser
                                  number of days, and
                              J   is 365 days.
                     (5C) Where, for the year of assessment 2026, qualifying interest referred to
                          in subsection (4C) is for a period of less than 365 days, then—
                         (a) where—
                             (i) the number of days in the year of assessment to which ‘A’ in the
                                 formula in subsection (4C) relates is less than 365 and the
                                 number of days in the year of assessment to which ‘B’ in the
                                 formula in subsection (4C) relates is equal to 365, or
                            (ii) the number of days in the year of assessment to which ‘B’ in the
                                 formula in subsection (4C) relates is less than 365 and the
                                 number of days in the year of assessment to which ‘A’ in the
                                 formula in subsection (4C) relates is equal to 365,
                             the upper limit shall be determined by the formula—

                                                         F x G/H

                             or
                         (b) where the number of days in the year of assessment to which ‘A’ in
                             the formula in subsection (4C) relates is less than 365 and the
                             number of days in the year of assessment to which ‘B’ in the
                             formula in subsection (4C) relates is less than 365, then, the upper
                             limit shall be determined by the formula—

                                                         F x I/J

                             where—
                              F is €3,125,
                              G is the number of days in the year of assessment with the lesser
                                number of days,
                              H is the number of days in the year of assessment with the greater
                                number of days,
                              I   is the number of days in the year of assessment with the lesser
                                  number of days, and
                              J   is 365 days.”,
          (e) in subsection (7)(a), by the substitution of “a qualifying period referred to in
              paragraph (a), (b), (c) or (d), as the case may be, of the definition, in
              subsection (1), of that term” for “a qualifying period referred to in paragraph (a)

                                                   12
[2025.]                                 Finance Act 2025.                        [No. 18.] PT.1 S.4

              or (b), as the case may be, of the definition of that term in subsection (1)”,
          (f) in subsection (8)(a), by the substitution of “the calendar year 2023, 2024, 2025 or
              2026, as the case may be,” for “the calendar year 2023 or 2024, as the case may
              be,”,
          (g) in subsection (9)(b), by the substitution of “subsection (4), (4A), (4B) or (4C), as
              the case may be” for “subsection (4) or (4A), as the case may be”, and
          (h) in subsection (11)(e), by the substitution of the following subparagraphs for
              subparagraphs (i) and (ii):
                           “(i) the qualifying interest paid by the claimant for—
                                (I) the year of assessment 2022,
                               (II) the qualifying period referred to in paragraph (a) of the
                                    definition, in subsection (1), of that term to which the claim
                                    relates,
                              (III) the qualifying period referred to in paragraph (b) of the
                                    definition, in subsection (1), of that term to which the claim
                                    relates,
                              (IV) the qualifying period referred to in paragraph (c) of the
                                   definition, in subsection (1), of that term to which the claim
                                   relates, or
                               (V) the qualifying period referred to in paragraph (d) of the
                                   definition, in subsection (1), of that term to which the claim
                                   relates,
                           (ii) where subsection (9)(b) applies, the total qualifying interest
                                paid by all of the individuals concerned for—
                                (I) the year of assessment 2022,
                               (II) the qualifying period referred to in paragraph (a) of the
                                    definition, in subsection (1), of that term to which the claim
                                    relates,
                              (III) the qualifying period referred to in paragraph (b) of the
                                    definition, in subsection (1), of that term to which the claim
                                    relates,
                              (IV) the qualifying period referred to in paragraph (c) of the
                                   definition, in subsection (1), of that term to which the claim
                                   relates, or
                               (V) the qualifying period referred to in paragraph (d) of the
                                   definition, in subsection (1), of that term to which the claim
                                   relates, and”.




                                                13
PT.1 [No. 18.]                         Finance Act 2025.                                  [2025.]

Amendment of section 477C of Principal Act (Help to Buy)
5.    Section 477C of the Principal Act is amended, with effect as on and from 26 November
      2025, in subparagraph (ii) of the definition in subsection (1) of “qualifying residence”,
      by the substitution of “paragraph (c) or (cac), as the case may be, of section 46(1)” for
      “section 46(1)(c)”.


Amendment of section 204B of Principal Act (exemption in respect of compensation for
certain living donors)
6.    Section 204B of the Principal Act is amended by the substitution of “subsections (3) and
      (4) of section 12 of the Human Tissue (Transplantation, Post-Mortem, Anatomical
      Examination and Public Display) Act 2024” for “Regulation 21(2) of the European
      Union (Quality and Safety of Human Organs Intended for Transplantation) Regulations
      2012 (S.I. No. 325 of 2012)”.


Amendment of section 208B of Principal Act (charities - miscellaneous)
7.    Section 208B of the Principal Act is amended by the insertion of the following
      subsection after subsection (3):
                 “(3A) (a) An exemption under section 207 or 208, as the case may be, shall
                           apply from the date of the notice of the determination under
                           section 864, on a claim under section 207 or 208, granting the
                           exemption.
                        (b) An exemption under section 208A shall apply from the date of the
                            notice of the determination under that section granting the
                            exemption.”.


Amendment of section 235 of Principal Act (bodies established for promotion of athletic
or amateur games or sports)
8.    Section 235(2) of the Principal Act is amended by the insertion of “, and the exemption
      shall apply from the date of the notice of the determination under section 864 on a claim,
      under this section, granting the exemption” after “subsection (1)(a)”.


Amendment of section 847A of Principal Act (donations to certain sports bodies)
9.    Section 847A of the Principal Act is amended—
          (a) in subsection (1), by the insertion of the following definitions:
                         “ ‘approved project number’ has the meaning given to it by
                         subsection (4)(aa);
                         ‘unique receipt number’ has the meaning given to it by
                         subsection (16)(b)(vii).”,
          (b) in subsection (4), by the insertion of the following paragraph after paragraph (a):
                      “(aa) Where the Minister gives a certificate to a body in respect of a


                                                14
[2025.]                                 Finance Act 2025.                        [No. 18.] PT.1 S.9

                             project under paragraph (a), the Minister shall assign a unique
                             number to the project (in this section referred to as an ‘approved
                             project number’) and include that number in the certificate.”,
          (c) in subsection (9)—
              (i) by the substitution of the following paragraph for paragraph (b):
                        “(b) For the purposes of paragraph (a)(i), any such deduction or set-off
                             shall not be taken into account in determining in respect of the
                             individual or, as the case may be, the individual’s spouse or civil
                             partner—
                            (i) the remuneration of the office or employment for the purposes
                                of section 774(7)(c) of the individual or, as the case may be, the
                                individual’s spouse or civil partner for the relevant year of
                                assessment, or
                            (ii) net relevant earnings within the meaning of section 787, 787B
                                 or 787X, as the case may be, of the individual or, as the case
                                 may be, the individual’s spouse or civil partner for the relevant
                                 year of assessment,”,
                  and
              (ii) by the insertion of the following paragraph after paragraph (e):
                        “(f) An election made under paragraph (a) is irrevocable with effect
                             from the date that is the earliest of—
                            (i) the specified return date for the chargeable period, within the
                                meaning of section 959A, in respect of the return referred to in
                                paragraph (d),
                            (ii) the date on which the return referred to in paragraph (d) is
                                 delivered, or
                           (iii) 1 December in the year following the year in which the relevant
                                 donation was made.”,
          (d) in subsection (11)—
              (i) by the substitution of the following paragraph for paragraph (b):
                        “(b) For the purposes of paragraph (a)(i), any such deduction or set-off
                             shall not be taken into account in determining, in respect of the
                             individual or, as the case may be, the individual’s spouse or civil
                             partner—
                            (i) the remuneration of the office or employment for the purposes
                                of section 774(7)(c) of the individual or, as the case may be, the
                                individual’s spouse or civil partner for the relevant year of
                                assessment, or
                            (ii) net relevant earnings within the meaning of section 787, 787B


                                                15
PT.1 S.9 [No. 18.]                        Finance Act 2025.                                   [2025.]

                                  or 787X, as the case may be, of the individual or, as the case
                                  may be, the individual’s spouse or civil partner for the relevant
                                  year of assessment.”,
              (ii) in paragraph (d)—
                     (I) in subparagraph (ii), by the substitution of “in subsection (16),” for “in
                         subsection (16), and”, and
                     (II) by the insertion of the following subparagraphs after subparagraph (ii):
                            “(iia) the approved project number,
                             (iib) the unique receipt number, and”,
                     and
             (iii) by the insertion of the following paragraph after paragraph (e):
                           “(f) An election made under paragraph (a) is irrevocable with effect
                                from the date that is the earlier of—
                               (i) the date on which a claim is made under paragraph (d), or
                              (ii) 1 December in the year following the year in which the relevant
                                   donation was made.”,
          (e) in subsection (12), by the substitution of “subsection (9)(a)(ii)(II) or
              subsection (11)(a)(ii)(II), as the case may be,” for “subsection (11)(b)”, and
          (f) in subsection (16)(b)—
               (i) in subparagraph (v), by the substitution of “issued,” for “issued, and”, and
              (ii) by the insertion of the following subparagraphs after subparagraph (vi):
                            “(vii) a unique number assigned by the approved sports body in
                                   respect of the relevant donation (in this section referred to as a
                                   “unique receipt number”), and
                            (viii) the approved project number,”.


Amendment of section 531AM of Principal Act (charge to universal social charge)
10.   Section 531AM of the Principal Act is amended, in paragraph (b)(viii)(II) of the Table to
      that section—
          (a) in subclause (D), by the deletion of “or”, and
          (b) by the insertion of the following subclause after subclause (D):
                                  “(DA) under section 847AA in respect of a relevant donation
                                        (within the meaning of that section), or”.




                                                  16
[2025.]                                 Finance Act 2025.                             [No. 18.] PT.1

Amendment of section 847AA of Principal Act (deduction for donations to National
Governing Bodies)
11.   Section 847AA of the Principal Act is amended—
          (a) in subsection (1)—
              (i) in the definition of “elite athlete”, by the insertion of “or” after “Sport Ireland
                  International Carding Scheme,”,
              (ii) in paragraph (a)(ii) of the definition of “national governing body”, by the
                   substitution of “Minister,” for “Minister for Tourism, Culture, Arts, Gaeltacht,
                   Sports and Media,”, and
             (iii) by the insertion of the following definitions:
                          “ ‘qualifying project number’ has the meaning given to it by
                          subsection (8)(aa);
                          ‘unique receipt number’ has the meaning given to it by
                          subsection (9).”,
          (b) in subsection (4)—
              (i) by the substitution of the following paragraph for paragraph (c):
                        “(c) For the purposes of paragraph (a)(i), any such deduction or set-off
                             shall not be taken into account in determining in respect of the
                             individual or, as the case may be, the individual’s spouse or civil
                             partner—
                             (i) the remuneration of the office or employment for the purposes
                                 of section 774(7)(c) of the individual or, as the case may be, the
                                 individual’s spouse or civil partner for the relevant year of
                                 assessment, or
                            (ii) net relevant earnings within the meaning of section 787, 787B
                                 or 787X, as the case may be, of the individual or, as the case
                                 may be, the individual’s spouse or civil partner for the relevant
                                 year of assessment.”,

              (ii) in paragraph (e)—
                   (I) in subparagraph (ii), by the substitution of “in subsection (9),” for “in
                       subsection (9) and”,
                  (II) by the insertion of the following subparagraphs after subparagraph (ii):
                     “(iia) the qualifying project number,
                        (iib) the unique receipt number, and”,
                  and

             (iii) by the insertion of the following paragraph after paragraph (f):



                                                17
PT.1 S.11 [No. 18.]                      Finance Act 2025.                                  [2025.]

                          “(g) An election made under paragraph (a) is irrevocable from the date
                               that is the earlier of—
                              (i) the date on which the claim referred to in paragraph (e) is made,
                                  or

                             (ii) 1 December in the year following the year in which the relevant
                                  donation was made.”,

          (c) in subsection (5)—
               (i) by the substitution of the following paragraph for paragraph (c):
                          “(c) For the purposes of paragraph (a)(i), any such deduction or set-off
                               shall not be taken into account in determining in respect of the
                               individual or, as the case may be, the individual’s spouse or civil
                               partner—
                              (i) the remuneration of the office or employment for the purposes
                                  of section 774(7)(c) of the individual or, as the case may be, the
                                  individual’s spouse or civil partner for the relevant year of
                                  assessment, or
                             (ii) net relevant earnings, within the meaning of section 787, 787B
                                  or 787X, as the case may be, of the individual or, as the case
                                  may be, the individual’s spouse or civil partner for the relevant
                                  year of assessment.”,

                    and
              (ii) by the insertion of the following paragraph after paragraph (f):
                          “(g) An election made under paragraph (a) is irrevocable from the date
                               that is the earliest of—
                              (i) the specified return date for the chargeable period, within the
                                  meaning of section 959A, in respect of the return referred to in
                                  paragraph (e),
                             (ii) the date on which the return referred to in paragraph (e) is
                                  delivered, or
                             (iii) 1 December in the year following the year in which the relevant
                                   donation was made.”,
          (d) in subsection (8), by the insertion of the following paragraph after paragraph (a):
                      “(aa) Where the Minister gives a certificate to a body in respect of a
                            project under paragraph (a), the Minister shall assign a unique
                            number to the project (in this section referred to as a ‘qualifying
                            project number’) and shall include that number in the certificate.”,
              and


                                                 18
[2025.]                                Finance Act 2025.                       [No. 18.] PT.1 S.11

          (e) in subsection (9)—
              (i) by the substitution of “shall, on the acceptance of a relevant donation, assign a
                  unique number to the donation (in this section referred to as a ‘unique receipt
                  number’) and give to the person” for “shall, on acceptance of a relevant
                  donation, give to the person”, and
              (ii) in paragraph (b)—
                   (I) in subparagraph (iv), by the deletion of “and”, and
                  (II) in subparagraph (v), by the deletion of “and”, and
                 (III) by the insertion of the following subparagraphs after subparagraph (v):
                         “(vi) the qualifying project number, and
                         (vii) the unique receipt number, and”.


Amendment of section 216D of Principal Act (certain profits of micro-generation of
electricity)
12.   Section 216D of the Principal Act is amended, in subsection (1), in the definition of
      “relevant period”, by the substitution of “31 December 2028” for “31 December 2025”.


Amendment of section 216F of Principal Act (exemption of certain profits arising from
production, maintenance and repair of certain musical instruments)
13.   Section 216F(1) of the Principal Act is amended by the substitution of the following
      definition for the definition of “relevant period”:
             “ ‘relevant period’ means any of the years of assessment 2023 to 2028 (both years
             inclusive);”.


Annual returns by qualifying fund managers
14. (1) Part 30 of the Principal Act is amended by the insertion of the following section after
        section 784B:

          “784BA. (1) In this section—
                        ‘electronic means’ has the same meaning as it has in section 917EA;
                        ‘fund holder’ means the individual beneficially entitled to the assets in
                        the approved retirement fund;
                        ‘qualifying fund manager’ has the same meaning as it has in
                        section 784A;
                        ‘tax reference number’ has the same meaning as it has in
                        section 784A.
                    (2) A qualifying fund manager shall, within 3 months of the end of the
                        year of assessment, make a return to the Revenue Commissioners, by

                                               19
PT.1 S.14 [No. 18.]                     Finance Act 2025.                                 [2025.]

                          electronic means, in respect of all approved retirement funds which the
                          qualifying fund manager administered in that year of assessment.

                      (3) For the purposes of a return under this section, the qualifying fund
                          manager shall provide to the Revenue Commissioners the following
                          information in respect of each approved retirement fund that the
                          qualifying fund manager administers:
                         (a) the name and address of the fund holder;
                         (b) the tax reference number of the fund holder;
                         (c) the date on which the approved retirement fund was first held by
                             the fund holder;
                         (d) the country of residence of the fund holder;
                         (e) the number of approved retirement funds administered by the
                             qualifying fund manager on behalf of each fund holder;
                         (f) details and value of the assets held in the approved retirement fund,
                             including:
                            (i) asset type and location;
                            (ii) details of any income, profits or chargeable gains derived from
                                 those assets during the year of assessment concerned;
                           (iii) details of any assets acquired and or disposed of during the year
                                 of assessment concerned;
                           (iv) details of any distributions made in the year of assessment to
                                which the return relates;

                         (g) in respect of a transaction deemed to be a distribution for the
                             purposes of this Chapter:
                            (i) the name and address of the person to whom the distribution
                                was made;
                            (ii) the amount of the distribution;
                           (iii) the tax which the qualifying fund manager is required to account
                                 for in relation to that distribution;
                         (h) such other information in relation to assets held in, and
                             distributions made from, the approved retirement fund as the
                             Revenue Commissioners may require for the purposes of this
                             section.
                      (4) A return under this section shall be in a form prescribed or authorised
                          by the Revenue Commissioners and shall include a declaration to the
                          effect that the return is correct and complete.



                                                20
[2025.]                               Finance Act 2025.                        [No. 18.] PT.1 S.14

                    (5) A person who is required to make a return under this section and
                        who—
                       (a) fails to comply with any of the requirements of subsections (2) or
                           (3), as the case may be, or
                       (b) makes an incorrect or incomplete return under this section,
                        shall, for each such failure, be liable to a penalty of €3,000.”.
      (2) Subsection (1) applies for the year of assessment 2026 and each subsequent year of
          assessment.


Repeal of section 14 of Finance Act 2024
15.   Section 14 of the Finance Act 2024 is repealed.


Automatic enrolment retirement savings system
16.   Part 30 of the Principal Act is amended by the insertion of the following Chapter after
      Chapter 2D:
                                                    “CHAPTER 2E
                              Automatic Enrolment Retirement Savings System
            Interpretation (Chapter 2E)
            787AE. In this Chapter—
                     ‘Act of 2024’ means the Automatic Enrolment Retirement Savings
                     System Act 2024;
                     ‘AE provider scheme’ has the same meaning as it has in the Act of 2024;
                     ‘Authority’ has the same meaning as it has in the Act of 2024;
                     ‘balance’ has the same meaning as it has in Part 5 of the Act of 2024;
                     ‘contributing participant’ has the same meaning as it has in the Act of
                     2024;
                     ‘contribution’ has the same meaning as it has in the Act of 2024;
                     ‘emoluments’ has the same meaning as it has in Chapter 4 of Part 42;
                     ‘employee’ has the same meaning as it has in Chapter 4 of Part 42;
                     ‘employer’ has the same meaning as it has in Chapter 4 of Part 42;
                     ‘employer contribution’ has the same meaning as it has in the Act of
                     2024;
                     ‘participant’ has the same meaning as it has in the Act of 2024;
                     ‘participant account’, in relation to a participant, means the account
                     maintained for the participant by the Authority under section 76 of the
                     Act of 2024;


                                               21
PT.1 S.16 [No. 18.]                     Finance Act 2025.                                  [2025.]

                       ‘personal representative’ has the same meaning as it has in Part 5 of the
                       Act of 2024;
                       ‘State contribution’ has the same meaning as it has in the Act of 2024;
                       ‘unit’, in relation to an AE provider scheme, has the same meaning as it
                       has in Part 4 of the Act of 2024.
            Allowance to employer
            787AF. (1) For the purposes of this section, ‘chargeable period’ means an accounting
                       period of a company or a year of assessment.
                      (2) Subject to subsection (3), any employer contribution in respect of a
                          contributing participant shall, for the purposes of Case I or II of
                          Schedule D and of sections 83 and 707(4), be allowed to be deducted
                          as an expense, or expense of management, incurred in the chargeable
                          period in which the sum is paid but no other sum shall for those
                          purposes be allowed to be deducted as an expense, or expense of
                          management, in respect of the making, or any provision for the
                          making, of any such contributions.
                      (3) The amount of an employer contribution which may be deducted under
                          subsection (2) shall not exceed the amount contributed by that
                          employer to the Authority in respect of an employee in a trade or
                          undertaking in respect of the profits of which the employer is
                          assessable to income tax or corporation tax, as the case may be.
            Repayments to employer
            787AG. Where a repayment of employer contributions is made or becomes due to
                   an employer under section 64 of the Act of 2024 as a result of an
                   overpayment of contributions to the Authority, the repayment shall be
                   treated for the purposes of the Tax Acts as a receipt of that trade or
                   undertaking receivable when the repayment is due or on the last day on
                   which the trade or undertaking is carried on by the employer, whichever is
                   the earlier.
            Exemption of AE provider schemes
           787AH. (1) Exemption from income tax shall, on a claim being made in that
                      behalf, be allowed in respect of income derived from investments or
                      deposits of assets held in an AE provider scheme if it is income from
                      investments or deposits held for the purposes of the scheme.
                      (2) (a) In this subsection, ‘financial futures’ and ‘traded options’ mean,
                              respectively, financial futures and traded options for the time being
                              dealt in or quoted on any futures exchange or any stock exchange,
                              whether or not that exchange is situated in the State.
                         (b) For the purposes of subsection (1), a contract entered into in the
                             course of dealing in financial futures or traded options shall be
                             regarded as an investment.



                                                22
[2025.]                            Finance Act 2025.                      [No. 18.] PT.1 S.16

                 (3) Exemption from income tax shall, on a claim being made in that
                     behalf, be allowed in respect of underwriting commissions if the
                     underwriting commissions are applied for the purposes of the AE
                     provider scheme and in respect of which the Authority would, but for
                     this subsection, be chargeable to tax under Case IV of Schedule D.
                (4) (a) A unit in an AE provider scheme is not an asset of a pension fund
                        for the purposes of Chapter 1A of Part 27.
                    (b) For the purpose of this subsection, a unit referred to in
                        paragraph (a) includes a unit (within the meaning of section 739B)
                        in an investment undertaking (within the said meaning) held by a
                        participant.
          Taxation of payments from automatic enrolment retirement savings system
          787AI. (1) Subject to subsections (2) and (3)—
                    (a) the payment of the balance from a participant account, after any
                        lump sum withdrawn in accordance with subsection (3)(a), shall,
                        notwithstanding anything in section 18 or 19, be treated as a
                        payment to the participant of emoluments to which Schedule E
                        applies and, accordingly, the provisions of Chapter 4 of Part 42
                        shall apply to any such payment or amount treated as a payment,
                        and
                    (b) the Authority shall deduct tax from the balance held in that
                        participant’s account at the higher rate for the year of assessment in
                        which the balance is made available unless the Authority has
                        received from the Revenue Commissioners a revenue payroll
                        notification (within the meaning of section 983) for that year in
                        respect of the participant.
                 (2) The Authority shall be liable to pay to the Collector-General the
                     income tax which the Authority is required to deduct from any balance
                     withdrawn by a participant by virtue of this section and the individual
                     beneficially entitled to the balance withdrawn by that participant from
                     their participating account, including the personal representatives of a
                     deceased individual who was so entitled prior to the individual’s death,
                     shall allow such deduction; but where there are no funds or
                     insufficient funds available out of which the Authority may satisfy the
                     tax required to be deducted, the amount of such tax for which there are
                     insufficient funds available shall be a debt due to the Authority from
                     the individual beneficially entitled to the balance held in the
                     participant account or from the estate of the deceased individual, as
                     the case may be.
                 (3) Subsection (1) shall not apply where the balance from a participant
                     account is—
                    (a) an amount made available, at the time the balance of the participant
                        account is first made available to the participant, by way of lump

                                           23
PT.1 S.16 [No. 18.]                      Finance Act 2025.                                    [2025.]

                              sum (in accordance with section 83(1)(a) of the Act of 2024) not
                              exceeding 25 per cent of the value of the balance at that time, or
                          (b) an amount made available to the personal representatives of the
                              participant following the death of the participant and before the
                              giving of a notification under section 82(1)(d) of the Act of 2024 by
                              the Authority.
                      (4) (a) Where the payment of the balance referred to in subsection (1) is
                              made following the death of the participant who was prior to death
                              beneficially entitled to the assets of the participant account, the
                              amount of the funds shall be treated as the income of that
                              participant for the year of assessment in which that participant dies
                              and, subject to paragraph (b), subsection (1) shall apply
                              accordingly.
                          (b) Subsection (1) shall not apply to a payment made of the balance
                              following the death of the participant, where the giving of a
                              notification under section 82(1)(d) of the Act of 2024 by the
                              Authority is made to—
                             (i) a spouse or civil partner of the participant, or
                             (ii) any child of the participant or any child of the spouse or civil
                                  partner of the participant.
                          (c) Where, in a case referred to in paragraph (b), the payment of the
                              balance is made to a person who had attained the age of 21 years at
                              the date of death of the participant beneficially entitled to the assets
                              in the participant account, the Authority shall deduct income tax
                              from the distribution under Case IV of Schedule D at a rate of 30
                              per cent, and—
                             (i) the amount so charged to tax—
                                 (I) shall not be reckoned in computing total income for the
                                     purposes of the Tax Acts, and
                                (II) shall be computed without regard to any amount deductible
                                     from, or deductible in computing, total income for the
                                     purposes of the Tax Acts,
                             (ii) the charging of the balance in such manner shall be without any
                                  relief or reduction specified in the Table to section 458, or any
                                  other deduction from that distribution, and
                            (iii) section 188 shall not apply as regards the amount so charged.
                          (d) Where the Authority deducts tax in accordance with paragraph (c),
                              subsections (8) to (15) of section 790AA shall, with any necessary
                              modifications, apply as if any reference in those subsections—
                             (i) to the administrator were a reference to the Authority, and


                                                  24
[2025.]                                 Finance Act 2025.                       [No. 18.] PT.1 S.16

                           (ii) to an excess lump sum were a reference to the balance of a kind
                                referred to in paragraph (c).”.


Repeal of section 15 of Finance Act 2024
17.   Section 15 of the Finance Act 2024 is repealed.


Automatic enrolment retirement savings system (amendments consequential on insertion
of Chapter 2E in Part 30)
18. (1) The Principal Act is amended—
          (a) in section 118, by the insertion of the following subsection after subsection (5L):
                 “(5M) Subsection (1) shall not apply to expense incurred by the body corporate
                       in the provision for an employee (within the meaning of Chapter 2E of
                       Part 30) of a contribution (within the said meaning).”,
          (b) in Part 7, by the insertion of the following section after section 192P:
             “Exemption in respect of State contribution under automatic enrolment
             retirement savings system
             192Q. A State contribution (within the meaning of the Automatic Enrolment
                   Retirement Savings System Act 2024) shall be exempt from income tax
                   and shall not be reckoned in computing total income for the purposes of
                   the Income Tax Acts or in computing amounts chargeable to universal
                   social charge in accordance with Part 18D.”,
          (c) in section 246(3)—
               (i) in paragraph (i), by the substitution of “such subsidiary,” for “such subsidiary,
                   or”,
              (ii) in paragraph (j), by the substitution of “such subsidiary,” for “such
                   subsidiary.”, and
             (iii) by the insertion of the following paragraphs after paragraph (j):
                       “(k) interest paid to the Authority (within the meaning of Chapter 2E of
                            Part 30), or
                         (l) interest paid by the Authority (within the meaning of Chapter 2E of
                             Part 30).”,
          (d) in section 256(1), in the definition of “relevant deposit”—
               (i) in paragraph (a)—
                   (I) in subparagraph (v), by the substitution of “The Investor Compensation
                       Company Limited,” for “The Investor Compensation Company Limited,
                       or”,
                  (II) in subparagraph (vi), by the substitution of “Icarom plc, or” for “Icarom
                       plc,”, and


                                                25
PT.1 S.18 [No. 18.]                       Finance Act 2025.                                   [2025.]

                 (III) by the insertion of the following subparagraph after subparagraph (vi):
                           “(vii) An tÚdarás Náisiúnta um Uathrollú Coigiltis Scoir,”,
              (ii) in paragraph (k), by the substitution of “Revenue Commissioners,” for
                   “Revenue Commissioners, or”,
             (iii) in paragraph (l), by the substitution of “relevant deposit taker, or” for “relevant
                   deposit taker;”, and
             (iv) by the insertion of the following paragraph after paragraph (l):
                        “(m) which is made by the Authority (within the meaning of Chapter 2E
                             of Part 30) in respect of contributions (within the meaning of the
                             Automatic Enrolment Retirement Savings System Act 2024) made
                             to the Authority;”,
          (e) in section 531AM, in paragraph (a) of the Table to that section—
                      (i) in clause (VI), by the deletion of “and”,
                  (ii) in clause (VII), by the substitution of “(within the meaning of Chapter
                       2D of Part 30) and,”, for “(within the meaning of Chapter 2D of
                       Part 30).”, and
                  (iii) by the insertion of the following clause after clause (VII):
                             “(VIII) emoluments in the nature of a contribution by an employer
                                     to the Authority (within the meaning of Chapter 2E of
                                     Part 30).”,
          (f) in section 608(2), by the substitution of “PEPP assets (within the meaning of
              Chapter 2D of Part 30) or held by or on behalf of that person as units in an AE
              provider scheme (within the meaning of Chapter 2E of Part 30)” for “PEPP assets
              (within the meaning of Chapter 2D of Part 30)”,
          (g) in section 706(3), by the insertion of the following paragraph after paragraph (e):
                         “(f) any contract with an AE provider scheme (within the meaning of
                              Chapter 2E of Part 30);”,
         (h) in section 739B(1), by the insertion of the following definitions:
                           “ ‘AE provider scheme’ has the same meaning as it has in Chapter 2E
                           of Part 30;
                           ‘Authority’ has the same meaning as it has in Chapter 2E of Part 30;
                           ‘participant’ has the same meaning as it has in Chapter 2E of Part 30;”,
          (i) in section 739D(6), by the insertion of the following paragraph after
              paragraph (kc):
                        “(kd) holds units in an AE provider scheme, registered in the name of the
                              Authority on behalf of a participant and the Authority has made a
                              declaration to that effect to the investment undertaking,”,


                                                  26
[2025.]                                   Finance Act 2025.                      [No. 18.] PT.1 S.18

          (j) in section 787O(1)—
              (i) in the definition of “administrator”—
                     (I) in paragraph (d), by the substitution of “section 787U,” for
                         “section 787U, and”,
                    (II) in paragraph (e), by the substitution of “Chapter 2D, and” for
                         “Chapter 2D;”, and
                    (III) by the insertion of the following paragraph after paragraph (e):
                          “(f) An tÚdarás Náisiúnta um Uathrollú Coigiltis Scoir;”,
              (ii) in the definition of “member”, by the substitution of “Chapter 2D, a participant
                   within the meaning of Chapter 2E” for “Chapter 2D”,
             (iii) in the definition of “relevant pension arrangement”—
                     (I) in paragraph (f), by the substitution of “paragraph (e),” for
                         “paragraph (e), or”,
                    (II) in paragraph (g), by the substitution of “that Chapter, or” for “that
                         Chapter;”, and
                    (III) by the insertion of the following paragraph after paragraph (g):
                          “(h) the automatic enrolment retirement savings system established,
                               maintained and controlled by the Authority (within the meaning of
                               Chapter 2E) under the Automatic Enrolment Retirement Savings
                               System Act 2024;”,
                    and
             (iv) by the insertion of the following definition:
                            “ ‘participant’ has the same meaning as it has in Chapter 2E;”,
              and
          (k) in section 790AA(1)(a), in the definition of “relevant pension arrangement”—
              (i) in subparagraph (vii), by the substitution of “that Chapter,” for “that Chapter;”,
                  and
              (ii) by the insertion of the following subparagraph after subparagraph (vii):
                           “(viii) the automatic enrolment retirement savings system established,
                                   maintained and controlled by the Authority (within the meaning
                                   of Chapter 2E) under the Automatic Enrolment Retirement
                                   Savings System Act 2024;”.

     (2) Section 85 of the Capital Acquisitions Tax Consolidation Act 2003 is amended by the
         substitution of the following subsection for subsection (1):
                     “(1) In this section—



                                                  27
PT.1 S.18 [No. 18.]                 Finance Act 2025.                                    [2025.]

                      ‘Act of 1997’ means the Taxes Consolidation Act 1997;
                      ‘Act of 2024’ means the Automatic Enrolment Retirement Savings
                      System Act 2024;
                      ‘Authority’ has the same meaning as it has in the Act of 2024;
                      ‘balance’ has the same meaning as it has in section 78 of the Act of
                      2024;
                      ‘participant’ has the same meaning as it has in the Act of 2024;
                      ‘participant account’, in relation to a participant, means the account
                      maintained for the participant by the Authority under section 76 of the
                      Act of 2024;
                      ‘retirement fund’, in relation to an inheritance taken on death of a
                      disponer, means—
                      (a) a fund that is—
                         (i) an approved retirement fund or an approved minimum
                             retirement fund, within the meaning of section 784A or 784C of
                             the Act of 1997,
                        (ii) a Personal Retirement Savings Account, within the meaning of
                             section 787A of the Act of 1997, where assets of the Personal
                             Retirement Savings Account are treated under subsection (4) or
                             (4B), as the case may be, of section 787G of that Act as having
                             been made available to an individual,
                        (iii) a vested RAC within the meaning of section 787O(1) of the Act
                              of 1997, or
                        (iv) a PEPP, within the meaning of Chapter 2D of Part 30 of the Act
                             of 1997, where assets of the PEPP are treated under
                             subsection (4) or (6), as the case may be, of section 787AA of
                             that Act as having been made available to an individual,
                         being wholly comprised of all or any of the following, that is—
                         (I) property which represents in whole or in part the accrued rights
                             of the disponer, or of a predeceased spouse or civil partner of
                             the disponer, under—
                            (A) an annuity contract or retirement benefits scheme approved
                                by the Commissioners for the purposes of Chapter 1 or 2 of
                                Part 30 of the Act of 1997, or
                            (B) a Personal Retirement Savings Account being a PRSA
                                product approved by the Commissioners for the purposes of
                                Chapter 2A of Part 30 of the Act of 1997,
                        (II) any accumulations of income of such property,



                                            28
[2025.]                                         Finance Act 2025.                    [No. 18.] PT.1 S.18

                                    (III) property which represents in whole or in part these
                                          accumulations, or
                                    (IV) a PEPP, within the meaning of Chapter 2D of Part 30 of the Act
                                         of 1997, registered for the purposes of that Chapter under
                                         Article 7 of Regulation (EU) No. 2019/1238 of the European
                                         Parliament and Council of 20 June 20191,
                                      or
                               (b) the balance in a participant’s account, where the Authority sent a
                                   notification to the participant, in accordance with section 82(1)(d)
                                   of the Act of 2024, that such balance was eligible for withdrawal.”.
      (3) Section 82C(1) of the Stamp Duties Consolidation Act 1999 is amended, in the
          definition of “pension scheme”—
             (a) in paragraph (g), by the substitution of “that Chapter, or” for “that Chapter;”, and
            (b) by the insertion of the following paragraph after paragraph (g):
                              “(h) an AE provider scheme within the meaning of the Automatic
                                   Enrolment Retirement Savings System Act 2024;”.


Amendment of section 128F of Principal Act (key employee engagement programme)
19. (1) Section 128F of the Principal Act is amended—
             (a) in subsection (1)—
                   (i) in the definition of “excluded activities”, by the substitution of the following
                       paragraph for paragraph (c):
                              “(c) financing activities,”,
                        and
                  (ii) by the substitution of the following definition for the definition of “financial
                       activities”:
                                “ ‘financing activities’ has the same meaning as in section 489;”,
            (b) in subsection (3), by the substitution of “1 January 2029” for “1 January 2026”,
                and
             (c) in subsection (6A)(a), by the substitution of “1 January 2029” for “1 January
                 2026”.
      (2) Paragraphs (b) and (c) of subsection (1) shall come into operation on such day as the
          Minister for Finance may appoint by order.




1   OJ No. L.198, 25.7.2019, p.1.


                                                        29
PT.1 [No. 18.]                             Finance Act 2025.                                  [2025.]

Amendment of Schedule 13 to Principal Act (accountable persons for purposes of Chapter
1 of Part 18)
20.   Schedule 13 to the Principal Act is amended—
          (a) by the substitution of the following paragraph for paragraph 69:
                  “69. Temple Bar Cultural Trust Designated Activity Company.”,
                 and
          (b) by the insertion of the following paragraphs after paragraph 217:
                  “218. Taighde Éireann.
                  219. Judicial Appointments Commission.
                  220. Comhlacht Formhaoirsithe Seachtrach Óglaigh na hÉireann.
                  221. Gambling Regulatory Authority of Ireland.
                  222. oifig an Scrúdaitheora Neamhspleách um Reachtaíocht Slándála.”.


Amendment of section 530A of Principal Act (principal to whom relevant contracts tax
applies)
21.   Section 530A of the Principal Act is amended, in subsection (1), by the substitution of
      the following paragraph for paragraph (d):
                         “(d) a local authority, a public utility society (within the meaning of
                              section 2 of the Housing Act 1966), a body referred to in section 45
                              of the Housing Act 1966 and approved for the purposes of the said
                              section 45 or a body referred to in subsection (1) of section 7 of the
                              Housing (Miscellaneous Provisions) Act 1979 and approved for the
                              purposes of the said section 7.”.


Amendment of section 823A of Principal Act (deduction for income earned in certain
foreign states)
22.   Section 823A of the Principal Act is amended—
          (a) in subsection (1)—
                 (i) by the substitution of the following definition for the definition of “qualifying
                     day”:
                           “ ‘qualifying day’, in relation to an office or employment of an
                           individual, means a day—
                          (a) which is one throughout the whole of which the individual is
                              present in a relevant state for the purposes of the performance of
                              the duties of the office or employment,
                          (b) where such day is substantially devoted to the performance of such
                              duties, and


                                                  30
[2025.]                                Finance Act 2025.                      [No. 18.] PT.1 S.22

                        (c) which shall not be counted more than once as a qualifying day;”,
                  and
              (ii) by the substitution of the following definition for the definition of “relevant
                   state”:
                         “ ‘relevant state’ means, as regards the years of assessment 2012 to
                         2025, the Russian Federation, and as regards the years of assessment
                         2012 to 2030, the Federative Republic of Brazil, the Republic of India,
                         the People’s Republic of China or the Republic of South Africa, and
                         includes—
                        (a) as regards the years of assessment 2013 to 2030, the Arab Republic
                            of Egypt, the People’s Democratic Republic of Algeria, the
                            Republic of Senegal, the United Republic of Tanzania, the Republic
                            of Kenya, the Federal Republic of Nigeria, the Republic of Ghana
                            and the Democratic Republic of the Congo,
                        (b) as regards the years of assessment 2015 to 2030, Japan, the
                            Republic of Singapore, the Republic of Korea, the Kingdom of
                            Saudi Arabia, the United Arab Emirates, the State of Qatar, the
                            Kingdom of Bahrain, the Republic of Indonesia, the Socialist
                            Republic of Vietnam, the Kingdom of Thailand, the Republic of
                            Chile, the Sultanate of Oman, the State of Kuwait, the United
                            Mexican States and Malaysia,
                        (c) as regards the years of assessment 2017 to 2030, the Republic of
                            Colombia and the Islamic Republic of Pakistan, and
                        (d) as regards the years of assessment 2026 to 2030, the Republic of
                            the Philippines and the Republic of Türkiye;”,

          (b) by the insertion of the following subsection after subsection (1):
                  “(1A) For the purposes of the definition, in subsection (1), of ‘qualifying
                        day’—
                        (a) presence in a relevant state shall include the duration of time spent
                            travelling directly from the State to a relevant state, and from a
                            relevant state to the State or to another relevant state,
                        (b) a day shall be a qualifying day only where the individual’s presence
                            in the relevant state is reasonably required for the purposes of the
                            performance of the duties of the office or employment, and
                        (c) a day shall not be precluded from being a qualifying day solely on
                            the grounds that the duties of the office or employment could have
                            been performed in the State on that day.”,

          (c) by the substitution of the following subsection for subsection (3):
                   “(3) Where for any year of assessment an individual resident in the State


                                               31
PT.1 S.22 [No. 18.]                   Finance Act 2025.                                  [2025.]

                        makes a claim in that behalf to and satisfies an authorised officer that
                        either—
                        (a) the number of days in that year which are qualifying days in
                            relation to an office or employment of the individual (together with
                            any days which are qualifying days in relation to any other such
                            office or employment of the individual), or
                       (b) the number of such days referred to in paragraph (a) in a relevant
                           period in relation to that year and no part of which period is
                           comprised in any other relevant period,
                        amounts to at least 30 days, there shall be deducted from the income,
                        profits or gains of the individual from all offices or employments
                        assessable under Schedule D or E, as may be appropriate, an amount
                        equal to the specified amount in relation to that office or employment
                        or those offices or employments but that amount, or the aggregate of
                        those amounts where there is more than one such office or
                        employment, shall not exceed €50,000.”,
              and
         (d) in subsection (6), by the substitution of “2015 to 2030” for “2015 to 2025”.


Amendment of section 825C of Principal Act (special assignee relief programme)
23.   Section 825C of the Principal Act is amended—
          (a) by the insertion of the following subsection after subsection (2AA):
                “(2AB) In this section, in the case of an individual who arrives in the State in
                       any of the tax years 2026 to 2030, ‘relevant employee’ means an
                       individual—
                        (a) who, for the whole of the 6 months immediately before his or her
                            arrival in the State, was a full time employee of a relevant employer
                            and exercised the duties of his or her employment for that relevant
                            employer outside the State,
                       (b) who arrives in the State at the request of his or her relevant
                           employer—
                           (i) to perform in the State duties of his or her employment for that
                               employer, or
                           (ii) to take up employment in the State with an associated company
                                and to perform duties in the State for that company,
                        (c) who performs the duties referred to in paragraph (b) for a minimum
                            period of 12 consecutive months from the date he or she first
                            performs those duties in the State,
                       (d) who, for the year of arrival in the State, is entitled to receive
                           income, profits or gains from an employment with a relevant

                                               32
[2025.]                                Finance Act 2025.                     [No. 18.] PT.1 S.23

                            employer or an associated company, which, after excluding the
                            amounts referred to at paragraphs (a) to (h) of the definition, in
                            subsection (1), of ‘relevant income’, is not less than the annualised
                            equivalent of €125,000,
                        (e) to whom a PPS number has been issued,
                        (f) who was not resident in the State for the 5 tax years immediately
                            preceding the tax year in which he or she first arrives in the State
                            for the purposes of performing the duties referred to in
                            paragraph (b), and
                        (g) in respect of whom the relevant employer or associated company
                            certifies, in such form as the Revenue Commissioners may require,
                            within 90 days from the employee’s arrival in the State to perform
                            the duties referred to in paragraph (b), that—
                           (i) the individual complies with the conditions set out in
                               paragraphs (a) to (e), and
                          (ii) the relevant employer or associated company has complied with
                               Regulation 17(2) of the Income Tax (Employments) Regulations
                               2018 (S.I. No. 345 of 2018),
                            but where such certification is made after 90 days but within 180
                            days from the date of the employee’s arrival in the State, the
                            individual shall be deemed to be a relevant employee for the
                            purposes of this section.”,
          (b) in subsection (2B)(b)—
              (i) in subparagraph (i)—
                   (I) by the substitution of “referred to in subsection (2)(a)(ii), (2A)(b),
                       (2AA)(b) or (2AB)(b)” for “referred to in subsection (2)(a)(ii), (2A)(b)
                       or (2AA)(b)”, and
                  (II) in subclause (B), by the substitution of “set out in subsection (2A)(b),
                       (2AA)(b) or (2AB)(b)” for “set out in subsection (2A)(b) or (2AA)(b)”,
                  and
              (ii) by the substitution of the following subparagraph for subparagraph (ii)—
                         “(ii) ‘B’ is €75,000 or, in the case of a relevant employee who arrives
                               in the State—
                               (I) in any of the tax years 2023 to 2025, €100,000, or
                              (II) in any of the tax years 2026 to 2030, €125,000.’’,
          (c) in subsection (3)—
              (i) in paragraph (a)—
                   (I) by the substitution of the following subparagraph for subparagraph (ii):

                                               33
PT.1 S.23 [No. 18.]                        Finance Act 2025.                                        [2025.]

                            “(ii) performs the duties referred to in subsection (2)(a)(ii), (2A)(b),
                                  (2AA)(b) or (2AB)(b), and”,
                          and
                    (II) by the substitution of the following subparagraph for subparagraph (iii):
                            “(iii) has relevant income from his or her relevant employer or from
                                   the associated company, the annualised equivalent of which is—
                                    (I) subject to clauses (II) and (III), not less than €75,000,
                                   (II) in the case of a relevant employee who arrives in the State in
                                        any of the tax years 2023 to 2025, not less than €100,000, or
                                  (III) in the case of a relevant employee who arrives in the State in
                                        any of the tax years 2026 to 2030, not less than €125,000,’’,
                    and
              (ii) by the substitution of the following subparagraph for subparagraph (c):
                          “(c) (i) A relevant employee, other than a relevant employee referred to
                                   in subsection (2AB), shall only be entitled to relief under this
                                   section for 5 consecutive tax years, commencing with the tax
                                   year for which the relevant employee is first entitled to relief
                                   under this section.
                                (ii) A relevant employee referred to in subsection (2AB) shall only
                                     be entitled to relief under this section for—
                                    (I) 5 consecutive tax years, commencing with the tax year for
                                        which the relevant employee is first entitled to relief under
                                        this section, where the certification referred to in paragraph
                                        (g) of subsection (2AB) is made within 90 days from the
                                        employee’s arrival in the State, or
                                   (II) 4 consecutive tax years, commencing with the tax year after
                                        which the relevant employee is first entitled to relief under
                                        this section, where the certification referred to in
                                        paragraph (g) of subsection (2AB) is made after 90 days but
                                        within 180 days from the employee’s arrival in the State.’’,
         (d) in subsection (4)(b)—
               (i) by the substitution of “2030” for “2025”, and
              (ii) in subparagraph (i), by the substitution of “set out in subsection (2A)(b),
                   (2AA)(b) or (2AB)(b)” for “set out in subsection (2A)(b) or (2AA)(b)”,
              and
          (e) in subsection (10), by the substitution of “30 June” for “23 February”.




                                                    34
[2025.]                                  Finance Act 2025.                                  [No. 18.] PT.1

Amendment of section 121 of Principal Act (benefit of use of car)
24.   Section 121(4A) of the Principal Act is amended—
          (a) in paragraph (a), by the substitution of “column (3), (4), (5), (6), (7) or (8)” for
              “column (3), (4), (5), (6) or (7)”,
          (b) in paragraph (aa)—
               (i) in subparagraph (iv), by the substitution of “subject to paragraph (ab), €20,000”
                   for “€20,000”, and
              (ii) in subparagraph (v), by the substitution of “subject to paragraph (ab), €10,000”
                   for “€10,000”,
          (c) in paragraph (ab)—
               (i) by the substitution of “each of the years of assessment 2023 to 2028 (both
                   years inclusive)” for “the years of assessment 2023, 2024 and 2025”,
              (ii) in subparagraph (i)—
                   (I) by the substitution of “subparagraph (i), (ii), (iii), (iv) or (v)” for “subparagraph
                       (i), (ii) or (iii)”,
                  (II) in clause (I), by the substitution of “subparagraph (i), (ii), (iii), (iv) or
                       (v)” for “subparagraph (i), (ii) or (iii)”,
                  (III) by the substitution of the following for clause (II):
                                 “(II) €10,000 for each of the years of assessment 2023 to 2026
                                       (both years inclusive), €5,000 for the year of assessment
                                       2027 and €2,500 for the year of assessment 2028,”,
                  and
             (iii) in subparagraph (ii)—
                   (I) by the substitution of “A1, A, B, C and D” for “A, B, C and D”, and
                  (II) by the substitution of “an amount ascertained under clause (II)” for
                       “€10,000”,
          (d) in paragraph (b), by the substitution of “column (3), (4), (5), (6), (7) or (8)” for
              “column (3), (4), (5), (6) or (7)” in both places where it occurs, and
          (e) in paragraph (d)—
               (i) by the substitution of the following Table for Table A:

                                                       “TABLE A

                         Business Mileage                            Vehicle Categories
                        Lower          Upper         A1         A        B         C         D        E
                         limit         limit
                         (1)             (2)           (3)     (4)       (5)      (6)       (7)       (8)


                                                  35
PT.1 S.24 [No. 18.]                        Finance Act 2025.                                    [2025.]

                       Kilometres     Kilometres      Per     Per      Per      Per      Per     Per
                                                      cent    cent     cent     cent     cent    cent
                           —            26,000          15    22.5    26.25      30     33.75    37.5
                          26,001        39,000          12     18       21       24      27       30
                          39,001        48,000          9     13.5    15.75      18     20.25    22.5
                          48,001          —             6      9       10.5      12     13.5      15
                                                                                                       ”,
                    and
              (ii) by the substitution of the following Table for Table B:

                                                        “TABLE B

                        Vehicle Category                     CO2 Emissions (CO2 g/km)
                                (1)                                      (2)
                               A1             0g/km
                                A             More than 0g/km up to and including 59g/km
                                B             More than 59g/km up to and including 99g/km
                                C             More than 99g/km up to and including 139g/km
                                D             More than 139g/km up to and including 179g/km
                                E             More than 179g/km
                                                                                                       ”.


Amendment of section 121A of Principal Act (benefit of use of van)
25.   Section 121A(2)(b) of the Principal Act is amended—
          (a) in subparagraph (vii)—
               (i) in clause (IV), by the substitution of “subject to subparagraph (viii), €20,000”
                   for “€20,000”, and
              (ii) in clause (V), by the substitution of “subject to subparagraph (viii), €10,000”
                   for “€10,000”,
              and
         (b) in subparagraph (viii)—
               (i) by the substitution of “each of the years of assessment 2023 to 2028 (both
                   years inclusive)” for “the years of assessment 2023, 2024 and 2025”,
              (ii) in clause (I)—
                      (I) by the substitution of “clause (I), (II), (III), (IV) or (V)” for “clause (I),
                          (II) or (III)”,
                    (II) in subclause (A), by the substitution of “clause (I), (II), (III), (IV) or
                         (V)” for “clause (I), (II) or (III)”, and


                                                   36
[2025.]                                      Finance Act 2025.                      [No. 18.] PT.1 S.25

                        (III) by the substitution of the following subclause for subclause (B):
                                       “(B) €10,000 for each of the years of assessment 2023 to
                                            2026 (both years inclusive), €5,000 for the year of
                                            assessment 2027 and €2,500 for the year of assessment
                                            2028,”,
                         and
                   (iii) in clause (II), by the substitution of “an amount ascertained under
                         clause (I) (B)” for “€10,000”.

                                                 CHAPTER 4

                             Income Tax, Corporation Tax and Capital Gains Tax


Amendment of section 285A of Principal Act (acceleration of wear and tear allowances for
certain energy-efficient equipment)
26.       Section 285A of the Principal Act is amended, in subsection (1), in the definition of
          “relevant period”, by the substitution of “31 December 2030” for “31 December 2025”.


Amendment of section 285C of Principal Act (acceleration of wear and tear allowances
for gas vehicles and refuelling equipment)
27.       Section 285C of the Principal Act is amended, in subsection (1), in the definition of
          “relevant period”, by the substitution of “31 December 2030” for “31 December 2025”.


Amendment of section 285D of Principal Act (acceleration of wear and tear allowances
for farm safety equipment)
28.       Section 285D of the Principal Act is amended, in subsection (18)—
              (a) in paragraph (b), by the substitution of “, Regulation (EU) 2019/1243 of the
                  European Parliament and of the Council of 20 June 20192 and Commission
                  Delegated Regulation (EU) 2023/137 of 10 October 20223” for “and Regulation
                  (EU) 2019/1243 of the European Parliament and of the Council of 20 June
                  20194”, and
              (b) in paragraph (c), by the substitution of “Commission Delegated Regulation (EU)
                  2019/1755 of 8 August 20195 and Commission Delegated Regulation (EU)
                  2023/674 of 26 December 20226” for “and Commission Delegated Regulation
                  (EU) 2019/1755 of 8 August 20197”.




2     OJ No. L198, 25.7.2019, p.241
3     OJ No. L19, 20.1.2023, p.5
4     OJ No. L198, 25.7.2019, p.241
5     OJ No. L270, 24.10.2019, p.1
6     OJ No. L87, 24.3.2023, p.1
7     OJ No. L270, 24.10.2019, p.1


                                                     37
PT.1 [No. 18.]                                Finance Act 2025.                                  [2025.]

Amendment of section 658A of Principal Act (farming: accelerated allowances for capital
expenditure on slurry storage)
29.       Section 658A of the Principal Act is amended—
              (a) in subsection (1), in the definition of “relevant period”, by the substitution of “31
                  December 2029” for “31 December 2025”, and
              (b) in subsection (7)—
                    (i) in paragraph (b), by the substitution of “, Regulation (EU) 2019/1243 of the
                        European Parliament and of the Council of 20 June 20198 and Commission
                        Delegated Regulation (EU) 2023/137 of 10 October 2022 9” for “and
                        Regulation (EU) 2019/1243 of the European Parliament and of the Council of
                        20 June 201910”, and
                    (ii) in paragraph (c), by the substitution of “, Commission Delegated Regulation
                         (EU) 2019/1755 of 8 August 201911 and Commission Delegated Regulation
                         (EU) 2023/674 of 26 December 202212” for “and Commission Delegated
                         Regulation (EU) 2019/1755 of 8 August 201913”.



Living City Initiative
30.       The Principal Act is amended—
              (a) in section 372AAA(1)—
                    (i) in the definition of “qualifying period”, by the substitution of “31 December
                        2030” for “31 December 2027”,
                    (ii) in the definition of “relevant house”, by the substitution of “1975” for “1915”,
                         and
                   (iii) by the insertion of the following definitions:
                                 “ ‘Commission Regulation (EU) 2023/2831’ means Commission
                                 Regulation (EU) 2023/2831 of 13 December 202314 on the application
                                 of Articles 107 and 108 of the Treaty on the Functioning of the
                                 European Union to de minimis aid;
                                 ‘de minimis aid’ means aid granted in compliance with Commission
                                 Regulation (EU) 2023/2831;
                                 ‘permissible ceiling of aid’ means the maximum amount of de minimis
                                 aid of €300,000 that may be granted to a single undertaking over any
                                 period of 3 years in accordance with Commission Regulation (EU)
                                 2023/2831;


8     OJ No. L198, 25.7.2019, p.241
9     OJ No. L19, 20.1.2023, p.5
10    OJ No. L198, 25.7.2019, p.241
11    OJ No. L270, 24.10.2019, p.1
12    OJ No. L87, 24.3.2023, p.1
13    OJ No. L270, 24.10.2019, p.1
14    OJ L2023/2831, 15.12.2023


                                                      38
[2025.]                                Finance Act 2025.                        [No. 18.] PT.1 S.30

                         ‘single undertaking’ has the meaning given to it by Article 2(2) of
                         Commission Regulation (EU) 2023/2831;”,
          (b) in section 372AAC—
              (i) in subsection (1)—
                   (I) by the deletion of the definition of “property developer”, and
                  (II) by the substitution of the following definition for the definition of
                       “qualifying expenditure”:
                         “ ‘qualifying expenditure’, means, notwithstanding section 279, capital
                         expenditure incurred in the qualifying period on the conversion or the
                         refurbishment of a qualifying premises after deducting from that
                         amount of expenditure any sum in respect of or by reference to—
                        (a) that expenditure,
                        (b) the qualifying premises, or
                        (c) the conversion work, or as the case may be, the refurbishment work
                            in respect of which that expenditure was incurred,
                         which the person has received or is entitled to receive, directly or
                         indirectly, from the State, any board established by statute or any
                         public or local authority, and for the purposes of giving relief under
                         this section, any reference to expenditure being incurred shall include
                         a reference to expenditure deemed under any provision of Part 9 to be
                         incurred;”,
             (ii) by the deletion of subsection (1A),
             (iii) by the substitution of the following subsection for subsection (4):
                   “(4) (a) In relation to qualifying expenditure incurred before 1 January
                            2026 in the qualifying period on a qualifying premises, section 272
                            shall apply as if—
                            (i) in subsection (3)(a)(ii) of that section the reference to 4 per cent
                                were a reference to 15 per cent, and
                           (ii) in subsection (4)(a) of that section the following were
                                substituted for subparagraph (ii):
                                  ‘(ii) where capital expenditure on the conversion or
                                        refurbishment of the building or structure is incurred, 7
                                        years beginning with the time when the building or
                                        structure was first used subsequent to the incurring of
                                        that expenditure.’.
                        (b) In relation to qualifying expenditure incurred on or after 1 January
                            2026 in the qualifying period on a qualifying premises, section 272
                            shall apply as if—



                                                39
PT.1 S.30 [No. 18.]                       Finance Act 2025.                                   [2025.]

                              (i) in subsection (3)(a)(ii) of that section the reference to 4 per cent
                                  were a reference to 50 per cent, and
                             (ii) in subsection (4)(a) of that section the following were substituted
                                  for subparagraph (ii):
                                    ‘(ii) where capital expenditure on the conversion or
                                          refurbishment of the building or structure is incurred, 10
                                          years beginning with the time when the building or
                                          structure was first used subsequent to the incurring of
                                          that expenditure.’.”,
             (iv) by the substitution of the following subsection for subsection (5):
                      “(5) Notwithstanding section 274(1), no balancing allowance or balancing
                           charge shall be made in relation to a qualifying premises by reason of
                           any event referred to in that section which occurs more than—
                          (a) 7 years after the qualifying premises was first used subsequent to
                              the incurring of the qualifying expenditure on the conversion or
                              refurbishment of the qualifying premises where that qualifying
                              expenditure was incurred before 1 January 2026, or
                          (b) 10 years after the qualifying premises was first used subsequent to
                              the incurring of the qualifying expenditure on the conversion or
                              refurbishment of the qualifying premises where that qualifying
                              expenditure was incurred on or after 1 January 2026.”,
              (v) by the deletion of subsections (8), (8A) and (10), and
             (vi) by the insertion of the following subsection after subsection (10):
                  “(11) A claim for relief in accordance with this section may only be made by
                        a person insofar as the aggregate of the claim, when taken together
                        with other de minimis aid received, does not exceed the permissible
                        ceiling of aid to the single undertaking of which the person is a part.”,
          (c) in section 372AAD—
               (i) in subsection (1)—
                      (I) by the deletion of the definition of “property developer”,
                  (II) by the substitution of the following definition for the definition of
                       “eligible expenditure”:
                           “ ‘eligible expenditure’, means, notwithstanding section 279, capital
                           expenditure incurred in the relevant qualifying period on the
                           conversion or the refurbishment of a special qualifying premises after
                           deducting from that amount of expenditure any sum in respect of or by
                           reference to—
                          (a) that expenditure,
                          (b) the special qualifying premises, or


                                                  40
[2025.]                              Finance Act 2025.                        [No. 18.] PT.1 S.30

                     (c) the conversion work, or as the case may be, the refurbishment work
                         in respect of which that expenditure was incurred,
                      which the person has received or is entitled to receive, directly or
                      indirectly, from the State, any board established by statute or any
                      public or local authority, and for the purposes of giving relief under
                      this section, any reference to expenditure being incurred shall include
                      a reference to expenditure deemed under any provision of Part 9 to be
                      incurred;”,
                    and
              (III) in the definition of “relevant qualifying period”, by the substitution of
                    “31 December 2030” for “31 December 2027”,
          (ii) by the deletion of subsection (2),
          (iii) by the substitution of the following subsection for subsection (4):
                “(4) (a) In relation to eligible expenditure incurred before 1 January 2026
                         in the relevant qualifying period on a special qualifying premises,
                         section 272 shall apply as if—
                          (i) in subsection (3)(a)(ii) of that section the reference to 4 per cent
                              were a reference to 15 per cent, and
                          (ii) in subsection (4)(a) of that section the following were
                               substituted for subparagraph (ii):
                                ‘(ii) where capital expenditure on the conversion or
                                      refurbishment of the building or structure is incurred, 7
                                      years beginning with the time when the building or
                                      structure was first used subsequent to the incurring of
                                      that expenditure.’.
                     (b) In relation to eligible expenditure incurred on or after 1 January
                         2026 in the relevant qualifying period on a special qualifying
                         premises, section 272 shall apply as if—
                          (i) in subsection (3)(a)(ii) of that section the reference to 4 per cent
                              were a reference to 50 per cent, and
                          (ii) in subsection (4)(a) of that section the following were
                               substituted for subparagraph (ii):
                                ‘(ii) where capital expenditure on the conversion or
                                      refurbishment of the building or structure is incurred, 10
                                      years beginning with the time when the building or
                                      structure was first used subsequent to the incurring of
                                      that expenditure.’.”,


          (iv) by the substitution of the following subsection for subsection (7):



                                              41
PT.1 S.30 [No. 18.]                     Finance Act 2025.                                 [2025.]

                      “(7) Notwithstanding section 274(1), no balancing allowance or balancing
                           charge shall be made in relation to a special qualifying premises by
                           reason of any event referred to in that section which occurs more
                           than—
                          (a) 7 years after the special qualifying premises was first used
                              subsequent to the incurring of the eligible expenditure on the
                              conversion or refurbishment of the special qualifying premises
                              where that eligible expenditure was incurred before 1 January
                              2026, or
                          (b) 10 years after the special qualifying premises was first used
                              subsequent to the incurring of the eligible expenditure on the
                              conversion or refurbishment of the special qualifying premises
                              where that eligible expenditure was incurred on or after 1 January
                              2026.”,
              (v) by the deletion of subsections (10), (11) and (13), and
             (vi) by the insertion of the following subsection after subsection (13):
                  “(14) A claim for relief in accordance with this section may only be made by
                        a person insofar as the aggregate of that claim, when taken together
                        with other de minimis aid received, does not exceed the permissible
                        ceiling of aid to the single undertaking of which the person is a part.”,
         (d) by the insertion of the following section after section 372AAD:

            “Capital allowances in relation to conversion or refurbishment of certain
            qualifying premises
            372AAE. (1) In this section—

                           ‘conversion’, ‘house’ and ‘letter of certification’ have the same
                           meaning, respectively, as they have in section 372AAB;
                           ‘qualifying expenditure’ means, notwithstanding section 279, capital
                           expenditure incurred by a person in the relevant qualifying period on
                           the conversion or the refurbishment of a qualifying premises after
                           deducting from that amount of expenditure any sum in respect of or by
                           reference to—
                          (a) that expenditure,
                          (b) the qualifying premises, or
                          (c) the conversion work or, as the case may be, the refurbishment work
                              in respect of which that expenditure was incurred,
                           which the person has received or is entitled to receive, directly or
                           indirectly, from the State, any board established by statute or any
                           public or local authority and for the purposes of giving relief under
                           this section, any reference to expenditure being incurred shall include


                                                  42
[2025.]                     Finance Act 2025.                       [No. 18.] PT.1 S.30

              a reference to expenditure deemed under any provision of Part 9 to be
              incurred;
              ‘qualifying premises’ means a building or structure (or part of a
              building or structure)—
             (a) the site of which is wholly within a special regeneration area,
             (b) the entirety of which, before the qualifying expenditure was
                 incurred, was a relevant property liable to rates,
             (c) in respect of which a letter of certification has issued for its
                 conversion or refurbishment, as the case may be, into one or more
                 than one house, and
             (d) which, following the incurring of qualifying expenditure on its
                 conversion or refurbishment, as the case may be, into one or more
                 houses—
                 (i) is, or the relevant portion thereof is, a relevant property not
                     rateable, and
                (ii) the house or houses concerned are let on bona fide commercial
                     terms for such consideration as might be expected to be paid in
                     a letting of the house concerned negotiated on an arm’s length
                     basis;
              ‘rate’ has the meaning assigned to it by section 4 of the Local
              Government Rates and Other Matters Act 2019;
              ‘relevant property’ shall be construed in accordance with Schedule 3 to
              the Valuation Act 2001;
              ‘relevant property not rateable’ means a property specified in
              paragraph 6 of Schedule 4 to the Valuation Act 2001;
              ‘relevant qualifying period’ means the period commencing on 1
              January 2026 and ending on 31 December 2030.
          (2) (a) Subject to paragraph (b) and subsections (3) to (8), the provisions
                  of the Tax Acts relating to the making of allowances or charges in
                  respect of capital expenditure incurred on the construction or
                  refurbishment of an industrial building or structure shall,
                  notwithstanding anything to the contrary in those provisions, apply
                  in relation to qualifying expenditure on a qualifying premises as if
                  the qualifying premises were, at all times at which it is a qualifying
                  premises, an industrial building or structure in respect of which an
                  allowance is to be made for the purposes of income tax or
                  corporation tax, as the case may be, under Chapter 1 of Part 9 by
                  reason of its use for the purpose specified in section 268(1)(a).
             (b) An allowance shall be given by virtue of this subsection in relation
                 to any qualifying expenditure on a qualifying premises only in so


                                     43
PT.1 S.30 [No. 18.]                     Finance Act 2025.                                   [2025.]

                             far as that expenditure is incurred in the relevant qualifying period.
                      (3) In relation to qualifying expenditure incurred in the relevant qualifying
                          period on a qualifying premises, section 272 shall apply as if—
                         (a) in subsection (3)(a)(ii) of that section the reference to 4 per cent
                             were a reference to 50 per cent, and
                         (b) in subsection (4)(a) of that section the following were substituted
                             for subparagraph (ii):
                           ‘(ii) where capital expenditure on the conversion or refurbishment of
                                 the building or structure is incurred, 10 years beginning with the
                                 time when the building or structure was first used subsequent to
                                 the incurring of that expenditure.’.
                      (4) Notwithstanding section 274(1), no balancing allowance or balancing
                          charge shall be made in relation to a qualifying premises by reason of
                          any event referred to in that section which occurs more than 10 years
                          after the qualifying premises was first used subsequent to the incurring
                          of the qualifying expenditure on the conversion or refurbishment of
                          the qualifying premises.
                      (5) This section shall not apply where qualifying expenditure incurred
                          does not exceed €5,000.
                      (6) Relief under this section shall not be given unless the following
                          information is provided to the Revenue Commissioners as part of the
                          first claim made by the person in accordance with subsection (2):
                         (a) the name, address and tax reference number of the person making
                             the claim;
                         (b) the address of the qualifying premises in respect of which the
                             qualifying expenditure was incurred;
                         (c) details of the aggregate of all qualifying expenditure incurred by
                             the person in respect of the qualifying premises.
                      (7) Any information required to be provided to the Revenue
                          Commissioners under this section shall be provided by electronic
                          means and through such electronic systems as the Revenue
                          Commissioners may make available for the time being for any such
                          purpose.
                      (8) For the purposes only of determining, in relation to a claim for an
                          allowance by virtue of subsection (2), whether and to what extent
                          qualifying expenditure incurred on the conversion or refurbishment of
                          a qualifying premises is incurred or not incurred in the relevant
                          qualifying period, only such an amount of that expenditure as is
                          properly attributable to work on the conversion or refurbishment of the
                          qualifying premises actually carried out during the relevant qualifying
                          period shall (notwithstanding any other provision of the Tax Acts as to


                                                44
[2025.]                                  Finance Act 2025.                      [No. 18.] PT.1 S.30

                           the time when any capital expenditure is or is to be treated as incurred)
                           be treated as having been incurred in that period.
                       (9) Where relief is given by virtue of this section in relation to capital
                           expenditure incurred on the conversion or refurbishment of a building
                           or structure, relief shall not be given in respect of that expenditure
                           under any other provision of the Tax Acts.
                   (10) A claim for relief in accordance with this section may only be made by
                        a person insofar as the aggregate of that claim, when taken together
                        with other de minimis aid received, does not exceed the permissible
                        ceiling of aid to the single undertaking of which the person is a part.”,
          (e) in section 409F(2), in paragraph (a) of the definition of “area-based capital
              allowance”, by the substitution of “372AAC, 372AAD or 372AAE” for
              “372AAC or 372AAD”, and
          (f) in Schedule 25B, by insertion of the following after the matter set out opposite
              Reference Number 38C:
             “

                 38D      Section 372AAE (capital          An amount equal to—
                          allowances in relation to
                          conversion or refurbishment of
                          certain qualifying premises)
                                                           (a) the aggregate amount of
                                                               allowances (including balancing
                                                               allowances) made to the individual
                                                               under Chapter 1 of Part 9 as that
                                                               Chapter is applied by section
                                                               372AAE, including any such
                                                               allowance or part of any
                                                               allowances made to the individual
                                                               for a previous tax year and carried
                                                               forward from that previous tax
                                                               year in accordance with Part 9, or
                                                           (b) where full effect has not been
                                                               given in respect of that aggregate
                                                               for that tax year, the part of that
                                                               aggregate to which full effect has
                                                               been given for that tax year in
                                                               accordance with section 278 and
                                                               section 304 or 305, as the case
                                                               may be, or any of those sections as
                                                               applied or modified by any other
                                                               provision of the Tax Acts.
                                                                                                   ”.


Amendment of section 97B of Principal Act (deduction for retrofitting expenditure)
31.   Section 97B of the Principal Act is amended—


                                                 45
PT.1 S.31 [No. 18.]                      Finance Act 2025.                                 [2025.]

          (a) in subsection (1), in the definition of “relevant period”, by the substitution of “31
              December 2028” for “31 December 2025”,
         (b) by the substitution of the following subsection for subsection (4):
                      “(4) Subject to subsections (5) and (6)—
                          (a) where a person chargeable has incurred qualifying expenditure in
                              the year of assessment 2023, 2024 or 2025, that person is entitled,
                              in computing for the purposes of section 97(1) the amount of a
                              surplus or deficiency in respect of the rent from the qualifying
                              premises concerned for the year of assessment following that in
                              which the qualifying expenditure is incurred, to a deduction equal
                              to the relevant amount, and
                          (b) where a person chargeable has incurred qualifying expenditure in
                              the year of assessment 2026 or any subsequent year of assessment,
                              that person is entitled, in computing for the purposes of
                              section 97(1) the amount of a surplus or deficiency in respect of the
                              rent from the qualifying premises concerned for the year of
                              assessment in which the qualifying expenditure is incurred, to a
                              deduction equal to the relevant amount.”,
              and
          (c) by the substitution of the following subsection for subsection (5):
                      “(5) A person chargeable shall not be entitled to a deduction under
                           subsection (4)—
                          (a) for qualifying expenditure incurred in the year of assessment 2023,
                              2024 or 2025, in respect of more than two qualifying premises, and
                          (b) for qualifying expenditure incurred in the year of assessment 2026
                              or any subsequent year of assessment, in respect of more than three
                              qualifying premises.”.


Estimate of tax due
32.   Part 41A of the Principal Act is amended, in Chapter 8, by the insertion of the following
      section after section 959AW:


           “959AX. (1) Where a chargeable person fails to deliver a return in respect of a
                       chargeable period in the prescribed form, on or before the specified
                       return date for the chargeable period, in accordance with section 959I,
                       for income tax or corporation tax, as appropriate, then, without
                       prejudice to any other action which may be taken, a Revenue officer
                       may, subject to subsection (2), at any time estimate the amount of tax
                       payable by the chargeable person in respect of that chargeable period
                       and serve notice in writing on the chargeable person specifying the
                       amount estimated in respect of income tax or corporation tax, as the


                                                 46
[2025.]                               Finance Act 2025.                      [No. 18.] PT.1 S.32

                        case may be, for that chargeable period (in this section referred to as
                        ‘the estimated tax’).
                    (2) For the purposes of subsection (1), the estimated tax, in respect of the
                        chargeable period concerned, shall be the greater of—
                       (a) an amount based on the average amount of tax due that was
                           included on the 2 most recent returns delivered by the chargeable
                           person for income tax or corporation tax, as the case may be, before
                           the service of the notice under subsection (1), or
                       (b) €1,000.
                    (3) The estimated tax specified in the notice served under subsection (1)
                        shall be recoverable in the same manner and by the like proceedings as
                        if the chargeable person had delivered a return in respect of the
                        chargeable period concerned in the prescribed form, on or before the
                        specified return date for that chargeable period to which the notice
                        relates, in accordance with section 959I, for income tax or corporation
                        tax, as appropriate, showing the estimated tax as due by that person.
                    (4) If, within 30 days after the service of a notice under subsection (1), in
                        respect of the chargeable period to which the notice relates, the
                        person—
                       (a) delivers a return to the Revenue Commissioners in respect of that
                           chargeable period and pays the tax due, if any, in accordance with
                           the return, together with any interest, penalties and surcharge which
                           may have been incurred in connection with the tax due, or
                       (b) notifies the Revenue Commissioners in writing that he or she is not
                           a chargeable person in respect of that chargeable period,
                        then, for the purposes of this section, it shall be deemed that no notice
                        was served under subsection (1) and the person may make a claim for
                        repayment in accordance with section 865 of any excess of tax which
                        may have been paid in respect of the chargeable period.”.


Exemption of certain profits or gains arising from cost rental properties
33.   The Principal Act is amended by the insertion of the following section after section 222:


           “222A. (1) In this section—

                        ‘Act of 2021’ means the Affordable Housing Act 2021;
                        ‘cost rental dwelling’ has the same meaning as it has in Part 3 of the
                        Act of 2021;
                        ‘cost rental revocation’ has the same meaning as it has in Part 3 of the
                        Act of 2021;


                                              47
PT.1 S.33 [No. 18.]                     Finance Act 2025.                                  [2025.]

                          ‘Minister’ means the Minister for Housing, Local Government and
                          Heritage;
                          ‘qualifying cost rental dwelling’ means a cost rental dwelling that is
                          first designated as such by the Minister on or after 8 October 2025;
                          ‘qualifying provider’ means a person chargeable in respect of the
                          relevant profits or gains from a qualifying cost rental dwelling;
                          ‘relevant profits or gains’ means the profits or gains, computed as
                          provided for in section 97(1), arising from any rent and receipts from a
                          qualifying cost rental dwelling.

                      (2) Notwithstanding any other provision of this Act—
                         (a) relevant profits or gains arising to a qualifying provider from
                             qualifying cost rental dwellings which, but for this section, would
                             have been chargeable to tax under Case V of Schedule D,
                         (b) any deficiencies, computed in accordance with section 97(1),
                             arising to a qualifying provider in respect of qualifying cost rental
                             dwellings,
                         (c) any reliefs under Chapter 8 of Part 4 that could be claimed by a
                             qualifying provider in respect of qualifying cost rental dwellings,
                             and
                         (d) any allowance that could be made to a qualifying provider, in
                             accordance with Part 9, in respect of qualifying cost rental
                             dwellings,
                          shall be disregarded for all purposes of the Corporation Tax Acts.
                      (3) Notwithstanding subsection (2), as respects the making of a return of
                          income and self assessment which a chargeable person, within the
                          meaning of Part 41A, is required to deliver under Chapter 3 of that
                          Part—
                         (a) the provisions of Part 41A shall apply as if a qualifying provider in
                             receipt of relevant profits or gains in any accounting period were, if
                             such person would not otherwise be, a chargeable person (within
                             the meaning of that Part) for that accounting period,
                         (b) any notice issued to the qualifying provider under section 959N
                             shall be treated as if it had not issued,
                         (c) section 886 shall apply as if the relevant profits or gains received
                             by the qualifying provider were chargeable to corporation tax, and
                         (d) the qualifying provider shall state on the return for the chargeable
                             period—
                            (i) the number of qualifying cost rental dwellings in respect of
                                which the qualifying provider is in receipt of rent and receipts,


                                                48
[2025.]                                Finance Act 2025.                       [No. 18.] PT.1 S.33

                           (ii) the total amount of rent and receipts from the dwellings referred
                                to in subparagraph (i) in the chargeable period, and
                          (iii) the profits or gains that would have been subject to corporation
                                tax if subsection (2) did not apply.
                    (4) For the purposes of subsection (3), the relevant profits or gains,
                        deficiencies, reliefs and allowances in respect of qualifying cost rental
                        dwellings shall be computed in accordance with the Corporation Tax
                        Acts as if subsection (2) had not been enacted.
                    (5) Where the Minister issues a cost rental revocation—
                        (a) the Minister shall notify the Revenue Commissioners in writing of
                            the following:
                            (i) that a cost rental revocation has been issued in respect of the
                                qualifying cost rental dwelling concerned;
                           (ii) the address of the dwelling referred to in subparagraph (i);
                          (iii) the date on which the cost rental revocation was sealed by the
                                Minister,
                        (b) subsection (2) shall not apply to the profits or gains, losses and
                            reliefs arising in respect of the dwelling referred to in paragraph (a)
                            (i) on or after the date referred to in paragraph (a)(iii), and
                        (c) where an allowance under Part 9 for any accounting period would
                            have been due but for subsection (2)(d), the amount due shall be
                            deemed to have been granted.”.


Amendment of Schedule 4 to Principal Act (Exemption of Specified Non-Commercial
State Sponsored Bodies from Certain Tax Provisions)
34.   Schedule 4 to the Principal Act is amended by the insertion of the following paragraph
      after paragraph 84A:
                         “84B. Property Services Regulatory Authority.”.


Amendment of Chapter 2 of Part 29 of Principal Act (scientific and certain other
research)
35. (1) Chapter 2 of Part 29 of the Principal Act is amended—
          (a) in section 766, by the insertion of the following subsection after subsection (1A):
                  “(1B) For the purposes of this section and section 766C—
                        (a) Where expenditure is incurred by a company on emoluments paid
                            to an employee of the company who performs not less than 95 per
                            cent of the duties of his or her employment in the carrying on by
                            the company of research and development activities, 100 per cent
                            of that expenditure shall be treated for the purposes of the

                                               49
PT.1 S.35 [No. 18.]                      Finance Act 2025.                                      [2025.]

                              definition, in subsection (1)(a), of ‘expenditure on research and
                              development’, as expenditure incurred by the company wholly and
                              exclusively in the carrying on by it of research and development
                              activities, save where the expenditure is incurred by a company
                              which is resident in the State and where that expenditure—
                              (i) may be taken into account as an expense in computing income
                                  of that company,
                             (ii) is expenditure in respect of which an allowance for capital
                                  expenditure may be made to that company, or
                            (iii) may otherwise be allowed or relieved in relation to that
                                  company,
                              for the purposes of tax in a territory other than the State.
                          (b) In this subsection, ‘emoluments’ and ‘employee’ have the meaning
                              given to them, respectively, by section 983.”,
         (b) in section 766A—
               (i) in subsection (1)(a), in the definition of “relevant expenditure”, by the
                   insertion of “or being expenditure of the type referred to in subsection (1A)”
                   after “Part 9”, and
              (ii) by the insertion of the following subsection after subsection (1):
                  “(1A) For the purposes of the definition, in subsection (1)(a), of ‘relevant
                        expenditure’, expenditure incurred by a company on the construction
                        of a qualifying building shall include expenditure incurred by the
                        company on the construction of a laboratory for use in the carrying on
                        of research and development activities but does not include
                        expenditure—
                          (a) to which section 765(1)(a)(ii) applies, or
                          (b) which is incurred on the construction of any part of the laboratory
                              for use as an office or for any purpose ancillary to the purpose of an
                              office.”,
          (c) in section 766C—
               (i) in subsection (1), by the substitution of “35 per cent” for “30 per cent”,
              (ii) in subsection (2)(a)(ii), by the substitution of “subsection (7)(a)(i)” for
                   “subsection (7)(a)”,
             (iii) in subsection (6)(a)(i), by the substitution of “€87,500” for “€75,000”,
             (iv) by the substitution of the following subsection for subsection (7):
                      “(7) (a) The company shall specify in respect of each instalment referred to
                               in subsection (6) whether such amounts, or any portion of such
                               amounts, are to be—


                                                 50
[2025.]                             Finance Act 2025.                        [No. 18.] PT.1 S.35

                        (i) treated as an overpayment of tax, for the purposes of
                            section 960H, or
                        (ii) paid to the company by the Revenue Commissioners.
                    (b) Subject to paragraph (c), the company shall make the specification
                        referred to in paragraph (a)—
                        (i) in respect of the first instalment, in the return referred to in
                            subsection (9),
                        (ii) in respect of the second instalment, if any, in the return that the
                             company is required to file under Part 41A in respect of the
                             accounting period (in this paragraph referred to as ‘the
                             first-mentioned accounting period’) immediately succeeding the
                             accounting period in respect of which the claim was made, and

                       (iii) in respect of the third instalment, if any, in the return that the
                             company is required to file under Part 41A in respect of the
                             accounting period immediately succeeding the first-mentioned
                             accounting period.
                    (c) Where, in relation to an accounting period, a company makes a
                        claim in respect of the credit in accordance with subsection (9) (in
                        this paragraph referred to as ‘the first-mentioned claim’), and a
                        second or third instalment is payable in accordance with
                        subsection (11) in respect of a claim for the credit made in an
                        earlier accounting period, the company may make the specification
                        referred to in paragraph (a) in respect of the second or third
                        instalment, or both, as the case may be, on the making of the
                        first-mentioned claim.”,
           (v) in subsection (7A), by the substitution of “subsection (7)(a)(i) or paid to the
               company in accordance with subsection (7)(a)(ii)” for “subsection (7)(a) or
               paid to the company in accordance with subsection (7)(b)”,
          (vi) in subsection (10)(a), by the substitution of “subsection (7)(a)(i) or paid to the
               company under subsection (7)(a)(ii)” for “subsection (7)(a) or paid to the
               company under subsection (7)(b)”,
          (vii) in subsection (11)(c), by the substitution of the following subparagraph for
                subparagraph (i):
                       “(i) where the first-mentioned accounting period is for a period of
                            12 months and the accounting period (in this subparagraph
                            referred to as ‘the second-mentioned accounting period’)
                            immediately succeeding the first-mentioned accounting period
                            is for a period of 12 months, on the filing of the return that the
                            company is required to file under Part 41A for the second-
                            mentioned accounting period, or”,



                                             51
PT.1 S.35 [No. 18.]                      Finance Act 2025.                                      [2025.]

            (viii) in subsection (13), by the substitution of “subsection (7)(a)(i)” for
                   “subsection (7)(a)”, and
             (ix) in subsection (15), by the substitution of “subsection (7)(a)(i) or to be paid
                  under subsection (7)(a)(ii)” for “subsection (7)(a) or to be paid under
                  subsection (7)(b)”,
              and
         (d) in section 766D—
               (i) in subsection (1), by the substitution of “35 per cent” for “30 per cent”,
              (ii) in subsection (2)(a)(ii), by the substitution of “subsection (6)(a)(i)” for
                   “subsection (6)(a)”,
             (iii) in subsection (3A)(c)(II), by the substitution of “subsection (6)(a)(i) or paid to
                   the company in accordance with subsection (6)(a)(ii)” for “subsection (6)(a) or
                   paid to the company in accordance with subsection (6)(b)”,
             (iv) by the substitution of the following subsection for subsection (6):
                      “(6) (a) The company shall specify in respect of each instalment referred to
                               in subsection (5) whether such amounts, or any portion of such
                               amounts, are to be—
                              (i) treated as an overpayment of tax, for the purposes of
                                  section 960H, or
                             (ii) paid to the company by the Revenue Commissioners.
                          (b) Subject to paragraph (c), the company shall make the specification
                              referred to in paragraph (a)—
                              (i) in respect of the first instalment, in the return referred to in
                                  subsection (8),
                             (ii) in respect of the second instalment, if any, in the return that the
                                  company is required to file under Part 41A in respect of the
                                  accounting period (in this paragraph referred to as ‘the
                                  first-mentioned accounting period’) immediately succeeding the
                                  accounting period in respect of which the claim was made, and
                            (iii) in respect of the third instalment, if any, in the return that the
                                  company is required to file under Part 41A in respect of the
                                  accounting period immediately succeeding the first-mentioned
                                  accounting period.
                          (c) Where, in relation to an accounting period, a company makes a
                              claim in respect of the credit in accordance with subsection (8) (in
                              this paragraph referred to as ‘the first-mentioned claim’), and a
                              second or third instalment is payable in accordance with
                              subsection (10) in respect of a claim for the credit made in an
                              earlier accounting period, the company may make the specification


                                                 52
[2025.]                                 Finance Act 2025.                       [No. 18.] PT.1 S.35

                             referred to in paragraph (a) in respect of the second or third
                             instalment, or both, as the case may be, on the making of the
                             first-mentioned claim.”,
               (v) in subsection (9)(a), by the substitution of “subsection (6)(a)(i) or paid to the
                   company under subsection (6)(a)(ii)” for “subsection (6)(a) or paid to the
                   company under subsection (6)(b)”,
              (vi) in subsection (10)(c), by the substitution of the following subparagraph for
                   subparagraph (i):
                           “(i) where the first-mentioned accounting period is for a period of
                                12 months and the accounting period (in this subparagraph
                                referred to as ‘the second-mentioned accounting period’)
                                immediately succeeding the first-mentioned accounting period
                                is for a period of 12 months, on the filing of the return that the
                                company is required to file under Part 41A for the
                                second-mentioned accounting period, or”,
             (vii) in subsection (12), by the substitution of “subsection (6)(a)(i)” for
                   “subsection (6)(a)”, and
             (viii) in subsection (14), by the substitution of “subsection (6)(a)(i) or to be paid
                    under subsection (6)(a)(ii)” for “subsection (6)(a) or to be paid under
                    subsection (6)(b)”.
      (2) (a) Paragraph (a), subparagraphs (i) and (iii) of paragraph (c) and subparagraph (i)
              of paragraph (d) of subsection (1) shall apply in respect of any accounting period
              the specified return date (within the meaning of Part 41A) of which is on or after
              23 September 2027.
          (b) Paragraph (b) of subsection (1) shall apply on and from the date of the passing of
              this Act.
          (c) Subparagraphs (ii), (iv), (v), (vi), (viii) and (ix) of paragraph (c) and
              subparagraphs (ii), (iii), (iv), (v), (vii) and (viii) of paragraph (d) of
              subsection (1) shall apply in respect of accounting periods ending on or after 31
              December 2025.
          (d) Paragraph (c)(vii) of subsection (1) shall apply in respect of instalments payable
              in accordance with section 766C on and from the date of the passing of this Act.
          (e) Paragraph (d)(vi) of subsection (1) shall apply in respect of instalments payable
              in accordance with section 766D on and from the date of the passing of this Act.


Taxation of certain foreign body corporates
36.    Part 43 of the Principal Act is amended by the insertion of the following section after
       section 1009:
             “1009A. Notwithstanding any provision of the Tax Acts or the Capital Gains Tax
                     Acts, as the case may be, a body corporate and each of its members shall
                     be chargeable to tax or capital gains tax, as the case may be, on their

                                                53
PT.1 S.36 [No. 18.]                     Finance Act 2025.                                     [2025.]

                      respective income, profits or gains on the basis that the body corporate is
                      a partnership and each of its members are partners in a partnership
                      where—
                        (a) the body corporate is incorporated, or formed, under the laws of a
                            jurisdiction other than the State, and
                        (b) having regard to the characteristics of that body corporate and the
                            rights and obligations of each of its members, the body corporate is
                            substantially similar to a partnership formed under the law of the
                            State.”.


Life assurance policies and investment funds
37. (1) The Principal Act is amended—
          (a) in section 730F(1)(a)(ii), by the substitution of “38 per cent” for “41 per cent”,
         (b) in section 730J(a)(i)(II), by the substitution of “38 per cent” for “41 per cent”,
          (c) in section 730K(1)(a)(ii), by the substitution of “38 per cent” for “41 per cent”,
         (d) in section 739D(5A), in the formula in paragraph (b), by the substitution of “(G x
             38)” for “(G x 41)”,
          (e) in section 739E(1)—
               (i) in paragraph (a)(ii), by the substitution of “38 per cent” for “41 per cent”, and
              (ii) in paragraph (b)(ii), by the substitution of “38 per cent” for “41 per cent”,
          (f) in section 747D(a)(i)(II), by the substitution of “38 per cent” for “41 per cent”,
              and
          (g) in section 747E(1)(b)(ii), by the substitution of “38 per cent” for “41 per cent”.
     (2) (a) Subsection (1)(a) applies and has effect as respects the happening of a chargeable
             event in relation to a life policy (within the meaning of Chapter 5 of Part 26 of
             the Principal Act) on or after 1 January 2026.
         (b) Subsection (1)(b) applies and has effect as respects the receipt by a person of a
             payment in respect of a foreign life policy (within the meaning of Chapter 6 of
             Part 26 of the Principal Act) on or after 1 January 2026.
          (c) Subsection (1)(c) applies and has effect as respects the disposal in whole or in
              part of a foreign life policy (within the meaning of Chapter 6 of Part 26 of the
              Principal Act) on or after 1 January 2026.
         (d) Subsection (1)(d) and (e) apply and have effect as respects the happening of a
             chargeable event in relation to an investment undertaking (within the meaning of
             section 739B(1) of the Principal Act) on or after 1 January 2026.
          (e) Subsection (1)(f) applies and has effect as respects the receipt by a person of a
              payment in respect of a material interest in an offshore fund (within the meaning
              of Chapter 4 of Part 27 of the Principal Act) on or after 1 January 2026.


                                                 54
[2025.]                                Finance Act 2025.                        [No. 18.] PT.1 S.37

          (f) Subsection (1)(g) applies and has effect as respects the disposal in whole or in
              part by a person of a material interest in an offshore fund (within the meaning of
              Chapter 4 of Part 27 of the Principal Act) on or after 1 January 2026.


Amendment of section 731 of Principal Act (chargeable gains accruing to unit trusts)
38. (1) Section 731 of the Principal Act is amended, in subsection (5)(a)(i), by the
        substitution of “(otherwise than by reason of residence, by virtue of section 739(3) or
        by virtue of section 739C(1))” for “(otherwise than by reason of residence or by virtue
        of section 739(3))”.
     (2) Subsection (1) shall apply for the year of assessment 2026 and each subsequent year
         of assessment.


Exemption from dividend withholding tax for certain investment limited partnerships
39. (1) Part 6 of the Principal Act is amended—
          (a) in section 172A(1)(a), by the insertion of the following definitions:
                         “ ‘equivalent partnership’ means a partnership which would be an
                         investment limited partnership but for the fact that it is authorised by
                         an EEA state other than the State and is subject to such supervisory
                         and regulatory arrangements in the EEA state by which it is authorised
                         at least equivalent to those applied to an investment limited
                         partnership;
                         ‘investment limited partnership’ means a partnership authorised in
                         accordance with the Investment Limited Partnerships Act 1994;”,
              and
          (b) in section 172C—
               (i) in subsection (2), by the insertion of the following paragraph after
                   paragraph (db):
                      “(dc) subject to subsection (4), an investment limited partnership or
                            equivalent partnership, as the case may be, where—
                            (i) the partners of the investment limited partnership or equivalent
                                partnership are beneficially entitled to not less than 51 per cent
                                of the ordinary share capital of the company making the relevant
                                distribution,
                           (ii) the ordinary share capital of the company making the relevant
                                distribution is an asset of that investment limited partnership or
                                equivalent partnership, and
                          (iii) that investment limited partnership or equivalent partnership has
                                made a declaration, to the company making the relevant
                                distribution, in relation to the relevant distribution in accordance
                                with paragraph 14 of Schedule 2A,”,

                                               55
PT.1 S.39 [No. 18.]                       Finance Act 2025.                                    [2025.]

              (ii) in subsection (3)—
                      (I) in paragraph (d), by the deletion of “and”,
                  (II) in paragraph (e), by the substitution of “PEPP assets, and” for “PEPP
                       assets,”, and
                 (III) by the insertion of the following paragraph after paragraph (e):
                          “(f) an investment limited partnership or equivalent partnership, as the
                               case may be, which receives a relevant distribution,”,
                  and
             (iii) in subsection (4), by the substitution of “paragraph (bd) or (dc) of
                   subsection (2)” for “subsection (2)(bd)”.
     (2) Section 739J of the Principal Act is amended by the insertion of the following
         subsection after subsection (3A):
                  “(3B) A statement made under subsection (3) shall be treated as if it satisfies
                        the requirements in respect of the making of a return under
                        section 880, 959I or 959M, as the case may be.”.
     (3) Schedule 2A of the Principal Act is amended by the insertion of the following
         paragraph after paragraph 13:
                      “Declaration to be made by investment limited partnership or equivalent
                              partnership under section 172C(2)(dc)
                       14. The declaration referred to in section 172C(2)(dc) shall be a
                           declaration in writing to the company making the relevant distribution
                           in relation to the relevant distributions which—
                            (a) is made by the person (in this paragraph referred to as ‘the
                                declarer’) beneficially entitled to the relevant distributions in
                                respect of which the declaration is made,
                            (b) is signed by the declarer,
                            (c) is made in such form as may be prescribed or authorised by the
                                Revenue Commissioners,
                            (d) declares that, at the time when the declaration is made, the person
                                beneficially entitled to the relevant distributions is an investment
                                limited partnership or equivalent partnership,
                            (e) contains the name and tax reference number of the investment
                                limited partnership or equivalent partnership,
                            (f) contains an undertaking by the declarer that, if the person
                                mentioned in subparagraph (d) ceases to be an excluded person,
                                the declarer will, by notice in writing, advise the company
                                resident in the State in relation to the relevant distributions
                                accordingly, and


                                                  56
[2025.]                                Finance Act 2025.                        [No. 18.] PT.1 S.39

                         (g) contains such other information as the Revenue Commissioners
                             may reasonably require for the purposes of Chapter 8A of Part 6.”.
     (4) (a) Subsection (1) and (3) shall apply in respect of a relevant distribution (within the
             meaning of section 172A of the Principal Act) made on or after 1 January 2026.
          (b) Subsection (2) shall apply for the year of assessment 2026 and each subsequent
              year.


Amendment to section 835AVB of Principal Act (collective investment scheme)
40. (1) Section 835AVB of the Principal Act is amended—
          (a) in subsection (1)—
              (i) by the insertion of the following definitions:
                        “ ‘EEA Agreement’ means the Agreement on the European Economic
                        Area signed at Oporto on 2 May 1992, as adjusted by all subsequent
                        amendments to that Agreement;
                        ‘EEA state’ means a state which is a contracting party to the EEA
                        Agreement;
                        ‘foreign tax’, in relation to a relevant territory, means a tax which—
                        (a) corresponds to corporation tax in the State,
                       (b) generally applies to income, profits and gains arising to a company
                           that is resident for the purposes of tax in that territory, and
                        (c) is imposed at a nominal rate greater than zero per cent;
                        ‘investment limited partnership’ means a partnership authorised in
                        accordance with the Investment Limited Partnerships Act 1994;
                        ‘listed territory’ has the same meaning as it has in section 835YA;
                        ‘relevant company’, in relation to an investment limited partnership,
                        means a company—
                        (a) which is a direct or indirect asset of the investment limited
                            partnership,
                       (b) in which the partners of the investment limited partnership are
                           beneficially entitled, directly or indirectly, to not less than 95 per
                           cent of its ordinary share capital,
                        (c) whose business consists of the holding, directly or indirectly, of a
                            diversified portfolio of assets, and
                       (d) which is—
                           (i) resident in the State, or
                           (ii) by virtue of the law of a relevant territory, is—


                                               57
PT.1 S.40 [No. 18.]                       Finance Act 2025.                                    [2025.]

                                  (I) resident for the purposes of foreign tax in the relevant
                                      territory, and
                                 (II) not generally exempt from foreign tax;
                           ‘relevant territory’ means—
                           (a) an EEA state, other than the State,
                          (b) not being such an EEA state, a territory with the government of
                              which arrangements having the force of law by virtue of
                              section 826(1) have been made, or
                           (c) not being a territory referred to in paragraph (a) or (b), a territory
                               with the government of which arrangements have been made which
                               on completion of the procedures set out in section 826(1) will have
                               the force of law,


                           but does not include a listed territory;”,
                  and
              (ii) in paragraph (b) of the definition of “relevant investment undertaking”, by the
                   deletion of “, within the meaning of section 739J”,
         (b) in subsection (4)(a), by the substitution of “20 per cent” for “10 per cent”, and
          (c) by the insertion of the following subsection after subsection (4):
                  “(4A) In the case of an investment limited partnership, for the purposes of
                        subsection (4)(a)—
                           (a) a relevant company shall not be considered to be an issuer of
                               securities to the investment limited partnership, and
                          (b) an investment limited partnership shall be deemed to hold directly
                              any securities held by a relevant company.”.
     (2) Subsection (1) shall apply for the year of assessment 2026 and each subsequent year.


Amendments relating to group payments
41. (1) The Principal Act is amended—
          (a) in section 410—
               (i) in subsection (1)(a)—
                      (I) by the substitution of the following definition for the definition of “tax”:
                               “ ‘tax’, in relation to a relevant territory other than the State, means
                               any tax imposed in the relevant territory which corresponds to
                               corporation tax in the State;”,
                         and


                                                  58
[2025.]                                  Finance Act 2025.                      [No. 18.] PT.1 S.41

                    (II) by the insertion of the following definition:
                              “ ‘relevant territory’ means—
                             (i) a relevant Member State,
                            (ii) not being a territory referred to in subparagraph (i), a territory
                                 with the government of which arrangements having the force of
                                 law by virtue of section 826(1) have been made, or
                            (iii) not being a territory referred to in subparagraph (i) or (ii), a
                                  territory with the government of which arrangements have been
                                  made which on completion of the procedures set out in
                                  section 826(1) will have the force of law;”,
              (ii) in subsection (1)(b)—
                    (I) in subparagraph (i), by the substitution of “relevant territory” for
                        “relevant Member State”, and
                    (II) by the substitution of the following subparagraph for subparagraph (ii):
                           “(ii) references to—
                                 (I) a company resident in a relevant Member State shall be
                                     construed as references to a company which, by virtue of the
                                     law of a relevant Member State, is resident for the purposes
                                     of tax in such a relevant Member State, and
                                (II) a company resident in a relevant territory shall be construed
                                     as references to a company which, by virtue of the law of a
                                     relevant territory, is resident for the purposes of tax in such
                                     a relevant territory.”,
             (iii) in subsection (3)(a), by the substitution of “relevant territory” for “relevant
                   Member State”, and
             (iv) in subsection (4)(a)(i), by the substitution of “relevant territory” for “relevant
                  Member State”,
              and
          (b) in section 243(5)(c), by the substitution of “section 242A, 267I or 410(4)” for
              “section 242A or 267I”.
      (2) Subsection (1) shall apply to payments to which section 410 of the Principal Act
          applies made on or after the date of the passing of this Act.

                                             CHAPTER 5

                                         Corporation Tax


Enhanced deduction for eligible construction expenditure
42.   The Principal Act is amended by the insertion of the following section after section 81D:


                                                  59
PT.1 S.42 [No. 18.]                   Finance Act 2025.                                 [2025.]

              “81E. (1) In this section—
                        ‘apartment’ means a separate and self-contained dwelling in a
                        qualifying apartment block—
                       (a) that has sleeping facilities, bathroom facilities and cooking
                           facilities within it for the exclusive use of the occupant of the
                           dwelling concerned, and
                       (b) other than where the dwelling is situated on the ground floor of a
                           multi-storey building, access to the dwelling is grouped or in
                           common with other separate and self-contained dwellings;
                        ‘certificate of compliance on completion’, ‘commencement notice’,
                        ‘local authority’, ‘planning permission’ and ‘planning permission
                        period’ have the same meaning, respectively, as they have in section
                        653A(1);
                        ‘completed development’ means a qualifying apartment block, in
                        respect of which—
                       (a) planning permission has been granted which includes permission
                           for not fewer than 10 new apartments in the qualifying apartment
                           block,
                       (b) a relevant commencement notice is lodged with the relevant local
                           authority on or after 8 October 2025 but not later than 31 December
                           2030, and
                       (c) on or before the expiry of the planning permission period relating
                           to it—
                          (i) all works required to ensure that all apartments in the qualifying
                              apartment block are suitable for occupation as a dwelling have
                              been completed, and
                          (ii) a relevant certificate of compliance on completion is lodged
                               with the relevant local authority;
                        ‘construction operations’ and ‘excepted trade’ have the same meaning,
                        respectively, as they have in section 21A;
                        ‘eligible expenditure’, in relation to a completed development, means,
                        subject to subsection (8), expenditure incurred by a relevant person in
                        connection with construction operations carried out in respect of the
                        completed development, being expenditure which is incurred up to the
                        relevant date, excluding—
                       (a) any capital expenditure so incurred, and
                       (b) ineligible expenditure;
                        ‘enhanced deduction’ has the meaning given to it by subsection (4);
                        ‘ineligible expenditure’, in relation to a completed development,


                                              60
[2025.]                  Finance Act 2025.                          [No. 18.] PT.1 S.42

          means any expenditure incurred by a relevant person in respect of the
          completed development in respect of any or all of the following:
          (a) financing costs;
          (b) insurance costs;
          (c) professional and legal fees;
          (d) sales and marketing costs;
          (e) taxes, duties, levies or charges under the care and management of
              the Revenue Commissioners;
          (f) the acquisition of, or rights in or over, any land;
          (g) levies, fees, charges or contributions imposed by, or under, any
              enactment in respect of the completed development concerned,
              however described in the relevant enactment, including any—
             (i) development contributions,
             (ii) utility connection charges,
            (iii) environmental levies,
            (iv) planning application fees,
             (v) building control fees, or
            (vi) building energy rating fees;
          ‘land’ includes any interest in land;
          ‘material change’ shall be construed in accordance with subsection (2);
          ‘property developer’ means a company carrying on a relevant property
          development trade;
          ‘qualifying apartment block’ means a building that—
          (a) is a multi-storey building,
          (b) is principally comprised of not fewer than 10 apartments, and
          (c) is—
             (i) a newly erected building, or
             (ii) not being a building referred to in subparagraph (i), a building
                  that meets the requirements of paragraphs (a) and (b) as a result
                  of a material change,
          and includes an area of land for occupation and enjoyment by its
          occupants with the building as its gardens or grounds;
          ‘qualifying refurbishment’ means any work of construction,
          reconstruction, restoration, repair or renewal, including the provision
          or improvement of water, sewerage or heating facilities, carried out on

                                 61
PT.1 S.42 [No. 18.]                 Finance Act 2025.                                [2025.]

                      a building or structure, or part of a building or structure;
                      ‘qualifying trade’, in relation to a relevant contractor, means a trade
                      carried out by the relevant contractor, which—
                      (a) is not an excepted trade, and
                      (b) consists wholly or mainly of the construction or refurbishment of
                          buildings or structures;
                      ‘relevant accounting period’ means the accounting period in which the
                      relevant certificate of compliance on completion in respect of a
                      completed development is lodged with the relevant local authority;
                      ‘relevant beneficial owner’ means a beneficial owner of a completed
                      development that is not a relevant person in respect of that completed
                      development;
                      ‘relevant certificate of compliance on completion’ means a certificate
                      of compliance on completion lodged with the relevant local authority
                      or, where there is more than one such certificate of compliance on
                      completion, the last such certificate of compliance on completion so
                      lodged, in respect of a completed development;
                      ‘relevant commencement notice’ means a commencement notice
                      lodged with the relevant local authority or, where there is more than
                      one such commencement notice, the first such commencement notice
                      so lodged, in respect of a completed development;
                      ‘relevant contractor’, in relation to a completed development, means a
                      company that develops the completed development pursuant to a
                      contract entered into with the beneficial owner, or where there is more
                      than one beneficial owner, the beneficial owners, of that completed
                      development;
                      ‘relevant date’, in relation to a completed development, means the date
                      on which the relevant certificate of compliance on completion is
                      lodged with the relevant local authority in respect of that completed
                      development;
                      ‘relevant declaration’ means a declaration that is made under and in
                      accordance with subsection (3);
                      ‘relevant local authority’, in relation to a completed development,
                      means the local authority in whose functional area the completed
                      development is situated;
                      ‘relevant person’ means—
                      (a) a property developer that—
                         (i) in the course of a relevant property development trade, develops
                             a completed development, and



                                             62
[2025.]                     Finance Act 2025.                     [No. 18.] PT.1 S.42

                (ii) on the relevant date is a beneficial owner of the completed
                     development,
                 or
             (b) a relevant contractor—
                (i) that, in the course of a qualifying trade, develops a completed
                    development, and
                (ii) to which a relevant declaration has been made by a relevant
                     beneficial owner, or where there is more than one relevant
                     beneficial owner, a relevant declaration has been made by each
                     relevant beneficial owner, in respect of that completed
                     development;
              ‘relevant property development trade’, in relation to a property
              developer, means a trade carried out by the property developer,
              which—
             (a) is not an excepted trade, and
             (b) consists wholly or mainly of the construction or refurbishment of
                 buildings or structures with a view to their sale.
          (2) For the purposes of this section, there is a material change where,
              following a qualifying refurbishment, a building or part of a building,
              or a structure or part of a structure—
             (a) although not originally constructed for occupation as a dwelling, or
             (b) although originally constructed for occupation as a dwelling, was
                 not suitable for use as a dwelling or has been appropriated to other
                 purposes,
              becomes suitable for use as a dwelling.
          (3) (a) Where, on the relevant date, a completed development is
                  beneficially owned by a relevant beneficial owner, then—
                (i) the relevant beneficial owner, or
                (ii) where there is more than one relevant beneficial owner, each
                     relevant beneficial owner,
                 may make a declaration in accordance with paragraph (c) to a
                 relevant contractor for the purposes of the relevant contractor
                 making a claim for an enhanced deduction under this section.
             (b) A relevant declaration shall not be made to more than one relevant
                 contractor in respect of a completed development and, where a
                 relevant declaration is made to more than one relevant contractor in
                 respect of the same completed development, it shall be deemed that
                 no relevant declaration has been made to any relevant contractor in
                 respect of that completed development.


                                    63
PT.1 S.42 [No. 18.]                  Finance Act 2025.                                  [2025.]

                      (c) A relevant declaration shall be a declaration in writing to a relevant
                          contractor which—
                         (i) is made by a relevant beneficial owner of a completed
                             development (in this paragraph referred to as ‘the declarer’) for
                             the purposes of the relevant contractor making a claim for an
                             enhanced deduction under this section,
                        (ii) is signed by the declarer,
                        (iii) is made in such form as may be prescribed or authorised by the
                              Revenue Commissioners,
                        (iv) declares—
                             (I) that on the relevant date the declarer is a relevant beneficial
                                 owner of the completed development and the percentage of
                                 the completed development of which the declarer is a
                                 relevant beneficial owner on the relevant date,
                            (II) that the relevant contractor developed the completed
                                 development pursuant to a contract entered into by the
                                 declarer and the relevant contractor,
                           (III) that the declarer is not a relevant person,
                             and
                         (v) contains—
                             (I) the name, address and tax reference number of the declarer
                                 and relevant contractor,
                            (II) the address of the completed development and the number
                                 of apartments in the completed development, and
                           (III) such other information as the Revenue Commissioners may
                                 reasonably require for the purposes of this section.
                      (d) Where, in respect of a completed development—
                         (i) a relevant declaration is made by the relevant beneficial owner,
                             or
                        (ii) where there is more than one relevant beneficial owner, a
                             relevant declaration is made by each relevant beneficial owner,
                          to a relevant contractor, then, for the purposes of this section, the
                          relevant contractor shall be deemed to be the beneficial owner, on
                          the relevant date, of the percentage of the completed development
                          beneficially owned on the relevant date by each relevant beneficial
                          owner, who makes the relevant declaration.
                      (e) A relevant contractor to which a relevant declaration has been made
                          shall keep and retain the relevant declaration for a period of 6 years


                                             64
[2025.]                     Finance Act 2025.                       [No. 18.] PT.1 S.42

                  from the end of the accounting period in which a return has been
                  delivered making a claim under this section in respect of the
                  completed development to which the relevant declaration relates.

          (4) Where—
             (a) a relevant person has incurred eligible expenditure in respect of a
                 completed development, and
             (b) the relevant person is, in the computation of the amount of the
                 profits or gains of a relevant property development trade or a
                 qualifying trade, as the case may be, to be charged to corporation
                 tax under Case I of Schedule D for an accounting period, entitled to
                 any deduction on account of eligible expenditure in respect of the
                 completed development,
              then, the relevant person shall, on the making of a claim, be entitled, in
              the computation of the amount of the profits or gains of that trade for
              the relevant accounting period, to a further deduction (in this section
              referred to as an ‘enhanced deduction’) equal to the amount
              determined under subsection (5).
          (5) Subject to subsections (6) and (7), the amount of the enhanced
              deduction in respect of a completed development shall be equal to the
              amount determined by the formula—

                                          A x 25%

              where—
              A    is the amount of eligible expenditure incurred by the relevant
                   person in respect of the completed development in respect of
                   which the relevant person is entitled to a deduction in the
                   computation of the amount of the profits or gains of a relevant
                   property development trade or a qualifying trade, as the case may
                   be, to be charged to corporation tax under Case I of Schedule D
                   for an accounting period.
          (6) The amount of the enhanced deduction in respect of a completed
              development shall not exceed the amount determined by the formula—

                                          BxCxD

              where—
              B    is the number of apartments in the completed development,
              C    is €50,000, and
              D    is the percentage of the completed development that is
                   beneficially owned by the relevant person, or in the case of a
                   relevant person who is a relevant contractor is deemed, by virtue


                                     65
PT.1 S.42 [No. 18.]                      Finance Act 2025.                                 [2025.]

                                of subsection (3)(d), to be beneficially owned by the relevant
                                person, on the relevant date.
                       (7) Any amount of eligible expenditure incurred by a relevant person in
                           respect of a completed development which—
                          (a) has been or is to be met, directly or indirectly, by grant assistance
                              or any other assistance which is granted by or through the State,
                              any board established by statute, any public or local authority or
                              any other agency of the State,
                          (b) exceeds the amount which would be payable between independent
                              persons acting at arm’s length in a transaction similar to that in
                              respect of which the expenditure was incurred, or
                          (c) is incurred as part of a scheme or arrangement, where it is
                              reasonable to consider that the main purpose, or one of the main
                              purposes, is the avoidance of, or reduction in, liability to tax,
                           shall, in calculating the amount of the enhanced deduction in respect
                           of a completed development, be excluded from the amount represented
                           by ‘A’ in the formula in subsection (5).
                       (8) Where expenditure is incurred by a relevant person in connection with
                           construction operations in respect of both a completed development
                           and a development that is not a completed development, such
                           expenditure shall be apportioned by the relevant person on a just and
                           reasonable basis.
                       (9) (a) A claim under this section shall be made by a relevant person
                               within 12 months from the end of the relevant accounting period to
                               which the claim relates and shall be made in the return filed under
                               Part 41A, in respect of that accounting period.
                          (b) The relevant person shall, when making a claim in accordance with
                              paragraph (a), provide details of—
                              (i) the eligible expenditure incurred in relation to the completed
                                  development and in respect of which the relevant person is
                                  claiming an enhanced deduction,
                             (ii) the number of apartments in the completed development, and
                             (iii) such other information as the Revenue Commissioners may
                                   reasonably require for the purposes of this section.
                      (10) (a) Where, in computing for tax purposes the profits of a relevant
                               property development trade or a qualifying trade, as the case may
                               be, an enhanced deduction has been claimed by a relevant person
                               and, in computing that deduction, a debt incurred by the relevant
                               person was included in the amount of eligible expenditure, then, if
                               the whole or any part of that debt is thereafter released, an amount
                               equal to the portion of the enhanced deduction which was


                                                 66
[2025.]                                Finance Act 2025.                       [No. 18.] PT.1 S.42

                            determined based on the amount released (in this subsection
                            referred to as the ‘disallowed deduction’) shall be treated as a
                            receipt of the relevant property development trade or a qualifying
                            trade, as the case may be, arising in the period in which the release
                            is effected.
                        (b) Where paragraph (a) applies, and the trade concerned has been
                            permanently discontinued at or after the end of the period for which
                            the enhanced deduction was claimed and before the release was
                            effected, or is treated for tax purposes as if it had been so
                            discontinued, section 91 shall apply as if the disallowed deduction
                            were a sum received after the discontinuance.”.


Amendment of section 291A of Principal Act (intangible assets)
43. (1) Section 291A of the Principal Act is amended—
          (a) in subsection (6)—
              (i) in paragraph (a), by the substitution of the following subparagraph for
                  subparagraph (i):
                          “(i) any allowances to be made to a company under section 284 as
                               applied by this section, and any balancing allowances (within
                               the meaning of section 288) to be made to a company in respect
                               of a specified intangible asset or specified intangible assets,
                               and”,
                  and
              (ii) in paragraph (b)—
                  (I) in subparagraph (i), by the substitution of “in this subparagraph and
                      subparagraph (ia)” for “in this subparagraph”, and
                  (II) by the insertion of the following subparagraph after subparagraph (i):
                         “(ia) Notwithstanding that the excess amount remains unallowed for
                               an accounting period and shall be carried forward and treated as
                               an allowance within the meaning of paragraph (a)(i) for the
                               succeeding accounting          period    in   accordance    with
                               subparagraph (i), for all other purposes of this Part the excess
                               amount shall be treated as an allowance that has been made in
                               the first accounting period for which it remains unallowed.”,
          (b) in subsection (8)(a), by the deletion of “under section 284 as applied by this
              section”, and
          (c) in subsection (9)—
              (i) in paragraph (a), by the substitution of “Subject to paragraphs (b) and (c), this
                  section shall not apply” for “This section shall not apply”,



                                               67
PT.1 S.43 [No. 18.]                     Finance Act 2025.                                 [2025.]

              (ii) by the substitution of the following paragraph for paragraph (b):
                        “(b) Where, in relation to an acquisition referred to in paragraph (a)—
                            (i) the transferor and transferee make a joint election under section
                                615(4) or 617(4), and
                            (ii) the acquisition does not occur on a transfer to which section
                                 400(6) applies,
                             the transferee shall be entitled to claim an allowance under section
                             284 as applied by this section in respect of capital expenditure
                             incurred by it on acquiring the specified intangible asset from the
                             transferor.”,
                  and
             (iii) by the insertion of the following paragraph after paragraph (b):
                        “(c) Where an acquisition referred to in paragraph (a) occurs on a
                             transfer to which section 400(6) applies, the transferee shall be
                             entitled to claim allowances under section 284 as applied by this
                             section in respect of the specified intangible asset in accordance
                             with section 400(6).”.
     (2) (a) Paragraph (a)(i) of subsection (1) applies as respects any event referred to in
             section 288(1) of the Principal Act which occurs on or after 8 October 2025.
         (b) Paragraphs (a)(ii), (b) and (c) of subsection (1) shall have effect for accounting
             periods commencing on or after 1 January 2026.


Amendment of section 400 of Principal Act (company reconstructions without change of
ownership)
44. (1) Section 400 of the Principal Act is amended—
          (a) in subsection (6), by the insertion of “in respect of assets which have transferred
              from the predecessor to the successor on the transfer of the trade,” after “sections
              307 and 308; but,”, and

         (b) by the insertion of the following subsection after subsection (7A):
                 “(7B) (a) Where the trade consists of the carrying on of relevant activities
                           (within the meaning of section 291A(5)(a))—
                            (i) the predecessor shall not be entitled to any relief under section
                                291A(6)(b)(i) in respect of an excess amount (within the
                                meaning of section 291A(6)(b)(i)), or portion thereof, as the
                                case may be, which relates to a specified intangible asset which
                                transferred from the predecessor to the successor on the transfer
                                of the trade (in this subsection referred to as ‘the transferable
                                excess amount’), and the successor shall be entitled to relief
                                under section 291A(6)(b)(i) in respect of the transferable excess


                                                68
[2025.]                               Finance Act 2025.                      [No. 18.] PT.1 S.44

                              amount, for which the predecessor would have been entitled to
                              claim relief if the predecessor had continued to carry on the
                              trade, and
                          (ii) the predecessor shall not be entitled to any relief under section
                               291A(6)(b)(ii) in respect of excess interest (within the meaning
                               of section 291A(6)(b)(ii)), or portion thereof, as the case may
                               be, which was incurred in connection with the provision of a
                               specified intangible asset which transferred from the
                               predecessor to the successor on the transfer of the trade (in this
                               subsection referred to as ‘the transferable excess interest’), and
                               the successor shall be entitled to relief under section 291A(6)(b)
                               (ii) in respect of the transferable excess interest, for which the
                               predecessor would have been entitled to claim relief if the
                               predecessor had continued to carry on the trade.
                      (b) (i) For the purposes of subparagraph (i) of paragraph (a), where an
                              excess amount referred to in that subparagraph relates to both—
                              (I) a specified intangible asset which transferred from the
                                  predecessor to the successor on the transfer of the trade, and
                             (II) a specified intangible asset which did not so transfer,
                              when determining the transferable excess amount, the excess
                              amount shall be apportioned on a just and reasonable basis.
                          (ii) For the purposes of subparagraph (ii) of paragraph (a), where
                               excess interest referred to in that subparagraph was incurred in
                               connection with both—
                              (I) the provision of a specified intangible asset which
                                  transferred from the predecessor to the successor on the
                                  transfer of the trade, and
                             (II) the provision of a specified intangible asset which did not so
                                  transfer,
                              when determining the transferable excess interest, the excess
                              interest shall be apportioned on a just and reasonable basis.”.
     (2) Subsection (1) shall have effect for accounting periods commencing on or after
         1 January 2026 in respect of a transfer of a trade to which section 400(5) of the
         Principal Act applies which occurs on or after 1 January 2026.


Amendment of section 481 of Principal Act (relief for investment in films)
45. (1) Section 481 of the Principal Act is amended—
          (a) in subsection (1)—
              (i) in the definition of “film corporation tax credit”, by the substitution of
                  “subsections (1B), (1C) and (1D)” for “subsections (1B) and (1C)”, and

                                              69
PT.1 S.45 [No. 18.]                     Finance Act 2025.                                  [2025.]

              (ii) by the insertion of the following definitions:
                         “ ‘relevant visual effects work’, in relation to a visual effects project,
                         means work consisting of such visual effects processes as may be
                         specified in regulations made under subsection (2E);
                         ‘visual effects’ means the use of computer technology to digitally
                         create or manipulate content whether such content is for inclusion in a
                         film or within filmed footage for inclusion in a film;
                         ‘visual effects project’ means—
                        (a) a qualifying film—
                            (i) where production by the qualifying company consists wholly or
                                mainly of relevant visual effects work, and
                           (ii) in respect of which the eligible expenditure on relevant visual
                                effects work is not less than €1,000,000,
                            or
                        (b) a qualifying film in respect of which the qualifying company incurs
                            eligible expenditure of not less than €1,000,000 on relevant visual
                            effects work;”,
         (b) by the insertion of the following subsection after subsection (1C):
                 “(1D) (a) Where a producer company expects a film to be a visual effects
                           project, the producer company, in making its application under
                           subsection (1A), may apply for the certificate mentioned in that
                           subsection to specify, in addition to that mentioned in that
                           subsection, that an increased film corporation tax credit (in this
                           section referred to as the ‘enhanced credit amount for visual
                           effects’) may apply as provided for in paragraph (c).
                        (b) In considering whether, in the certification applied for, he or she
                            should specify that the enhanced credit amount for visual effects
                            may apply, the Minister, in accordance with regulations made under
                            subsection (2E), shall have regard to whether the film is expected
                            to satisfy the criteria set out in paragraph (a) or (b) of the
                            definition, in subsection (1), of ‘visual effects project’.
                        (c) Where—
                            (i) the certificate issued under subsection (2) specifies that the
                                enhanced credit amount for visual effects may apply,
                           (ii) on completion of production, the qualifying film satisfies the
                                conditions and obligations required by this section, and
                          (iii) the qualifying film is a visual effects project,
                            then, subject to paragraph (d), the producer company shall—



                                                70
[2025.]                               Finance Act 2025.                        [No. 18.] PT.1 S.45

                           (I) in making the claim for the film corporation tax credit under
                               subsection (2G)(b)(ii), calculate the value of the enhanced credit
                               amount for visual effects as if, in the definition, in subsection
                               (1), of ‘film corporation tax credit’, ‘40 per cent’ were
                               substituted for ‘32 per cent’ for that purpose, or
                          (II) where a claim has been made for the film corporation tax credit
                               under subsection (2G)(b)(i), in making the claim for the film
                               corporation tax credit under subsection (2G)(b)(ii), calculate the
                               value of the enhanced credit amount for visual effects as if, in the
                               definition, in subsection (1), of ‘film corporation tax credit’, ‘40
                               per cent’ were substituted for ‘32 per cent’ for that purpose, less
                               any amount already claimed pursuant to subsection (2G)(b)(i).
                        (d) Where, in relation to calculating the value of the enhanced credit
                            amount for visual effects under clause (I) or (II), as the case may
                            be, of paragraph (c), in respect of a visual effects project, the
                            lowest of the amounts referred to in paragraphs (a) to (c) of the
                            definition, in subsection (1), of ‘film corporation tax credit’
                            (referred to in this paragraph as the ‘qualifying amount’) exceeds
                            €10,000,000, then the total value of the film corporation tax credit
                            for the visual effects project shall comprise—
                           (i) an enhanced credit amount for visual effects equal to 40 per cent
                               of €10,000,000, and
                           (ii) an amount equal to 32 per cent of the amount by which the
                                qualifying amount exceeds €10,000,000.”,
          (c) in subsection (2)—
              (i) in paragraph (a), by the substitution of the following subparagraph for
                  subparagraph (ii):
                         “(ii) specifying—
                               (I) whether or not the regional film development uplift applies,
                                   if appropriate,
                              (II) whether or not the enhanced credit for lower budget film
                                   may apply, if appropriate, or
                             (III) whether or not the enhanced credit amount for visual effects
                                   may apply, if appropriate.”,
                  and
             (ii) in paragraph (b)—
                  (I) in subparagraph (iv), by the deletion of “and”,
                  (II) in subparagraph (v), by the substitution of “if appropriate, and” for “if
                       appropriate”, and



                                               71
PT.1 S.45 [No. 18.]                        Finance Act 2025.                                    [2025.]

                    (III) by the insertion of the following subparagraph after subparagraph (v):
                             “(vi) the criteria referred to in subsection (1D)(b), if appropriate,”,
              and
         (d) in subsection (2E)—
               (i) by the insertion of the following paragraph after paragraph (ba):
                       “(bb) specifying the visual effects processes that may be regarded as
                             relevant visual effects work for the purposes of an application for,
                             and certification in respect of, the enhanced credit amount for
                             visual effects in accordance with this section,”,
              (ii) by the insertion of the following paragraph after paragraph (i):
                          “(ia) in relation to the matters referred to in the definition, in subsection
                                (1), of ‘visual effects project’, governing the eligible expenditure
                                incurred by the qualifying company on relevant visual effects work
                                for the purposes of the calculation of the enhanced credit amount
                                for visual effects in accordance with this section,”,
                    and
             (iii) by the insertion of the following paragraph after paragraph (lb):
                          “(lc) specifying the criteria to be considered by the Minister, in relation
                                to the criteria referred to in subsection (1D)(b)—
                               (i) in deciding whether, in the certificate applied for under
                                   subsection (1A), he or she should specify that the enhanced
                                   credit amount for visual effects may apply, and
                              (ii) in specifying conditions in such a certificate, as provided for in
                                   subsection (2)(b),
                                and the information required for those purposes to be included in
                                the application made to the Minister under subsection (1A) by a
                                producer company,”.

     (2) Subsection (1) shall apply to a qualifying film (within the meaning of section 481 of
         the Principal Act) in respect of which the Minister for Culture, Communications and
         Sport issues a certificate (within the said meaning) after the coming into operation of
         this section.

     (3) This section shall come into operation on such day as the Minister for Finance may,
         by order, appoint.

Amendment of section 481A of Principal Act (relief for investment in digital games)
46. (1) Section 481A of the Principal Act is amended—
          (a) in subsection (1)—



                                                   72
[2025.]                             Finance Act 2025.                        [No. 18.] PT.1 S.46

           (i) by the substitution of the following definition for the definition of “date of
               completion”:

                      “ ‘date of completion’ means—
                     (a) in the case of a qualifying digital game in respect of which a post-
                         release extension of an interim certificate has not been granted, the
                         earlier of—
                        (i) the date on which the game is first made available to the public,
                            or
                        (ii) where the game is commissioned by an undertaking other than
                             the digital games development company, the date on which the
                             game is first provided by the digital games development
                             company to the undertaking,
                         and
                    (b) in the case of a qualifying digital game in respect of which a
                        post-release extension of an interim certificate has been granted,
                        the earlier of—
                        (i) the last date on which post-release digital content is made
                            available to the public before an application for a final
                            certificate is made by the digital games development company,
                            or
                        (ii) where the game is commissioned by an undertaking other than
                             the digital games development company, the last date on which
                             post-release digital content is provided by the digital games
                             development company to the undertaking before an application
                             for a final certificate is made by the digital games development
                             company,
                     and ‘completed’ shall be construed accordingly;”,
          (ii) in the definition of “eligible expenditure”, by the substitution of “an EEA
               state” for “the EEA”,

          (iii) by the substitution of the following definition for the definition of “qualifying
                expenditure”:

                      “ ‘qualifying expenditure’, in relation to an interim digital game or a
                      qualifying digital game, is expenditure (the types of which are
                      specified in regulations made under subsection (17)) incurred by a
                      digital games development company on the design, production and
                      testing of a digital game, being expenditure which for corporation tax
                      purposes is allowable as a deduction in computing, or against, the
                      income of the trade referred to in paragraph (b) of the definition, in
                      this subsection, of ‘digital games development company’ which is


                                             73
PT.1 S.46 [No. 18.]                      Finance Act 2025.                                  [2025.]

                           chargeable under Case I of Schedule D;”,
                  and
             (iv) by the insertion of the following definitions:
                           “ ‘date of release’, in relation to an interim digital game, means the
                           date on which the game is first made available to the public and
                           ‘released’ shall be construed accordingly;
                           ‘EEA Agreement’ means the Agreement on the European Economic
                           Area signed at Oporto on 2 May 1992 as adjusted by all subsequent
                           amendments to that Agreement;
                           ‘EEA state’ means a state, other than the State, which is a contracting
                           party to the EEA Agreement;
                           ‘post-release digital content’, in relation to a qualifying digital game,
                           means digital content which is developed subsequent to the date of
                           release of the game and which is in addition to, and for incorporation
                           into, that game;
                           ‘post-release extension of an interim certificate’ shall be construed in
                           accordance with subsection (8A);
                           ‘post-release interim certificate extension period’ has the meaning
                           given to it by subsection (8A);”,
         (b) by the substitution of the following subsection for subsection (2):
                      “(2) Subject to the provisions of this section, a digital games development
                           company that intends to make a claim for an interim digital games
                           corporation tax credit or a digital games corporation tax credit, as the
                           case may be, under this section—
                          (a) shall, in relation to a digital game that is to be developed by the
                              company, make an application to the Minister for the issue by the
                              Minister of an interim certificate,
                          (b) may, in relation to a digital game that is developed by the company
                              and released and in respect of which an interim certificate has been
                              issued under subsection (4), make an application to the Minister for
                              the grant by the Minister of a post-release extension of an interim
                              certificate, and
                          (c) shall, in relation to a digital game that has been developed and
                              completed by the company and in respect of which an interim
                              certificate has been issued under subsection (4), make an
                              application to the Minister for the issue of a final certificate.”,
          (c) in subsection (3), by the substitution of “an interim certificate, a post-release
              extension of an interim certificate or a final certificate under subsection (2)” for
              “an interim or final certificate under subsection (2)”,



                                                 74
[2025.]                                 Finance Act 2025.                      [No. 18.] PT.1 S.46

          (d) in subsection (5)—
              (i) in paragraph (a), by the deletion of “and”,
              (ii) in paragraph (b)—
                   (I) by the substitution of “the State or an EEA state” for “Ireland or another
                       EEA state” in each place where it occurs, and
                  (II) in subparagraph (v), by the substitution of “minimising climate change,
                       and” for “minimising climate change.”,
                  and
             (iii) by the insertion of the following paragraph after paragraph (b):
                        “(c) the timing of the application for the interim certificate by reference
                             to the date on which the digital games development company first
                             incurs qualifying expenditure on the development of the digital
                             game.”,

          (e) by the substitution of the following subsection for subsection (8):

                   “(8) On the expiry of an interim certificate, the interim certificate shall
                        cease to have effect and is treated as never having had effect unless—
                         (a) an application has been made before the expiry date to the Minister
                             under paragraph (b) or (c) of subsection (2), as the case may be,
                             and
                         (b) on the determination of the application—
                            (i) in the case of an application under subsection (2)(b), a
                                post-release extension of an interim certificate is granted by the
                                Minister, or
                            (ii) in the case of an application under subsection (2)(c), a final
                                 certificate is issued by the Minister.”,

          (f) by the insertion of the following subsections after subsection (8):
                 “(8A) (a) The Minister may, following an application by a digital games
                           development company under subsection (2)(b), subject to
                           subsection (8B) and in accordance with regulations made under
                           subsection (17), grant to the digital games development company a
                           post-release extension of an interim certificate for such period as
                           the Minister may specify (in this section referred to as the ‘post-
                           release interim certificate extension period’).
                         (b) Where the Minister grants a post-release extension of an interim
                             certificate under paragraph (a)—
                            (i) the interim certificate as issued under subsection (4) is extended
                                accordingly,


                                                75
PT.1 S.46 [No. 18.]                       Finance Act 2025.                                  [2025.]

                              (ii) the digital game concerned is to be treated as if it were an
                                   interim digital game for the purposes of this section, and
                             (iii) the conditions specified in the interim certificate concerned—
                                  (I) continue to apply, and
                                 (II) may be amended, revoked or added to by the Minister.
                      (8B) In considering whether to grant a post-release extension of an interim
                           certificate, the Minister shall have regard to the following criteria—
                           (a) whether the digital game as released is an eligible digital game,
                          (b) the contribution which the digital game makes to the promotion and
                              expression of Irish or European culture, by reference to the matters
                              referred to in subparagraphs (i) to (v) of subsection (5)(b), and
                           (c) whether the conditions specified in the interim certificate have, at
                               the date of release of the digital game, been satisfied.
                      (8C) On the expiry of a post-release interim certificate extension period, the
                           interim certificate shall cease to have effect and is treated as never
                           having had effect unless—
                           (a) an application has been made to the Minister under subsection (2)(c)
                               before the date on which the post-release interim certificate
                               extension period expires, and
                          (b) on the determination of that application, a final certificate is issued
                              by the Minister.
                      (8D) For the purposes of subsection (8A)(b)(iii)(II), subsection (7) shall
                           apply during the post-release interim certificate extension period as it
                           did before the post-release interim certificate extension period.”,
          (g) in subsection (9), by the substitution of “subsection (2)(c)” for “subsection (2)(b)”,
         (h) in subsection (10), by the substitution of the following paragraph for paragraph (c):
                         “(c) whether the conditions specified in the interim certificate issued in
                              respect of the interim digital game have been satisfied.”,
          (i) in subsection (13)—
               (i) in paragraph (b), by the substitution of “the interim certificate or, where a
                   post-release extension of an interim certificate has been granted, the
                   post-release interim certificate extension period, has expired” for “the interim
                   certificate has expired”, and
              (ii) in paragraph (g), by the deletion of “other than the State”,
          (j) in subsection (14A)(c), by the substitution of “section 481, or” for “section 481,
              and”,
          (k) in subsection (15)(c), by the deletion of “the Revenue Commissioners may”,


                                                  76
[2025.]                                 Finance Act 2025.                        [No. 18.] PT.1 S.46

           (l) in subsection (16)—
               (i) in paragraph (a)(i)(I), by the substitution of “the State or an EEA state” for “an
                   EEA state”,
              (ii) by the insertion of the following paragraph after paragraph (b):
                      “(ba) in relation to a claim under subsection (19) as respects an interim
                            digital game that is released, where the company fails to provide,
                            when requested to do so by the Revenue Commissioners, for the
                            purposes of verifying compliance with the provisions governing the
                            relief or with any condition specified in a certificate issued by the
                            Minister under subsection (4), a copy of a released digital game, in
                            such format and manner as is required to be provided to the
                            Minister under paragraph (d)(ii) as respects a completed digital
                            game,”,
                  and
             (iii) by the substitution of the following paragraph for paragraph (e):
                        “(e) unless—
                            (i) the company makes a claim under subsection (20) and has
                                available, prior to making that claim, a compliance report, in
                                such format and manner as is specified in the regulations made
                                under subsection (17), which provides proof that—
                                (I) the provisions of this section in so far as they apply in
                                    relation to the company have been met,
                               (II) any conditions attaching to the interim certificate issued to
                                    the company in relation to the interim digital game have
                                    been fulfilled, and
                              (III) any conditions attaching to the final certificate issued to the
                                    company in relation to the qualifying digital game have been
                                    fulfilled,
                                or
                           (ii) the requirements of subparagraphs (i) to (iii) of subsection
                                (28A)(c) are satisfied in respect of the company,”,
          (m) in subsection (17)—

               (i) in paragraph (a), by the substitution of “interim certification, post-release
                   extension of an interim certificate and final certification” for “interim
                   certification or final certification”, and

              (ii) by the insertion of the following paragraphs after paragraph (b):
                      “(ba) specifying, in relation to an application for a post-release extension
                            of an interim certificate, the time within which, and the format,

                                                77
PT.1 S.46 [No. 18.]                     Finance Act 2025.                                    [2025.]

                             number of copies and manner in which, a released digital game
                             shall be provided to the Minister,
                        (bb) specifying, in relation to an application for a post-release extension
                             of an interim certificate, the time within which a digital games
                             development company shall notify the Minister of the date of
                             release of a released digital game,
                        (bc) specifying the time within which, and the format and manner in
                             which, the confirmation referred to in subsection (28A)(c)(i) shall
                             be sought and the information and documents to be provided to the
                             Minister,”,
                  and
             (iii) in paragraph (g), by the substitution of “in accordance with subsection (16)(e)(i)
                   or (28A)(c)(ii)” for “in accordance with subsection (16)(e)”,

         (n) in subsection (19)(b), by the substitution of “the interim certificate or the
             post-release interim certificate extension period, as the case may be, has not
             expired” for “the interim certificate has not expired”,

         (o) in subsection (26)(a), by the substitution of “in respect of which an amount was
             paid or offset under subsection (22)” for “in respect of which the payment was
             made”,

         (p) by the insertion of the following subsection after subsection (28):
                “(28A) (a) This subsection applies to a claim for the interim digital games
                           corporation tax credit where—
                             (i) the amount was claimed under subsection (19), or paid or offset
                                 under subsection (22A), and
                            (ii) the interim certificate is subsequently treated under subsection
                                 (8) or (8C), as the case may be, as ceasing to have effect and
                                 never having had effect.
                         (b) Subject to paragraph (c), where this subsection applies, any amount
                             that is to be charged to tax in accordance with subsection (26) may
                             be so charged within 4 years of the end of the accounting period in
                             which the interim certificate is first treated under subsection (8) or
                             (8C), as the case may be, as ceasing to have effect and never having
                             had effect at any time.
                         (c) Where the interim certificate is treated under subsection (8C) as
                             never having had effect, then notwithstanding the generality of
                             subsection (26), the amount that is to be charged to tax in
                             accordance with that subsection shall, subject to paragraph (d), be
                             the amount of the interim digital games corporation tax credit that
                             was claimed under subsection (19), or paid or offset under


                                                78
[2025.]                                Finance Act 2025.                      [No. 18.] PT.1 S.46

                            subsection (22A), as the case may be, in respect of expenditure
                            incurred on the development of the interim digital game after the
                            date of release provided that—
                            (i) the Minister confirms that a final certificate would have been
                                issued to the digital games development company in accordance
                                with subsection (9) if, when the company made the application
                                to the Minister for a post-release extension of an interim
                                certificate under subsection (2)(b), the company had, instead,
                                made an application to the Minister for a final certificate under
                                subsection (2)(c),
                           (ii) the digital games development company has available a
                                compliance report, in such format and manner as is specified in
                                the regulations made under subsection (17), in respect of any
                                amount of the interim digital games corporation tax credit
                                claimed under subsection (19), or paid or offset under
                                subsection (22A), as the case may be, to the extent that such
                                amount is in respect of the development of the game prior to the
                                date of release, which provides proof of the matters set out in
                                clauses (I) and (II) of subsection (16)(e)(i), and
                          (iii) as respects the amount of the interim digital games corporation
                                tax credit claimed under subsection (19), the qualifying
                                expenditure incurred by the company on the development of the
                                released game is not less than €100,000.
                        (d) Nothing in paragraph (c) shall prevent the charging to tax of an
                            amount in accordance with subsection (26) equal to so much of the
                            amount of the interim digital games corporation tax credit that was
                            claimed under subsection (19), or paid or offset under subsection
                            (22A), as the case may be, in respect of expenditure incurred on the
                            development of the interim digital game prior to the date of release
                            as is not as authorised by this section.”,
          (q) by the substitution of the following subsection for subsection (29):
                  “(29) Notwithstanding section 851A, where a digital games development
                        company obtains relief under this section, the Revenue Commissioners
                        may disclose the following taxpayer information in accordance with
                        State aid transparency requirements:
                        (a) the name of the company;
                        (b) the name of the digital game;
                        (c) the number of the certificate of incorporation of the company;
                        (d) in respect of the principal activity carried on by the company, the
                            NACE classification code, as determined in accordance with
                            Regulation (EC) No. 1893/2006 of the European Parliament and of



                                               79
PT.1 S.46 [No. 18.]                             Finance Act 2025.                                 [2025.]

                                      the Council of 20 December 200615 as amended by Regulation
                                      (EU) 2019/1243 of the European Parliament and of the Council of
                                      20 June 201916 and Commission Delegated Regulation (EU)
                                      2023/137 of 10 October 202217;
                               (e) the amount of interim digital games corporation tax credit or digital
                                   games corporation tax credit, as the case may be, granted, by
                                   reference to ranges set out in page 10, paragraph 52(7) of the
                                   Communication from the Commission (2013/C 332/01)18, inserted
                                   by Communication from the Commission (2014/C 198/02)19;
                               (f) whether the company is—
                                     (i) a category of enterprise referred to in Article 2.1 of Annex 1 to
                                         Commission Regulation (EU) No. 651/2014 of 17 June 201420,
                                         or
                                     (ii) a category of enterprise which is larger than the categories of
                                          enterprise referred to in subparagraph (i);
                               (g) the territorial unit, within the meaning of the NUTS Level 2
                                   classification specified in Annex 1 to Regulation (EC) No.
                                   1059/2003 of the European Parliament and of the Council of 26
                                   May 200321 as amended by Regulation (EC) No. 1888/2005 of the
                                   European Parliament and of the Council of 26 October 200522,
                                   Commission Regulation (EC) No. 105/2007 of 1 February 200723,
                                   Regulation (EC) No. 176/2008 of the European Parliament and of
                                   the Council of 20 February 200824, Regulation (EC) No. 1137/2008
                                   of the European Parliament and of the Council of 22 October
                                   200825, Commission Regulation (EU) No. 31/2011 of 17 January
                                   201126, Council Regulation (EU) No. 517/2013 of 13 May 2013 27,
                                   Commission Regulation (EU) No. 1319/2013 of 9 December
                                   201328, Commission Regulation (EU) No. 868/2014 of 8 August
                                   201429, Commission Regulation (EU) No. 2016/2066 of 21
                                   November 201630, Regulation (EU) 2017/2391 of the European
                                   Parliament and of the Council of 12 December 201731, Commission
                                   Delegated Regulation 2019/1755 of 8 August 201932, and

15   OJ No. L393, 30.12.2006, p.1
16   OJ No. L198, 25.7.2019, p.241
17   OJ No. L19, 20.1.2023, p.5
18   OJ No. C332, 15.11.2013, p.1
19   OJ No. C198, 27.6.2014, p.30
20   OJ No. L187, 26.6.2014, p.70
21   OJ No. L154, 21.6.2003, p.1
22   OJ No. L309, 25.11.2005, p.1
23   OJ No. L39, 10.2.2007, p.1
24   OJ No. L61, 5.3.2008, p.1
25   OJ No. L311, 21.11.2008, p.1
26   OJ No. L13, 18.1.2011, p.3
27   OJ No. L158, 10.6.2013, p.1
28   OJ No. L342, 18.12.2013, p.1
29   OJ No. L241, 13.8.2014, p.1
30   OJ No. L322, 29.11.2016, p.1
31   OJ No. L350, 29.12.2017, p.1
32   OJ No. L270, 24.10.2019, p.1


                                                        80
[2025.]                                       Finance Act 2025.                     [No. 18.] PT.1 S.46

                                    Commission Delegated Regulation (EU) 2023/674 of 26 December
                                    202233 in which the company is located;
                                (h) the date on which the interim digital games corporation tax credit
                                    or digital games corporation tax credit, as the case may be, is
                                    granted.”,
                 and
            (r) in subsection (31), by the substitution of “31 December 2031” for “31 December
                2025”.
          (2) (a) (i) The provisions of subsection (1) referred to in subparagraph (ii) shall apply to
                      an application made to the Minister for Culture, Communications and Sport
                      for the grant by that Minister of a post-release extension of an interim
                      certificate, where such application is made on or after the date of the coming
                      into operation of the provisions referred to in subparagraphs (i) to (xiv) of
                      paragraph (c), in respect of—
                        (I) an extant interim certificate issued in respect of a digital game before the
                            coming into operation of the provisions referred to in subparagraphs (i)
                            to (xiv) of paragraph (c) and in respect of which digital game, on the
                            date on which the application for the grant of a post-release extension of
                            an interim certificate is made, a final certificate has not issued, and
                       (II) an interim certificate issued on or after the date on which the provisions
                            referred to in subparagraphs (i) to (xiv) of paragraph (c) come into
                            operation.
                 (ii) The provisions of subsection (1) referred to in subparagraph (i) are as follows:
                        (I) subparagraph (i) of paragraph (a),
                       (II) subparagraph (iv) (in so far as that subparagraph inserts the definitions
                            of “date of release”, “post-release digital content”, “post-release
                            extension of an interim certificate” and “post-release interim certificate
                            extension period” in section 481A(1) of the Principal Act) of paragraph
                            (a),
                       (III) paragraph (b) (in so far as that paragraph substitutes subsection (2)(b)
                             of section 481A of the Principal Act),
                     (IV) paragraph (c),
                       (V) paragraph (e),
                     (VI) paragraph (f),
                    (VII) subparagraph (i) of paragraph (m), and
                   (VIII) subparagraph (ii) (in so far as that subparagraph inserts paragraphs (ba)
                          and (bb) in section 481A(17) of the Principal Act) of paragraph (m).
            (b) The following provisions of subsection (1) shall apply as respects digital games
33 OJ No. L87, 24.3.2023, p.1


                                                      81
PT.1 S.46 [No. 18.]                     Finance Act 2025.                                  [2025.]

              the development of which begins on or after the date on which those provisions
              come into operation:
               (i) paragraph (b) (in so far as that paragraph substitutes paragraphs (a) and (c) of
                   section 481A(2) of the Principal Act),
              (ii) subparagraphs (i), (ii)(II) and (iii) of paragraph (d), and
             (iii) paragraph (h).
          (c) The following provisions of subsection (1) shall come into operation on such day
              or days as the Minister for Finance may, by order or orders, appoint and different
              days may be appointed for different purposes or different provisions:
               (i) subparagraph (i) of paragraph (a),
              (ii) subparagraph (iv) (in so far as that subparagraph inserts the definitions of
                   “date of release”, “post-release digital content”, “post-release extension of an
                   interim certificate” and “post-release interim certificate extension period” in
                   section 481A(1) of the Principal Act) of paragraph (a),
             (iii) paragraph (b),
             (iv) paragraph (c),
              (v) subparagraphs (i), (ii)(II) and (iii) of paragraph (d),
             (vi) paragraph (e),
             (vii) paragraph (f),
            (viii) paragraph (g),
             (ix) paragraph (h),
              (x) subparagraph (i) of paragraph (i),
             (xi) subparagraphs (ii) and (iii) of paragraph (l),
             (xii) paragraph (m),
            (xiii) paragraph (n),
            (xiv) paragraph (p), and
             (xv) paragraph (r).
     (3) Paragraphs (a)(iii) and (j) of subsection (1) shall apply as respects claims for the
         interim digital games corporation tax credit and the digital games corporation tax
         credit in accordance with section 481A of the Principal Act made on and from the date
         of the passing of this Act.


Amendment of section 831B of Principal Act (participation exemption for certain foreign
distributions)
47. (1) Section 831B of the Principal Act is amended—
          (a) in subsection (1)—

                                                82
[2025.]                             Finance Act 2025.                      [No. 18.] PT.1 S.47

          (i) by the substitution of the following definition for the definition of “relevant
              subsidiary”:
                     “ ‘relevant subsidiary’, in relation to a relevant distribution, means a
                     company that—
                    (a) is, on the date on which it makes the relevant distribution—
                        (i) by virtue of the law of a relevant territory, resident for the
                            purposes of foreign tax in the relevant territory, and
                       (ii) not generally exempt from foreign tax,
                    (b) throughout the relevant period—
                        (i) was—
                            (I) by virtue of the law of a relevant territory, resident for the
                                purposes of foreign tax in the relevant territory, and
                           (II) not generally exempt from foreign tax,
                            or
                       (ii) was resident in the State,
                    (c) did not, at any time during the reference period, make an excluded
                        acquisition, and
                    (d) was not formed through a merger at any time during the reference
                        period, where a party to the merger was another company (in this
                        paragraph referred to as ‘the second-mentioned company’) that was
                        not resident in the State or that was not, by virtue of the law of a
                        relevant territory, resident for the purposes of foreign tax in a
                        relevant territory—
                        (i) from the date the reference period commences until the date the
                            merger takes place, or
                       (ii) where the second-mentioned company was incorporated or
                            formed during the reference period, from the date the
                            second-mentioned company was incorporated or formed until
                            the date the merger takes place;”,

          (ii) by the insertion of the following definitions:
                     “ ‘excluded acquisition’ means an acquisition by a company of—
                    (a) another business or part of another business, or
                    (b) the whole or greater part of the assets used for the purposes of
                        another business,
                     where the business concerned was previously carried on by another
                     company (in this definition referred to as ‘the second-mentioned
                     company’) that was not resident in the State or that was not, by virtue


                                            83
PT.1 S.47 [No. 18.]                      Finance Act 2025.                                    [2025.]

                           of the law of a relevant territory, resident for the purposes of foreign
                           tax in a relevant territory—
                           (i) from the date the reference period commences until the date the
                               acquisition takes place, or
                          (ii) where the second-mentioned company was incorporated or formed
                               during the reference period, from the date the second-mentioned
                               company was incorporated or formed until the date the acquisition
                               takes place,
                           but does not include the acquisition by a company of share capital in
                           another company;
                           ‘foreign withholding tax’ means a tax which—
                          (a) is directly chargeable on a distribution made by a company that is,
                              by virtue of the law of a territory other than the State, resident for
                              the purposes of foreign tax in that territory, to a company that is not
                              so resident, whether by charge to tax, deduction of tax at source or
                              otherwise, and
                          (b) is imposed at a nominal rate greater than zero per cent;”,

             (iii) in the definition of “reference period”, by the substitution of “3 years” for “5
                   years”,
             (iv) in the definition of “relevant distribution”—
                      (I) in paragraph (b)(ii), by the insertion of “where subparagraph (i) does not
                          apply,” before “out of the assets of the relevant subsidiary”, and
                  (II) in clause (I), by the insertion of “other than a tax that is similar or
                       corresponds to the surcharge referred to in section 440 and which is
                       imposed on a company where the greater part of the issued share capital
                       of the company or the greater part of the voting power in the company is
                       held by 5 or fewer individuals” after “the law of that territory”,
              (v) in the definition of “relevant period”, in paragraph (a)(i), by the substitution of
                  “3 years” for “5 years”, and
             (vi) in the definition of “relevant territory”—
                      (I) in paragraph (b), by the substitution of “have been made,” for “have
                          been made, or”,
                  (II) in paragraph (c), by the substitution of “the force of law, or” for “the
                       force of law,”, and
                 (III) by the insertion of the following paragraph after paragraph (c):
                         “(d) not being a territory referred to in paragraph (a), (b) or (c), a
                              territory (referred to in this section as a ‘specified territory’) which
                              generally imposes a foreign withholding tax on distributions,”,


                                                  84
[2025.]                                   Finance Act 2025.                       [No. 18.] PT.1 S.47

          (b) by the insertion of the following subsection after subsection (1):
                    “(1A) For the purposes of the definition, in subsection (1), of ‘relevant
                          territory’, a territory referred to in paragraph (b) or (c), as the case may
                          be, of that definition shall be regarded as a relevant territory from the
                          date that is 3 years immediately preceding the date on which the
                          arrangements referred to in the said paragraph (b) or (c), as the case
                          may be, have been made.”,
          (c) in subsection (5)—
               (i) in paragraph (a), by the substitution of “the relevant distribution is made,” for
                   “the relevant distribution is made, and”,
              (ii) in paragraph (b)—
                     (I) by the insertion of “other than out of the profits (within the meaning of
                         section 21B(1)(a)) of the relevant subsidiary,” before “where any gain”,
                         and
                    (II) by the substitution of “section 626B, and” for “section 626B.”,
                    and
             (iii) by the insertion of the following paragraph after paragraph (b):
                          “(c) if the relevant subsidiary that makes the relevant distribution is, by
                               virtue of the law of a specified territory, resident for the purposes
                               of foreign tax in the specified territory on the date on which it
                               makes the relevant distribution, where foreign withholding tax has
                               been paid by the relevant subsidiary on the full amount of the
                               relevant distribution and has not been and does not fall to be
                               repaid, in whole or in part, to any person.”,
              and
          (d) by the insertion of the following subsection after subsection (8):
                     “(9) For the purposes of this section, where the law of a relevant territory
                          does not determine the residence of a company for the purposes of
                          foreign tax and the company is not resident for the purposes of foreign
                          tax in another relevant territory by virtue of the law of that other
                          relevant territory, then—
                           (a) that company shall be regarded as resident for the purposes of
                               foreign tax in the relevant territory where that company is regarded
                               as so resident for the purposes of any arrangements having the
                               force of law by virtue of section 826(1), and
                           (b) that company shall be regarded as not generally exempt from
                               foreign tax where that company is not generally exempt from a tax
                               which—
                              (i) corresponds to corporation tax in the State,


                                                  85
PT.1 S.47 [No. 18.]                     Finance Act 2025.                                    [2025.]

                           (ii) generally applies to income, profits and gains arising in the
                                relevant territory referred to in paragraph (a), and
                          (iii) is imposed at a nominal rate greater than zero per cent.”.
     (2) Subject to subsection (3), subsection (1) shall apply in respect of a relevant
         distribution (within the meaning of section 831B of the Principal Act) made on or
         after 1 January 2026.
     (3) The following provisions of subsection (1) shall be deemed to apply in respect of a
         relevant distribution (within the meaning of section 831B of the Principal Act) made
         on or after 1 January 2025:
          (a) paragraph (a)(i);
         (b) paragraph (a)(ii), insofar as it relates to the insertion of the definition of
             “excluded acquisition” in section 831B(1) of the Principal Act.


Amendment of section 835AY of Principal Act (interpretation (Part 35D))
48. (1) Section 835AY of the Principal Act is amended, in subsection (1)—
          (a) in the definition of “large scale asset”—
               (i) in paragraph (i), by the substitution of “section 835AAA(1),” for “section
                   835AAA(1), or”, and
              (ii) by the insertion of the following paragraphs after paragraph (j):
                       “(k) an electricity transmission infrastructure development, a strategic
                            gas infrastructure development or a strategic infrastructure
                            development, each within the meaning of Part 4 of the Act of 2024,
                            in respect of which a decision to grant permission has been made
                            under section 123 of that Act, or
                        (l) a large-scale residential development, within the meaning of Part 4
                            of the Act of 2024, in respect of which a decision to grant
                            permission was made under section 98 or 109 of that Act,”,
              and
         (b) by the insertion of the following definition:
                         “ ‘Act of 2024’ means the Planning and Development Act 2024;”.
     (2) Subsection (1) shall come into operation on such day as the Minister for Finance may
         appoint by order.


Amendment of section 840A of Principal Act (interest on loans to defray money applied
for certain purposes)
49. (1) Section 840A of the Principal Act is amended—
          (a) in subsection (2), by the substitution of “Subject to subsections (3), (6), (7), (7A)
              and (8)” for “Subject to subsections (3), (6), (7) and (8)”, and

                                                86
[2025.]                                Finance Act 2025.                      [No. 18.] PT.1 S.49

          (b) in subsection (7), by the substitution of the following paragraph for
              paragraph (a):
                       “(a) where, other than the holding of shares in an investing company or
                            investing companies, the only business of the first-mentioned
                            company is the on-lending to the investing company or investing
                            companies of moneys which the first-mentioned company has
                            borrowed from persons who are not connected with either or both
                            the first-mentioned company and the investing company or
                            investing companies;”,
          (c) by the insertion of the following subsection after subsection (7):
                 “(7A) (a) For the purpose of subparagraph (b)(ii)(II), ‘relevant territory’ and
                           ‘tax’ have the same meaning, respectively, as in section 246.
                        (b) Subject to paragraph (c), subsection (2) shall not apply to an
                            amount of interest on a loan (in this subsection referred to as the
                            ‘connected loan’) made to an investing company by a person who
                            is connected with the investing company (in this subsection
                            referred to as the ‘connected lender’) used in acquiring an asset for
                            the purposes of its trade from a company which, at the time of the
                            acquiring of the asset, was connected with the investing company
                            (in this subsection referred to as the ‘connected seller’), where—
                            (i) the connected seller had borrowed to acquire the asset such that
                                the interest on the borrowings of the connected seller gave rise
                                to a reduction or relief in computing the amount of profits or
                                gains of the connected seller to be charged to corporation tax
                                under Schedule D, prior to the acquisition of the asset by the
                                investing company,
                           (ii) the connected lender—
                                (I) is subject to tax in the State on the interest income in
                                    relation to the connected loan, or
                               (II) by virtue of the law of a relevant territory, is resident in a
                                    relevant territory for the purposes of tax and, under the laws
                                    of the relevant territory, is subject, without any reduction
                                    computed by reference to the amount of such interest, to a
                                    tax on the interest income in relation to the connected loan,
                               and

                          (iii) it is reasonable to consider that the connected loan is made for
                                bona fide commercial purposes and does not form part of any
                                arrangement or scheme of which the main purpose, or one of the
                                main purposes, is the avoidance of tax.

                        (c) (i) For the purposes of calculating the amount of interest to which


                                               87
PT.1 S.49 [No. 18.]               Finance Act 2025.                                    [2025.]

                           paragraph (b) applies, the principal on the connected loan shall
                           not exceed—
                           (I) the principal outstanding on the borrowings of the connected
                               seller in respect of the asset concerned at the time
                               immediately prior to the acquisition of the asset by the
                               investing company, or
                          (II) where subparagraph (ii) applies, the maximum principal
                               amount.
                       (ii) (I) This subparagraph shall apply where, by virtue of
                                paragraph (b), subsection (2) has not applied to an amount
                                of interest on a connected loan made to a company that is
                                connected with the investing company (referred to in this
                                subparagraph as the ‘previous investing company’) in
                                respect of a previous acquisition of the asset concerned from
                                a company connected with the previous investing company
                                (referred to in this subparagraph as the ‘previous connected
                                seller’).
                          (II) Where this subparagraph applies, the ‘maximum principal
                               amount’ shall be an amount equal to the principal
                               outstanding on the borrowings of the previous connected
                               seller at the time immediately prior to the acquisition of the
                               asset concerned by the previous investing company and,
                               where there has been more than one previous acquisition
                               referred to in clause (I) in respect of the asset concerned, the
                               maximum principal amount shall be an amount equal to the
                               principal outstanding on the borrowings of the previous
                               connected seller at the time immediately prior to the
                               acquisition of the asset concerned by the previous investing
                               company in the earliest such previous acquisition of the
                               asset concerned to occur.
                      (iii) For the purposes of calculating—
                           (I) the principal outstanding on the borrowings of the connected
                               seller in respect of the asset concerned at the time
                               immediately prior to the acquisition of the asset by the
                               investing company, or
                          (II) where subparagraph (ii) applies, the maximum principal
                               amount,
                           where only a portion of the borrowings relate to the asset that is
                           acquired by the investing company, then the principal
                           outstanding on the borrowings or the maximum principal
                           amount shall be apportioned on a just and reasonable basis.




                                           88
[2025.]                                      Finance Act 2025.                        [No. 18.] PT.1 S.49

       (2) Subsection (1) shall apply to an acquisition of an asset (within the meaning of section
           840A of the Principal Act) on or after 1 January 2024.


Amendment of section 891H of Principal Act (country-by-country reporting)
50. (1) Section 891H of the Principal Act is amended—
             (a) in subsection (1)—
                    (i) by the substitution of “ ‘constituent entity’, ‘consolidated financial statements’,
                        ‘MNE group’,” for “ ‘constituent entity’, ‘MNE group’,”,
                   (ii) by the substitution of the following definition for the definition of
                        “country-by-country report”:
                                “ ‘country-by-country report’, in relation to an MNE group, means a
                                report that contains the information set out in subsection (4) and that
                                has been prepared in accordance with the OECD Report of 2015 and
                                the OECD CbCR Guidance;”,
                        and
                  (iii) by the insertion of the following definitions:
                                “ ‘OECD CbCR Guidance’ means the document entitled OECD
                                (2024), Guidance on the Implementation of Country-by-Country
                                Reporting: BEPS Action 13, OECD, Paris, published by the OECD in
                                May 2024;
                                ‘Directive’ means Council Directive 2011/16/EU of 15 February
                                201134 as amended by Council Directive 2014/107/EU of 9 December
                                201435, Council Directive (EU) 2015/2376 of 8 December 201536,
                                Council Directive (EU) 2016/881 of 25 May 201637, Council Directive
                                (EU) 2016/2258 of 6 December 201638, Council Directive (EU)
                                2018/822 of 25 May 201839, Council Directive (EU) 2020/876 of 24
                                June 202040, Council Directive (EU) 2021/514 of 22 March 202141,
                                Council Directive (EU) 2023/2226 of 17 October 202342 and Council
                                Directive (EU) 2025/872 of 14 April 202543;”,
                  and
             (b) by the insertion of the following subsections after subsection (11):
                        “(12) For the purposes of—
                               (a) determining whether a group is an MNE group, and

34   OJ No. L64, 11.3.2011, p.1
35   OJ No. L359, 16.12.2014, p.1
36   OJ No. L332, 18.12.2015, p.1
37   OJ No. L146, 3.6.2016, p.8
38   OJ No. L342, 16.12.2016, p.1
39   OJ No. L139, 5.6.2018, p.1
40   OJ No. L204, 26.6.2020, p.46
41   OJ No. L104, 25.3.2021, p.1
42   OJ L, 2023/2226, 24.10.2023
43   OJ L, 2025/872, 6.5.2025


                                                      89
PT.1 S.50 [No. 18.]                      Finance Act 2025.                                     [2025.]

                          (b) preparing    a   country-by-country      report    or    equivalent
                              country-by-country report, as the case may be, to be provided to the
                              Revenue Commissioners,
                           this section and any regulations made under this section shall be
                           construed so as to ensure, as far as practicable, consistency between—
                          (i) the effect which is to be given to this section and any regulations
                              made under this section, and
                          (ii) the effect which would be given if the OECD model legislation
                               were to be applied, in accordance with the OECD Report of 2015
                               and the OECD CbCR Guidance, to—
                             (I) the determination of whether a group is an MNE group, and
                             (II) the preparation of a country-by-country report or equivalent
                                  country-by-country report, as the case may be, to be provided to
                                  the Revenue Commissioners,
                           other than where such an application of this section and regulations
                           made under this section would be inconsistent with the Directive.
                      (13) (a) For the purposes of determining whether a group is an MNE group,
                               when applying the €750 million threshold provided for in
                               Article 1.3 of the OECD model legislation—
                              (i) where the preceding fiscal year of the ultimate parent entity was
                                  less than 12 months, the €750 million threshold shall be
                                  decreased pro rata,
                             (ii) where the group (in this subparagraph referred to as ‘the
                                  first-mentioned group’) existed as part of another group in the
                                  preceding fiscal year and the current fiscal year is the first fiscal
                                  year that it is no longer part of the other group and exists as an
                                  independent group, the first-mentioned group shall be deemed to
                                  have had consolidated group revenue of less than €750 million
                                  in the preceding fiscal year, and
                            (iii) subject to paragraph (b), extraordinary income and gains of the
                                  group from investment activities shall be included in the
                                  consolidated group revenue if such income and gains are
                                  presented in the consolidated financial statements of the
                                  ultimate parent entity in accordance with the applicable
                                  accounting principles under which the consolidated financial
                                  statements were prepared.
                          (b) Paragraph (a)(iii) shall not apply where the ultimate parent entity or
                              surrogate parent entity of the MNE group are tax resident in a
                              jurisdiction which, for the purposes of determining whether there is
                              a requirement for the ultimate parent entity or surrogate parent
                              entity, as the case may be, to file a country-by-country report in that


                                                  90
[2025.]                                 Finance Act 2025.                      [No. 18.] PT.1 S.50

                              jurisdiction, does not require extraordinary income and gains from
                              investment activities to be included in the consolidated group
                              revenue unless these items are included in revenue in accordance
                              with the applicable accounting principles under which the
                              consolidated financial statements were prepared.”.
      (2) Subsection (1) shall apply to accounting periods ending on or after 1 January 2026.

                                             CHAPTER 6

                                        Capital Gains Tax


Amendment of section 597AA of Principal Act (revised entrepreneur relief)
51.   Section 597AA of the Principal Act is amended—
          (a) in subsection (3), by the substitution of “Subject to subsections (4) to (4C)” for
              “Subject to subsection (4)”,
          (b) by the substitution of the following subsection for subsection (4):
                     “(4) Where a relevant individual makes a disposal or disposals of the whole
                          or part of chargeable business assets in the period beginning on
                          1 January 2016 and ending on 31 December 2025—
                          (a) the rate of capital gains tax referred to in subsection (3) shall be
                              chargeable only on so much, if any, of the chargeable gain or
                              chargeable gains accruing, when added to the aggregate amount of
                              any chargeable gain or chargeable gains accruing in respect of any
                              previous disposal or disposals of the whole or part of the
                              chargeable business assets made by the relevant individual in that
                              period, that does not exceed €1,000,000, and
                         (b) the rate of capital gains tax referred to in section 28(3) shall be
                             chargeable on so much, if any, of the chargeable gain or chargeable
                             gains accruing, when added to the aggregate amount of any
                             chargeable gain or chargeable gains accruing in respect of any
                             previous disposal or disposals of the whole or part of chargeable
                             business assets made by the relevant individual in that period, that
                             exceeds €1,000,000.”,
              and
          (c) by the insertion of the following subsections after subsection (4):
                    “(4A) Subsections (4B) and (4C) shall apply where a relevant individual
                          makes a disposal or disposals of the whole or part of chargeable
                          business assets on or after 1 January 2026, and the amount that is the
                          aggregate of—
                          (a) the chargeable gain or chargeable gains accruing,
                         (b) the aggregate amount of any chargeable gain or chargeable gains


                                                91
PT.1 S.51 [No. 18.]                      Finance Act 2025.                                [2025.]

                              accruing in respect of any previous disposal or disposals of the
                              whole or part of chargeable business assets made by the relevant
                              individual on or after 1 January 2026, and
                          (c) the aggregate amount of any chargeable gain or chargeable gains
                              accruing in respect of any previous disposal or disposals of the
                              whole or part of chargeable business assets made by the relevant
                              individual in the period beginning on 1 January 2016 and ending on
                              31 December 2025, provided that where the chargeable gain or
                              chargeable gains so aggregated for such disposals is greater than
                              €1,000,000, the chargeable gain or chargeable gains that shall be so
                              aggregated in respect of such disposals shall be €1,000,000,
                           exceeds €1,500,000.
                      (4B) The rate of capital gains tax referred to in subsection (3) shall be
                           chargeable only on so much, if any, of the chargeable gain or
                           chargeable gains referred to in paragraph (a) of subsection (4A), when
                           added to the amount of any chargeable gain or chargeable gains
                           referred to in paragraphs (b) and (c) of subsection (4A), that does not
                           exceed €1,500,000.
                      (4C) The rate of capital gains tax referred to in section 28(3) shall be
                           chargeable on so much of the chargeable gain or chargeable gains
                           referred to in paragraph (a) of subsection (4A), when added to the
                           amount of any chargeable gain or chargeable gains referred to in
                           paragraphs (b) and (c) of subsection (4A), that exceeds €1,500,000.”.



Amendment of section 604B of Principal Act (relief for farm restructuring)
52. (1) Section 604B(1) of the Principal Act is amended, in paragraph (a)—

          (a) by the substitution of the following definition for the definition of “agricultural
              land”:

                           “ ‘agricultural land’ means—
                              (i) land in the State used for the purposes of farming, including
                                  land suitable for occupation as woodlands on a commercial
                                  basis, and
                             (ii) land in the State suitable for occupation as woodlands (other
                                  than on a commercial basis), used for the purpose of
                                  conservation,
                           but does not include buildings on the land;”,

         (b) by the insertion of the following definition:
                           “ ‘conservation’ has the same meaning as it has in European


                                                 92
[2025.]                                      Finance Act 2025.                       [No. 18.] PT.1 S.52

                               Communities (Birds and Natural Habitats) Regulations 2011 (S.I. No.
                               477 of 2011);”,
                 and
            (c) in the definition of “relevant period”, by the substitution of “31 December 2029”
                for “31 December 2025”.
      (2) Paragraphs (a) and (b) of subsection (1) shall come into operation on such day as the
          Minister for Finance may, by order, appoint.
      (3) Paragraph (c) of subsection (1) shall come into operation on such day as the Minister
          for Finance may, by order, appoint.


                                                  PART 2

                                                   EXCISE


Amendment of Chapter 1 of Part 2 of Finance Act 1999 (Mineral Oil Tax)
53. (1) Chapter 1 of Part 2 of the Finance Act 1999 is amended—
            (a) in section 94(1), by the insertion of the following definitions:
                               “ ‘appropriate procedure’ means—
                              (a) in relation to biofuel for use as a propellant, and vehicle biogas, the
                                  procedure established by the National Oil Reserves Agency under
                                  Regulation 4(1) of the European Union (Biofuel Sustainability
                                  Criteria) Regulations 2012 (S.I. No. 33 of 2012), and
                             (b) in relation to biofuel for use other than as a propellant, the
                                 procedure established under Regulation 7(1) of the European
                                 Union (Renewable Energy) Regulations (2) 2022 (S.I. No. 350 of
                                 2022) by the competent authority referred to in the said
                                 Regulation 7(1) or, where no such procedure has been established,
                                 the procedure referred to in paragraph (a);
                               ‘sustainability and greenhouse gas emissions saving criteria’ means the
                               sustainability and greenhouse gas emissions saving criteria laid down
                               in Article 29 of Directive (EU) 2018/2001 of the European Parliament
                               and of the Council of 11 December 201844;”,
                 and
            (b) in section 100—
                  (i) in subsection (1), by the substitution of the following paragraph for
                      paragraph (f):
                             “(f) to be intended solely for use, or to have been solely used, to
                                  produce electricity, where that electricity is—
44 OJ No. L328 21.12.2018, p. 82.


                                                     93
PT.2 S.53 [No. 18.]                     Finance Act 2025.                                 [2025.]

                             (i) subject to electricity tax under section 58(1) of the Finance Act
                                 2008 or is supplied for consumption outside the State, and
                            (ii) produced in an installation that is covered by a greenhouse gas
                                 emissions permit.”,
              (ii) by the insertion of the following subsection after subsection (1):
                  “(1A) Subject to such conditions as the Commissioners may prescribe or
                        otherwise impose, a relief from mineral oil tax exclusive of the carbon
                        charge, shall be granted on any mineral oil that is shown to the
                        satisfaction of the Commissioners to be intended solely for use, or to
                        have been solely used, to produce electricity, where that electricity is
                        subject to electricity tax under section 58(1) of the Finance Act 2008
                        or is supplied for consumption outside the State.”,
             (iii) by the substitution of the following subsection for subsection (5):
                      “(5) Subject to such conditions as the Commissioners may prescribe or
                           otherwise impose, a relief from the carbon charge shall apply—
                          (a) to any mineral oil that is—
                             (i) shown to the satisfaction of the Commissioners to be biofuel,
                                 and
                            (ii) demonstrated, in accordance with the appropriate procedure, to
                                 be in compliance with the sustainability and greenhouse gas
                                 emissions saving criteria,
                              or
                         (b) where biofuel which meets the requirements of paragraph (a) has
                             been mixed or blended with any other mineral oil, to the biofuel
                             content of any such mixture or blend.”,
             (iv) by the substitution of the following subsection for subsection (5A):
                  “(5A) Subject to such conditions as the Commissioners may prescribe or
                        otherwise impose, a relief from the carbon charge shall apply—
                          (a) to any vehicle gas that is—
                             (i) shown to the satisfaction of the Commissioners to be vehicle
                                 biogas, and
                            (ii) demonstrated, in accordance with the appropriate procedure, to
                                 be in compliance with the sustainability and greenhouse gas
                                 emissions saving criteria,
                              or
                         (b) where vehicle biogas which meets the requirements of
                             paragraph (a) has been mixed or blended with any other vehicle
                             gas, to the vehicle biogas content of any such mixture or blend.”,


                                                94
[2025.]                                Finance Act 2025.                        [No. 18.] PT.2 S.53

              (v) by the insertion of the following subsection after subsection (5A) (amended by
                  subparagraph (iv)):
                 “(5B) (a) Where—
                           (i) relief from mineral oil tax has been availed of in respect of
                               biofuel or vehicle biogas in accordance with subsection (5) or
                               (5A), as the case may be, and
                           (ii) it is determined, in accordance with the appropriate procedure,
                                that the said biofuel or vehicle biogas is not in compliance with
                                the sustainability and greenhouse gas emissions saving criteria,
                            then, a liability to mineral oil tax, equal to the amount of relief
                            availed of in respect of that biofuel or vehicle biogas, shall arise.
                        (b) Notwithstanding paragraphs (a) and (b) of section 95(2), where a
                            liability to mineral oil tax arises under paragraph (a) of this
                            subsection, the liability shall apply from the date on which the
                            person who availed of the relief is notified, in accordance with the
                            appropriate procedure, of the determination referred to in the said
                            paragraph (a) of this subsection.”,
                  and
             (vi) in subsection (6)(a), by the insertion of “, other than in the case of mineral oil
                  to which subsection (1)(f) applies,” after “greenhouse gas emissions permit,”.
     (2) Subsection (1) shall come into operation on such day or days as the Minister for
         Finance may, by order, appoint and different days may be so appointed for different
         purposes or different provisions.


Amendment of section 71 of Finance Act 2010 (reliefs from natural gas carbon tax)
54. (1) Section 71 of the Finance Act 2010 is amended—
          (a) in subsection (1)(a), by the insertion of “in an installation that is covered by a
              greenhouse gas emissions permit” after “electricity”, and
          (b) in subsection (2), by the insertion of “, other than natural gas to which
              subsection (1)(a) applies” after “greenhouse gas emissions permit”.
     (2) Subsection (1) shall come into operation on such day as the Minister for Finance may,
         by order, appoint.


Amendment of section 82 of Finance Act 2010 (reliefs from solid fuel carbon tax)
55. (1) Section 82 of the Finance Act 2010 is amended—
          (a) in subsection (1)(a), by the insertion of “in an installation that is covered by a
              greenhouse gas emissions permit” after “electricity”, and
          (b) in subsection (2)—



                                                95
PT.2 S.55 [No. 18.]                               Finance Act 2025.                                       [2025.]

                 (i) by the substitution of “delivered” for “supplied”, and
                (ii) by the insertion of “, other than solid fuel to which subsection (1)(a) applies”
                     after “greenhouse gas emissions permit”.
      (2) Subsection (1) shall come into operation on such day as the Minister for Finance may,
          by order, appoint.


Amendment of Schedule 2 to Finance Act 2005 (rates of tobacco products tax)
56.   The Finance Act 2005 is amended with effect as on and from 8 October 2025 by the
      substitution of the following Schedule for Schedule 2:

                                                              “SCHEDULE 2

                                                    RATES OF TOBACCO PRODUCTS TAX

                                          (With effect as on and from 8 October 2025)

                      Description of Product                                          Rate of Tax
         Cigarettes .... .... .... .... .... .... .... .... ....    Rate of tax at—
                                                                    (a) except where paragraph (b) applies,
                                                                        €483.50 per thousand together with an
                                                                        amount equal to 8.78 per cent of the
                                                                        price at which the cigarettes are sold
                                                                        by retail, or
                                                                    (b) €533.99 per thousand in respect of
                                                                        cigarettes sold by retail where the rate
                                                                        of tax would be less than that rate had
                                                                        the rate been calculated in accordance
                                                                        with paragraph (a).
         Cigars .... .... .... .... .... .... .... .... .... ....   Rate of tax at €541.758 per kilogram.
         Fine-cut tobacco for the rolling of
         cigarettes .... .... .... .... .... .... .... .... ....    Rate of tax at €521.201 per kilogram.
         Other smoking tobacco .... .... .... .... ....             Rate of tax at €375.847 per kilogram.
                                                                                                                   ”.

Amendment of section 64 of Finance Act 2002 (interpretation)
57. (1) Section 64 of the Finance Act 2002 is amended—
          (a) by the substitution of the following definition for the definition of “licensed
              bookmaker”:
                          “ ‘licensed bookmaker’ means a person who is the holder of a
                          bookmaker’s licence or a remote bookmaker’s licence, as the case may
                          be, or a person who is the holder of a betting licence issued under—
                              (a) section 85(1)(a) of the Act of 2024,



                                                             96
[2025.]                                Finance Act 2025.                    [No. 18.] PT.2 S.57

                        (b) section 85(1)(b) of the Act of 2024, or
                        (c) section 85(1)(c) of the Act of 2024;”,
          (b) by the substitution of the following definition for the definition of “remote
              betting intermediary”:
                      “ ‘remote betting intermediary’ means a person who is the holder of a
                      licence issued under—
                        (a) section 7C of the Betting Act 1931, or
                        (b) section 85(1)(d) of the Act of 2024;”,
              and
          (c) by the insertion of the following definition:
                         “ ‘Act of 2024’ means the Gambling Regulation Act 2024;”.
      (2) Subsection (1) shall come into operation on such day or days as the Minister for
          Finance may, by order or orders, appoint and different days may be appointed for
          different purposes or different provisions.

Time when duty becomes due
58.   The Finance Act 2002 is amended by the substitution of the following section for
      section 69:
               “69. Betting duty and remote betting duty shall become due at the time the bet
                    is entered into by the bookmaker.”.


Amendment of section 70 of Finance Act 2002 (returns)
59.   Section 70 of the Finance Act 2002 is amended by the substitution of “excise duty under
      this Chapter” for “betting duty or betting intermediary duty” in both places where it
      occurs.


Amendment of section 71 of Finance Act 2002 (payment of duty with bet)
60.   Section 71(1) of the Finance Act 2002 is amended by the substitution of “excise duty” for
      “betting duty” in both places where it occurs.


Amendment of section 77 of Finance Act 2002 (regulations for payment of duty on bets)
61.   Section 77(1) of the Finance Act 2002 is amended—
          (a) in paragraph (a), by the insertion of “or remote betting intermediaries” after
              “bookmakers”, and
          (b) in paragraph (c), by the deletion of “, remote bookmakers”.




                                                97
PT.2 [No. 18.]                         Finance Act 2025.                                 [2025.]

De-registration of bookmaking premises
62. (1) The Finance Act 2002 is amended by the substitution of the following section for
        section 78:
                 “78. (1) A person who is employed by, or authorised to act as an agent for or
                          on behalf of, a bookmaker shall not engage in any of the following
                          activities:
                        (a) making any entry on any slip or other record by means of which a
                            bet is made, knowing that the said entry is false;
                        (b) substituting for any slip or record another document which is false;
                        (c) making any entry in any book or record kept for the purpose of
                            recording particulars of bets entered into by the bookmaker
                            knowing that the said entry is false;
                        (d) otherwise knowingly being concerned in the fraudulent evasion or
                            an attempt at evasion of duty.
                     (2) A person who contravenes subsection (1) shall be guilty of an offence
                         and shall be liable on summary conviction to an excise penalty of
                         €5,000.
                     (3) (a) The holder of a bookmaker’s licence shall not, in the course of
                             carrying on business as a bookmaker or acting as a bookmaker,
                             enter into a bet in any premises which are not for the time being
                             registered in the register.
                        (b) A person who enters into a bet in contravention of this subsection
                            shall, without prejudice to any other penalty to which he or she
                            may be liable, be guilty of an offence and shall be liable on
                            summary conviction to an excise penalty of €5,000.
                        (c) This subsection shall not apply to a licensed bookmaker who is
                            lawfully carrying on the business of a bookmaker at, or in the
                            precincts of, an authorised racecourse in accordance with the Irish
                            Horseracing Industry Act 1994 , or a greyhound race track or an
                            authorised coursing meeting in accordance with the Greyhound
                            Industry Act 1958.”.
     (2) Subsection (1) shall come into operation on such day or days as the Minister for
         Finance may, by order or orders, appoint and different days may be appointed for
         different purposes or different provisions.


Repeal of Chapter III of Part II of Finance Act 1992 (Amusement Machine Licence Duty)
63. (1) Chapter III of Part II of the Finance Act 1992 is repealed.
     (2) Subsection (1) shall come into operation on such day as the Minister for Finance may,
         by order, appoint.



                                               98
[2025.]                                Finance Act 2025.                               [No. 18.] PT.2

Amendment of section 68A of Finance Act 2002
64.   Section 68A of the Finance Act 2002 is amended—
          (a) in subsection (1)—
               (i) by the substitution of “excise duty under section 67, 67A or 67B, or any
                   combination thereof” for “betting duty under section 67 or betting
                   intermediary duty under section 67B, or both,”, and
              (ii) by the substitution of the following paragraph for paragraph (a):
                       “(a) that person is a licensed bookmaker or a remote betting
                            intermediary, and”,
              and
          (b) in subsection (7), by the insertion of the following paragraph after paragraph (iv):
                       “(v) furnish, by electronic means, a return in respect of the said
                            accounting period in the manner specified in section 70.”.


Amendment of section 135 of Finance Act 1992 (temporary exemption from registration)
65. (1) Section 135(aa) of the Finance Act 1992 is amended by the insertion of “or Northern
        Ireland” after “Member State” in each place where it occurs.
      (2) Subsection (1) is deemed to have come into operation on and from 31
          December 2020.


Amendment of section 135C of Finance Act 1992 (remission or repayment in respect of
vehicle registration tax, etc.)
66.   Section 135C of the Finance Act 1992 is amended—
          (a) in subsection (3)(b), by the substitution of “31 December 2026” for
              “31 December 2025”, and
          (b) in subsection (4), by the substitution of “31 December 2026” for “31
              December 2025”.


                                             PART 3

                                        VALUE-ADDED TAX


Definition (Part 3)
67.   In this Part, “Principal Act” means the Value-Added Tax Consolidation Act 2010.


Persons not accountable persons unless they so elect
68. (1) The Principal Act is amended, with effect from 1 January 2026—



                                                99
PT.3 S.68 [No. 18.]                       Finance Act 2025.                                   [2025.]

          (a) in section 4(1), in paragraph (b) of the definition of “farmer”—
               (i) by the substitution of the following subparagraph for subparagraph (ii):
                            “(ii) supplies of services consisting of the training of horses for
                                  racing, the total annual turnover for which has not exceeded, in
                                  the current calendar year or the previous calendar year, the
                                  services threshold;”,
                  and
              (ii) in subparagraph (iii), by the substitution of “annual turnover” for
                   “consideration”,
         (b) in section 6—
               (i) in subsection (1)—
                      (I) by the substitution of the following paragraph for paragraph (a):
                         “(a) a farmer, for whose supply, in the current calendar year or the
                              previous calendar year, of—
                               (i) agricultural services (other than insemination services,
                                   stock-minding or stock-rearing), the total annual turnover for
                                   which has not exceeded the services threshold,
                               (ii) goods being bovine semen, the total annual turnover for which
                                    has not exceeded the goods threshold,
                             (iii) goods, being horticultural type products of the kind specified in
                                   paragraph 22(1) of Schedule 3, to persons who are not engaged
                                   in supplying those goods in the course or furtherance of
                                   business, the total annual turnover for which has not exceeded
                                   the goods threshold,
                             (iv) either or both services of the kind specified in subparagraphs (i)
                                  and (vi), together with any or all goods of the kind specified in
                                  subparagraph (v), the total annual turnover for which has not
                                  exceeded the services threshold,
                               (v) any or all goods of the kind specified in subparagraph (ii),
                                   subparagraph (iii) where supplied in the circumstances set out in
                                   that subparagraph, and subparagraph (vii), the total annual
                                   turnover for which has not exceeded the goods threshold,
                             (vi) agricultural services of the kind specified in an order made
                                  under section 86A, the total annual turnover for which has not
                                  exceeded the services threshold, or
                            (vii) agricultural produce of the kind specified in an order made
                                  under section 86A, the total annual turnover for which has not
                                  exceeded the goods threshold;”,
                         and


                                                  100
[2025.]                                  Finance Act 2025.                         [No. 18.] PT.3 S.68

                    (II) in paragraph (b)(ii)(II), by the substitution of “annual turnover” for
                         “consideration”,
                    and
              (ii) in subsection (2)(c), by the substitution of “subsection (1)(a)(i), (ii), (iii), (vi)
                   or (vii),” for “subsection (1)(a)(i), (ii) or (iii),”,
          (c) in section 17(2)(a), by the substitution of “the total annual turnover for which has
              exceeded, in the current calendar year or the previous calendar year, the services
              threshold,” for “the consideration for which has exceeded the services threshold
              in any continuous period of 12 months,”, and
          (d) in Part 2 of Schedule 3, in paragraph 12(1A), by the substitution of “where the
              total annual turnover for providing those facilities exceeds, in the current
              calendar year or the previous calendar year, the services threshold” for “where
              the total consideration received by such entity for providing those facilities
              exceeds, or is likely to exceed, the services threshold during any continuous
              period of 12 months”.


Amendment of section 46 of Principal Act (reduced rate for electricity and gas)
69.   Section 46(1) of the Principal Act is amended, in paragraph (caa), by the substitution of
      “31 December 2030” for “31 October 2025” with effect as on and from 8 October 2025.


Amendment of section 46 of, and Schedule 3 to, Principal Act (reduced rate for housing as
part of a social policy)
70. (1) The Principal Act is amended, with effect as on and from 8 October 2025—
          (a) in section 46(1)—
              (i) in paragraph (a), by the insertion of “(cab),” after “(caa),”,
              (ii) in paragraph (c), by the insertion of “, (cab)” after “(caa)”, and
             (iii) by the insertion of the following paragraph after paragraph (caa):
                      “(cab) during the period from 8 October 2025 to 25 November 2025, 9 per
                             cent in relation to goods of a kind specified in paragraph 9A of
                             Schedule 3 on which tax would, but for this paragraph, be
                             chargeable in accordance with paragraph (c);”,
              and
          (b) in Schedule 3—

              (i) in Part 2, by the insertion of the following paragraph after paragraph 9:
                     “Housing as part of a social policy.
                     9A. The supply of housing, as part of a social policy, being the supply of
                         an apartment, used or to be used for residential purposes, in an

                                                 101
PT.3 S.70 [No. 18.]                      Finance Act 2025.                                  [2025.]

                           apartment block within the meaning of section 31E of the Stamp
                           Duties Consolidation Act 1999.”,
                    and
              (ii) in Part 3, by the substitution of the following paragraph for paragraph 14:
                      “14. Subject to paragraph 9A, the supply of immovable goods used or to be
                           used for residential purposes.”.

     (2) The Principal Act is amended, with effect as on and from 26 November 2025—
          (a) in section 46(1)—
               (i) in paragraph (a) (amended by subsection (1)(a)(i)), by the insertion of “(cac),”
                   after “(cab),”,
              (ii) in paragraph (c) (amended by subsection (1)(a)(ii)), by the insertion of
                   “, (cac)” after “(cab)”, and
             (iii) by the insertion of the following paragraph after paragraph (cab) (inserted by
                   subsection (1)(a)(iii)):
                       “(cac) during the period from 26 November 2025 to 31 December 2030, 9
                              per cent in relation to—
                              (i) goods of a kind specified in subparagraph (2) of paragraph 9B
                                  of Schedule 3, and
                             (ii) services of a kind specified in subparagraph (3) of paragraph 9B
                                  of Schedule 3,
                               on which tax would, but for this paragraph, be chargeable in
                               accordance with paragraph (c);”,
              and
         (b) in Schedule 3—
               (i) in Part 2—
                      (I) in paragraph 9(1), by the insertion of “(not being services referred to in
                          paragraph 9B(3))” after “Services”, and
                    (II) by the insertion of the following paragraph after paragraph 9A (inserted
                         by subsection (1)(b)(i)):
                      “Supply and construction of housing as part of a social policy.
                       9B. (1) In this paragraph—
                                ‘apartment block’ means a multi-storey building that comprises, or
                                will comprise, not less than 3 apartments with grouped or
                                common access;
                                ‘completed’ has the same meaning as it has in section 94.



                                                 102
[2025.]                                  Finance Act 2025.                     [No. 18.] PT.3 S.70

                            (2) The supply of immovable goods, as part of a social policy, which
                                are or, when completed, will be—
                                (a) one or more than one apartment, used or to be used for
                                    residential purposes, in an apartment block, or
                                (b) an apartment block, used or to be used for residential
                                    purposes, but excluding any part of the apartment block that
                                    is not used or to be used for residential purposes.
                            (3) Services consisting of the development, until completed, of
                                immovable goods to which subparagraph (2) applies.”,
              (ii) in Part 3, by the substitution of the following paragraph for paragraph 14
                   (amended by subsection (1)(b)(ii)):
                     “Housing.
                     14. The supply of immovable goods used or to be used for residential
                         purposes, other than immovable goods to which paragraph 9A or
                         9B(2), as the case may be, applies.”,
                    and
             (iii) in Part 4, in paragraph 15(2), by the insertion of “or 9B(3)” after “paragraph
                   9(1)”.


Amendment of section 46 of Principal Act (reduced rate for food and drink for human
consumption and hairdressing services)
71.   Section 46(1) of the Principal Act is amended, with effect from 1 July 2026, by the
      substitution of the following paragraph for paragraph (cb):
                      “(cb) 9 per cent in relation to goods or services of a kind specified in
                            paragraphs 3(1), 3(3) and 13(3) of Schedule 3 on which tax would,
                            but for this paragraph, be chargeable in accordance with paragraph
                            (c);”.


Amendment of sections 60 and 120 of, and paragraph 11 of Schedule 3 to, Principal Act
72.   The Principal Act is amended, with effect from 1 January 2026—
          (a) in section 60(1), in the definition of ‘qualifying accommodation’, by the deletion
              of “or accommodation”,
          (b) in section 120(15), by the substitution of the following paragraph for
              paragraph (a):
                          “(a) the circumstances, terms and conditions under which (for the
                               purposes of paragraph 11 of Schedule 3) a letting of immovable
                               goods consists of the provision of holiday or guest
                               accommodation,”,
              and

                                                103
PT.3 S.72 [No. 18.]                      Finance Act 2025.                                      [2025.]

          (c) in Part 2 of Schedule 3, by the substitution of the following paragraph for
              paragraph 11:
               “11. Subject to regulations, if any, the letting of immovable goods where the
                    letting consists of the provision of holiday or guest accommodation in—
                          (a) a hotel,
                          (b) a guesthouse,
                          (c) all or part of a house,
                          (d) all or part of an apartment, or
                          (e) another establishment,
                        including the letting of a place in a caravan park or camping site.”.


Amendment of section 86 of Principal Act (special provisions for tax invoiced by flat-rate
farmers)
73.   Section 86(1) of the Principal Act is amended, with effect from 1 January 2026, by the
      substitution of “4.5 per cent” for “5.1 per cent”.

Amendment of section 96 of Principal Act (waiver of exemption under old rules)
74.   Section 96 of the Principal Act is amended—
          (a) in subsection (2), by the substitution of “on the date specified in subsection (7A)”
              for “at the end of the taxable period during which it is cancelled in accordance
              with subsection (3)”,
         (b) in subsection (6)—
               (i) by the substitution of “Subsections (6) and (7)” for “Subsections (6) to (12)”,
                   and
              (ii) in paragraph (a), by the substitution of “who had a waiver which was cancelled
                   before the date of the passing of the Finance Act 2025” for “who has a
                   waiver”,
          (c) by the insertion of the following subsections after subsection (7):
                  “(7A) A waiver which has not been cancelled before the date of the passing
                        of the Finance Act 2025 shall be cancelled on the date of the passing
                        of that Act.
                      (7B) (a) This subsection applies to a waiver cancelled by virtue of
                               subsection (7A).
                          (b) For the purposes of applying Chapter 2 of Part 8, the adjustment
                              period (within the meaning of section 63(1) or, as the context may
                              require, the period to be treated as the adjustment period in
                              accordance with section 95(12)) in relation to the tax chargeable on
                              the landlord’s acquisition or development of a capital good, where


                                                 104
[2025.]                                  Finance Act 2025.                       [No. 18.] PT.3 S.74

                              that landlord used that capital good in relation to the supply of
                              services to which a waiver applied, shall end on the date specified
                              in subsection (7A).”,
              and
          (d) by the deletion of subsections (3), (4), (8), (9), (10), (11) and (12).

Amendments consequential on amendment of section 96 of Principal Act
75.   The Principal Act is amended—
          (a) in section 15—
               (i) in subsection (5)—
                    (I) by the deletion of “subject to subsection (6),”, and
                    (II) by the deletion of “or does not have a waiver of his or her right to
                         exemption from tax in accordance with section 96(2) to (5) still in effect
                         at the time of cessation”,
                    and
              (ii) by the deletion of subsection (6),
              and
          (b) in section 120(11), by the deletion of paragraph (a).


Amendment of section 115 of Principal Act (penalties generally)
76.   Section 115(1C) of the Principal Act is amended, with effect from 1 January 2026—
          (a) in paragraph (b)—
               (i) by the substitution of “section 85C” for “section 85C, 85F or 85G, as the case
                   may be,” and
              (ii) by the substitution of “that section” for “the section concerned”,
              and
          (b) by the insertion of the following paragraph after paragraph (c):
                          “(d) (i) A payment service provider who does not comply with section
                                   85F(2) shall be liable to a penalty of €4,000.
                             (ii) A payment service provider who fails to provide the information
                                  contained in the records referred to in section 85F(2) in respect
                                  of the calendar quarter to which that information relates (in this
                                  subparagraph referred to as the ‘first-mentioned calendar
                                  quarter’), in the manner specified in section 85G(a), by the end
                                  of the month following each calendar quarter subsequent to the
                                  first-mentioned calendar quarter, shall be liable to a further
                                  penalty of €4,000 in respect of such failure in respect of each


                                                105
PT.3 S.76 [No. 18.]                      Finance Act 2025.                                [2025.]

                                 such subsequent calendar quarter after the first-mentioned
                                 calendar quarter until the payment service provider provides the
                                 information concerned in the manner so specified.”.


Amendment of paragraph 6(2) of Schedule 1 to Principal Act (financial services)
77.   Schedule 1 to the Principal Act is amended, in Part 2, in paragraph 6(2), by the insertion
      of the following clause after clause (ed):
                              “(ee) the automatic enrolment retirement savings system
                                    established, maintained and controlled by An tÚdarás
                                    Náisiúnta um Uathrollú Coigiltis Scoir as provided for in the
                                    Automatic Enrolment Retirement Savings System Act 2024;”.


                                                PART 4

                                              STAMP DUTIES


Definition (Part 4)
78.   In this Part, “Principal Act” means the Stamp Duties Consolidation Act 1999.


Amendment of section 83D of Principal Act (repayment of stamp duty where land used
for residential development)
79. (1) The Principal Act is amended—

          (a) in section 83D—
               (i) in subsection (1)—
                      (I) in paragraph (a)—

                        (A) in the definition of “commencement notice”, by the substitution of
                            the following paragraph for paragraph (a):
                            “(a) a commencement notice within the meaning of article 8 of the
                                 Regulations of 1997, or”,

                        (B) by the substitution of the following definition for the definition of
                            “planning permission”:
                           “ ‘planning permission’ means a permission within the meaning of the
                           Planning and Development Act 2000 or, as the case may be, the
                           Planning and Development Act 2024;”, and
                        (C) by the insertion of the following definition:
                           “ ‘large-scale residential development’ has the same meaning as it has
                           in section 2 of the Planning and Development Act 2000 or, from the


                                                  106
[2025.]                               Finance Act 2025.                      [No. 18.] PT.4 S.79

                      date on which section 82 of the Planning and Development Act 2024
                      comes into operation, as it has in that section;”,
                    and
               (II) by the substitution of the following paragraph for paragraph (b):
                   “(b) References in this section to ‘relevant residential development’
                        shall be construed—
                          (i) in a case in which a claim for a repayment under subsection (8)
                              is, pursuant to subsection (7)(b), made in respect of such of the
                              construction operations as for the time being are being carried
                              out pursuant to a particular commencement notice, as references
                              to the residential development that comprises those construction
                              operations, or
                          (ii) in any other case, as references to the entire residential
                               development concerned.”,
          (ii) in subsection (3)—
                (I) by the substitution of the following paragraph for paragraph (a):
                    “(a) Subject to the provisions of this section, stamp duty paid on an
                         instrument may be repaid in accordance with this section in relation
                         to the land if construction operations on the land commence
                         pursuant to a commencement notice within the period commencing
                         on the date of execution of the instrument and ending—
                          (i) where the residential development concerned is a large-scale
                              residential development, on the date that is 36 months after the
                              date of execution, or
                          (ii) in any other case, on the date that is 30 months after the date of
                               execution.”,
                    and
               (II) by the deletion of paragraph (c),
          (iii) by the insertion of the following subsection after subsection (3):
              “(3A) (a) Notwithstanding subsection (3)(a), the stamp duty repaid under this
                        section shall be liable to the clawback provided for in
                        subsection (12) if—
                          (i) the relevant residential development specified in a commencement
                              notice is not completed within the period commencing on the date
                              of the sending by a building control authority, in accordance with
                              article 10(2) or 20A(3)(b), as the case may be, of the Regulations
                              of 1997, of an acknowledgment in relation to that notice (in this
                              subparagraph referred to as the ‘first-mentioned date’) and
                              ending—


                                             107
PT.4 S.79 [No. 18.]                      Finance Act 2025.                                       [2025.]

                                 (I) where the residential development concerned is a large-scale
                                     residential development, on the date that is 36 months after
                                     the first-mentioned date, or
                                 (II) in any other case, on the date that is 30 months after the
                                      first-mentioned date, and
                             (ii) when completed, the relevant residential development on the
                                  land, being the land to which that relevant residential
                                  development relates, is not such that—
                                 (I) at least 75 per cent of the total surface area of that land is
                                     occupied by dwelling units, or
                                 (II) the gross floor space of dwelling units amounts to at least 75
                                      per cent of the total surface area of that land,
                              and subparagraphs (i) and (ii) are subsequently referred to in this
                              section as the conditions for the avoidance of a clawback under this
                              paragraph.
                          (b) If—
                              (i) the residential development concerned was carried out in a
                                  phased manner such that there were 2 or more commencement
                                  notices in respect of the construction operations on the land, and
                             (ii) the repayment claimed under subsection (8) was not made in
                                  respect of such of the construction operations that were carried
                                  out pursuant to a particular commencement notice pursuant to
                                  subsection (7)(b),
                              the reference in paragraph (a)(i) to a commencement notice shall be
                              construed as a reference to the last of those commencement
                              notices.”,
             (iv) in subsection (4)(a), by the substitution of “(3A)(a)(ii)” for “(3)(c)(ii)”,
              (v) in subsection (5)(a)—
                      (I) in subparagraph (ii), by the substitution of “subsection (3A)(a)” for
                          “paragraph (c) of that subsection”, and
                  (II) by the substitution of “the period specified in subsection (3)(a), (3A)(a)
                       (i) or (4)(b), as the case may be,” for “the period of 30 months specified
                       in subsection (3)(a) or the period of 30 months specified in
                       subsection (3)(c)(i) or (4)(b)”,
             (vi) in subsection (7)(b), by the deletion of “, without prejudice to the accountable
                  person’s right to defer making a claim until completion of the residential
                  development concerned,”,
             (vii) in subsection (8), by the substitution of the following paragraph for
                   paragraph (e):


                                                108
[2025.]                                Finance Act 2025.                       [No. 18.] PT.4 S.79

                       “(e) not be made—
                            (i) until such time as construction operations have commenced
                                pursuant to a commencement notice, and
                           (ii) notwithstanding anything in subsection (7)(b), after the expiry
                                of 4 years following the commencement of the period specified
                                in subsection (3A)(a)(i) or, as the case may be, subsection (4)
                                (b).”,
            (viii) in subsection (9), by the substitution of “under subsection (3A)(a)” for “under
                   paragraph (c) of subsection (3)”,
              (ix) in subsection (10), by the substitution of the following paragraph for
                   paragraph (c):
                       “(c) not be made where, were repayment to be made, the accountable
                            person would be immediately liable to pay to the Commissioners
                            the stamp duty repaid in accordance with subsection (12)(a).”,
              (x) in subsection (12), by the substitution of “the conditions specified in paragraph
                  (a) of subsection (3A) for the avoidance of a clawback under that paragraph”
                  for “the conditions specified in paragraph (c) of subsection (3) for the
                  avoidance of a clawback under that paragraph”, and

              (xi) in subsection (18), by the substitution of “31 December 2030” for “31
                   December 2025”,
              and
          (b) in section 159A(2)(v), by the substitution of “section 83D(8)(e)(ii)” for
              “section 83D(10)(c)”.
      (2) The amendments effected by subsection (1) shall not apply to any claim for repayment
          of stamp duty made under section 83D of the Principal Act prior to the coming into
          operation of this section.


Miscellaneous amendments to Principal Act
80.   The Principal Act is amended—
          (a) by the repeal of section 110A,
          (b) in section 125C, by the insertion of the following subsection after subsection (7):
                    “(8) For the purposes of this section, a reference to a relevant policy shall
                         not include a reference to a policy of insurance, being insurance of a
                         class specified in Part A of Annex I to the European Communities
                         (Life Assurance) Framework Regulations 1994 (S.I. No. 360 of 1994),
                         which provides for—
                        (a) periodic payments to an individual in the event of loss or
                            diminution of income in consequence of ill health, or


                                               109
PT.4 S.80 [No. 18.]                        Finance Act 2025.                                     [2025.]

                            (b) the payment of an amount or amounts to an individual in
                                consequence of ill health, disability, accident or hospitalisation.”,
              and
          (c) in Schedule 1—
               (i) in the Heading “CONVEYANCE or TRANSFER on sale of any property other
                   than stocks or marketable securities or a policy of insurance or a policy of life
                   insurance”, in paragraph (1)(b) by the substitution of the following clause for
                   clause (i):
                    “

                      (i)    for the consideration which is      1 per cent of the first €1,000,000 of
                             attributable to residential         the consideration, 2 per cent of the
                             property other than that referred   next €500,000 of the consideration
                             to in clause (ii) or (iii);         and 6 per cent of the balance of the
                                                                 consideration thereafter, but where
                                                                 the calculation results in an amount
                                                                 which is not a multiple of €1 the
                                                                 amount so calculated shall be
                                                                 rounded down to the nearest €.
                                                                                                         ”,

                    and

              (ii) in the heading “LEASE”, in paragraph (3)(a)(i) by the substitution of the
                   following subclause for subclause (I):


                    “

                      (I)    for the consideration which is      1 per cent of the first €1,000,000 of
                             attributable to residential         the consideration, 2 per cent of the
                             property other than that            next €500,000 of the consideration
                             referred to in subclause (II) or    and 6 per cent of the balance of the
                             (III);                              consideration thereafter, but where the
                                                                 calculation results in an amount which
                                                                 is not a multiple of €1 the amount so
                                                                 calculated shall be rounded down to
                                                                 the nearest €.
                                                                                                       ”.


Land: special provisions
81.   The Principal Act is amended—

          (a) in section 31A, by the insertion of the following subsection after subsection (4):

                      “(5) The contract or agreement referred to in subsection (1) shall be
                           deemed to be executed on the date on which the contract or agreement


                                                   110
[2025.]                                   Finance Act 2025.                      [No. 18.] PT.4 S.81

                            becomes chargeable with stamp duty in accordance with that
                            subsection.”,
          (b) in section 31B, by the insertion of the following subsection after subsection (3):
                    “(4) The agreement referred to in subsection (2) shall be deemed to be
                         executed on the date on which the agreement becomes chargeable with
                         stamp duty in accordance with that subsection.”,
          (c) in section 31E(2)—
               (i) in paragraph (f), by the deletion of “and”,
              (ii) in paragraph (g), by the substitution of “the instrument,” for “the instrument.”,
                   and
             (iii) by the insertion of the following paragraphs after paragraph (g):
                          “(h) in the case of a contract or agreement, referred to in section 31A,
                               for the sale of an estate or interest in the residential unit, on the
                               date the contract or agreement, as the case may be, is deemed to be
                               executed in accordance with subsection (5) of that section, and
                           (i) in the case of an agreement for a lease or with respect to a letting,
                               referred to in section 50A, of the residential unit for any term
                               exceeding 35 years, on the date the agreement is deemed to be
                               executed in accordance with subsection (3) of that section.”,
              and
          (d) in section 50A—
               (i) by the substitution of the following subsection for subsection (2):
                    “(2) The stamp duty paid on any agreement for a lease or with respect to a
                         letting, in accordance with subsection (1), shall, on an application to
                         the Commissioners and subject to section 159A, be repaid by the
                         Commissioners where it is shown to the satisfaction of the
                         Commissioners that the agreement has been rescinded or annulled.”,
                    and
              (ii) by the insertion of the following subsection after subsection (2):
                    “(3) The agreement referred to in subsection (1) shall be deemed to be
                         executed on the date on which the agreement becomes chargeable with
                         stamp duty in accordance with that subsection.”.


Amendment of Part 7 of Principal Act (Exemptions and Reliefs from Stamp Duty)
82. (1) The Principal Act is amended—
          (a) by the repeal of section 86A, and
          (b) by the insertion of the following section before section 87:


                                                 111
PT.4 S.82 [No. 18.]                            Finance Act 2025.                                     [2025.]

                  “Market capitalisation
                   86B. (1) In this section—
                              ‘Directive’ means Directive 2014/65/EU of the European Parliament
                              and of the Council of 15 May 201445 on markets in financial
                              instruments and amending Directive 2002/92/EC and Directive
                              2011/61/EU;
                              ‘issuer’ has the meaning given to it by subsection (2)(a)(ii);
                              ‘multilateral trading facility’ has the same meaning as it has in Article
                              4(1), point (22), of the Directive;
                              ‘notification’ means a notification made under paragraph (a) or (b), as
                              the case may be, of subsection (2);
                              ‘notification date’        shall   be   construed     in   accordance     with
                              subsection (6);
                              ‘operator’ has the meaning given to it by subsection (2)(a);
                              ‘rate of exchange’ means a rate at which 2 currencies might reasonably
                              be expected to be exchanged for each other by persons dealing at
                              arm’s length;
                              ‘regulated market’ has the same meaning as it has in Article 4(1), point
                              (21), of the Directive;
                              ‘relevant market’ means—
                               (a) a regulated market,
                               (b) a multilateral trading facility, or
                               (c) a market located outside the European Union that is equivalent to
                                   a regulated market or multilateral trading facility, as the case may
                                   be;
                              ‘relevant securities’ means stocks or marketable securities;
                              ‘valid notification’ shall         be    construed    in   accordance     with
                              subsection (5).

                         (2) For the purposes of this section—
                             (a) where, on 1 December in a particular year—
                                   (i) relevant securities are admitted to trading on a relevant market,
                                       whether on or before that date, and
                                   (ii) the closing market capitalisation of the issuer of the relevant
                                        securities (in this section referred to as the ‘issuer’) on that date
                                        is less than €1 billion,
                                    the operator of the relevant market (in this section referred to as the
45 OJ No. L173, 12.6.2014, p.349


                                                       112
[2025.]                     Finance Act 2025.                       [No. 18.] PT.4 S.82

                 ‘operator’) or the issuer may, in respect of those relevant securities
                 for that particular year, make a notification to the Commissioners
                 stating the closing market capitalisation of the issuer on that date,
                 or
             (b) where, after 1 December in a particular year and before
                 1 December of the following year—
                (i) relevant securities are to be admitted to trading on a relevant
                    market, and
                (ii) the expected market capitalisation of the issuer upon admission
                     to the relevant market is less than €1 billion,
                 the operator or the issuer may, in respect of those relevant
                 securities for that particular year, make a notification to the
                 Commissioners stating the expected market capitalisation of the
                 issuer upon admission to the relevant market.

          (3) Where a valid notification in respect of relevant securities for a
              particular year is made under paragraph (a) or (b), as the case may be,
              of subsection (2), stamp duty shall not be chargeable on a conveyance
              or transfer of those relevant securities if—
             (a) subject to subsection (4), the conveyance or transfer is executed in
                 the period commencing on the later of—
                (i) 1 January of the year following that particular year, or
                (ii) 14 days after the notification date,
                 and ending on 31 December of the year following that particular
                 year, and
             (b) at the date of execution of the conveyance or transfer, the relevant
                 securities are admitted to trading on a relevant market.
          (4) Where a valid notification in respect of relevant securities for a
              particular year is made under subsection (2)(b) and the relevant
              securities are admitted to trading on a relevant market in the period
              commencing on 2 December and ending on 31 December in that
              particular year, the period referred to in subsection (3)(a) shall be
              treated as if it commenced on the later of—
             (a) the date of admission to the relevant market, or
             (b) 14 days after the notification date.
          (5) A notification made in respect of relevant securities for a particular
              year under paragraph (a) or (b), as the case may be, of subsection (2)
              shall be a valid notification for the purposes of this section where—
             (a) the notification is made in such form and manner as the
                 Commissioners may specify, and

                                    113
PT.4 S.82 [No. 18.]                     Finance Act 2025.                                   [2025.]

                         (b) such information, if any, as may reasonably be required by the
                             Commissioners in relation to the notification has been provided to
                             the Commissioners by the operator or the issuer, as the case may
                             be.
                      (6) For the purposes of this section, the notification date in respect of
                          relevant securities for a particular year is—
                         (a) where a valid notification in respect of those relevant securities for
                             the particular year is made by either, but not both, the operator or
                             the issuer, the date on which that valid notification is made by the
                             operator or the issuer, as the case may be, in respect of those
                             relevant securities, or
                         (b) where a valid notification in respect of those relevant securities for
                             the particular year is made by both the operator and the issuer, the
                             date on which the earlier of the valid notifications is made.
                      (7) The Commissioners shall, as soon as is practicable after a valid
                          notification in respect of relevant securities for a particular year is
                          made, publish details of the information set out in the valid
                          notification and the date on which the valid notification was made.
                      (8) For the purposes of this section, where the closing market
                          capitalisation or, the expected market capitalisation, as the case may
                          be, of an issuer is in a currency other than the currency of the State, it
                          shall be expressed in terms of the currency of the State by reference to
                          the average rate of exchange of the currency of the State for the other
                          currency for that day.
                      (9) This section applies as respects conveyances or transfers of relevant
                          securities executed no later than 31 December 2030.”.
      (2) Subsection (1) shall come into operation on 1 January 2026.



Amendment of section 126AB of Principal Act (further levy on certain financial
institutions)
83.   Section 126AB of the Principal Act is amended—
          (a) in subsection (1), by the substitution of the following definition for the definition
              of “base year”:
                          “ ‘base year’ means—
                            (a) in respect of each of the years 2024 and 2025, the year 2022,
                                and
                            (b) in respect of the year 2026, the year 2024;”,
          (b) in subsection (2), by the substitution of “each of the years 2024 to 2026 (both
              years inclusive)” for “each of the years 2024 and 2025”, and


                                                114
[2025.]                                Finance Act 2025.                        [No. 18.] PT.4 S.83

          (c) by the substitution of the following subsection for subsection (3):
                   “(3) There shall be charged on every statement delivered under
                        subsection (2) a stamp duty of an amount equal to—
                           (a) for the years 2024 and 2025, 0.112 per cent of the assessable
                               amount shown in the statement, and
                           (b) for the year 2026, 0.1025 per cent of the assessable amount
                               shown in the statement.”.


Levy on authorised insurers
84. (1) The Principal Act is amended—
          (a) in section 125A—
              (i) in subsection (1), by the substitution of the following definition for the
                  definition of “relevant contract”:
                         “ ‘relevant contract’ means a contract of insurance (not being an
                         excluded contract of insurance) between an authorised insurer and an
                         individual (in this section referred to as ‘the relevant individual’)
                         which provides for the making of in-patient indemnity payments under
                         the contract and which, in relation to the relevant individual, the
                         spouse or civil partner of the relevant individual, or the children or
                         other dependents of the relevant individual or of the spouse or civil
                         partner of the relevant individual, provides specifically, whether in
                         conjunction with other benefits or not, for the reimbursement or
                         discharge, in whole or in part, of actual health expenses (within the
                         meaning of section 469 of the Taxes Consolidation Act 1997), being a
                         contract of medical insurance;”,
              (ii) by the substitution of the following subsection for subsection (2):
                   “(2) Subject to subsection (7), an authorised insurer shall, in respect of
                        each accounting period and not later than the due date, deliver to the
                        Commissioners a statement showing the number of insured persons in
                        respect of whom a relevant contract was renewed, or entered into,
                        during the accounting period concerned, where the insured person
                        was—
                        (a) aged less than 18 years on the day the relevant contract was
                            renewed or entered into and the relevant contract provides for
                            non-advanced cover,
                        (b) aged 18 years or over on the day the relevant contract was renewed
                            or entered into and the relevant contract provides for non-advanced
                            cover,
                        (c) aged less than 18 years on the day the relevant contract was
                            renewed or entered into and the relevant contract provides for
                            advanced cover, and

                                               115
PT.4 S.84 [No. 18.]                      Finance Act 2025.                                   [2025.]

                          (d) aged 18 years or over on the day the relevant contract was renewed
                              or entered into and the relevant contract provides for advanced
                              cover.”,
             (iii) in subsection (4), by the substitution of “stamp duty” for “duty”,
             (iv) in subsection (6), by the substitution of “in addition to the stamp duty” for “in
                  addition to the duty”,
              (v) in subsection (9), by the substitution of “Any stamp duty or interest charged
                  under this section, or any penalty applied under section 134A in relation to a
                  statement required to be delivered under this section,” for “The stamp duty,
                  interest and penalty payable under this section”,
             (vi) by the deletion of subsections (10) and (11),
             (vii) in subsection (12)(a), by the deletion of “by an individual referred to in the
                   definition of ‘insured person’”, and
            (viii) by the insertion of the following subsections after subsection (13):
                  “(14) Where an authorised insurer is required to pay stamp duty pursuant to
                        subsection (4) in relation to an insured person in respect of whom a
                        relevant contract has been renewed or entered into during an
                        accounting period, the authorised insurer may charge to the relevant
                        individual an amount equal to the amount of stamp duty payable.
                      (15) (a) Where, in respect of any accounting period—
                              (i) an insured person is included in the number of insured persons
                                  shown on a statement delivered to the Commissioners pursuant
                                  to subsection (2) by virtue of a relevant contract having been
                                  entered into, or renewed, during the accounting period
                                  concerned,
                             (ii) stamp duty is paid by the authorised insurer on the delivery of
                                  the statement pursuant to subsection (4), and
                            (iii) during the period of 12 months commencing on the day the
                                  relevant contract was renewed or entered into (in this paragraph
                                  referred to as the ‘relevant period’), the insured person ceases to
                                  be insured under the relevant contract,
                              the authorised insurer shall, on a claim being made to the
                              Commissioners in accordance with paragraph (b) and subject to
                              section 159A, be entitled to a repayment of stamp duty determined
                              by the formula—

                                                       AX B
                                                          12

                              where—
                              A is the amount of stamp duty paid by the authorised insurer, and

                                                116
[2025.]                     Finance Act 2025.                      [No. 18.] PT.4 S.84

                  B is the number of complete months that remain in the relevant
                  period immediately following the date on which the insured person
                  ceases to be insured under the relevant contract.
              (b) A claim for repayment of stamp duty under paragraph (a) shall be
                  made by the authorised insurer in the statement that the authorised
                  insurer is required to deliver to the Commissioners pursuant to
                  subsection (2) in respect of the accounting period during which the
                  insured person ceases to be insured under the relevant contract.
              (c) For the purposes of paragraph (a), if, on the date the insured person
                  ceases to be insured under the relevant contract, a person (in this
                  paragraph referred to as ‘the successor’) other than the authorised
                  insurer that delivered the statement to the Commissioners on which
                  the insured person was included carries on the business that
                  required the delivery of that statement, the successor shall be
                  treated as if it were the authorised insurer that delivered the
                  statement.
          (16) Without prejudice to section 960H of the Taxes Consolidation Act
               1997, where an authorised insurer is entitled to a repayment of stamp
               duty pursuant to a claim made in accordance with subsection (15), the
               Collector-General may, instead of making the repayment, set the
               amount of the repayment against any stamp duty that is payable by the
               authorised insurer pursuant to subsection (4) in respect of the
               accounting period during which the insured person ceased to be
               insured under the relevant contract.
          (17) Where, in relation to an insured person—
              (a) an authorised insurer is entitled to a repayment of stamp duty
                  pursuant to a claim made in accordance with subsection (15), and
              (b) any of the following conditions is satisfied—
                 (i) the repayment is made to the authorised insurer;
                 (ii) the Collector-General has, in accordance with subsection (16),
                      set the repayment against stamp duty that is payable by the
                      authorised insurer; or
                (iii) the Collector-General has set or withheld the repayment
                      pursuant to section 960H of the Taxes Consolidation Act 1997,
                  then, the authorised insurer shall, to the extent that the relevant
                  individual paid to the authorised insurer the amount referred to in
                  subsection (14), pay to the relevant individual the amount
                  determined by the formula—

                                          A–B+C

                  where—


                                    117
PT.4 S.84 [No. 18.]                       Finance Act 2025.                                    [2025.]

                               A is the amount paid by the relevant individual to the authorised
                               insurer in relation to that insured person in respect of the
                               accounting period pursuant to subsection (14),
                               B is the amount of stamp duty paid by the authorised insurer in
                               relation to that insured person in respect of the accounting period
                               pursuant to subsection (4), and
                               C is the amount of the repayment.”,
              and
          (b) in section 159A(2)(c)—
               (i) in subparagraph (vi), by the deletion of “or”,
              (ii) in subparagraph (vii), by the substitution of “section 83DB, or” for
                   “section 83DB.”, and
              (iii) by the insertion of the following subparagraph after subparagraph (vii):
                          “(viii) for the purposes of section 125A(15), the date the insured
                                  person (within the meaning of section 125A) ceased to be
                                  insured under the relevant contract (within the meaning of
                                  section 125A).”.
      (2) Subsection (1) shall come into operation on 1 April 2027.


Amendment of section 81AA of Principal Act (transfers to young trained farmers)
85.   Section 81AA of the Principal Act is amended, in subsection (16), by the substitution of
      “31 December 2029” for “31 December 2025”.


Amendment of section 81C of Principal Act (further farm consolidation relief)
86. (1) Section 81C of the Principal Act is amended—
          (a) in subsection (1)—
               (i) in paragraph (a)—
                      (I) in the definition of “conditions of consolidation”, by the substitution of
                          “guidelines made and published pursuant to paragraph (b)(i)” for
                          “guidelines”,
                    (II) in the definition of “consolidation certificate”, by the substitution of
                         “guidelines made and published pursuant to paragraph (b)(i)” for
                         “guidelines”,
                    (III) by the deletion of the definition of “guidelines”,
                  (IV) in the definition of “relevant land”, by the substitution of “agricultural
                       land, including woodland, situated in the State” for “agricultural land,
                       including lands suitable for occupation as woodlands on a commercial
                       basis, in the State”,

                                                 118
[2025.]                                  Finance Act 2025.                     [No. 18.] PT.4 S.86

                    (V) in the definition of “relevant period”, by the substitution of “31
                        December 2029” for “31 December 2025”, and
                 (VI) by the insertion of the following definition:
                            “ ‘conservation’ has the same meaning as it has in the European
                            Communities (Birds and Natural Habitats) Regulations 2011 (S.I. No.
                            477/2011);”,
                    and
              (ii) in paragraph (b), by the substitution of “Minister for Agriculture, Food and the
                   Marine” for “Minister for Agriculture and Food”,
          (b) in subsection (6), by the substitution of the following paragraph for
              paragraph (b):
                          “(b) use the qualifying land—
                              (i) for farming, or
                             (ii) in the case of qualifying land consisting of woodland (other than
                                  woodland occupied on a commercial basis), for conservation
                                  purposes in accordance with guidelines made and published by
                                  the Minister for Agriculture, Food and the Marine,”,
              and
          (c) in subsection (12), by the substitution of “31 December 2029” for “31 December
              2025”.
      (2) Subsection (1) shall come into operation on such day or days as the Minister for
          Finance may, by order, appoint.


                                              PART 5

                                      CAPITAL ACQUISITIONS TAX


Definition (Part 5)
87.   In this Part, “Principal Act” means the Capital Acquisitions Tax Consolidation Act 2003.


Amendment of section 41 of Principal Act (when interest in assurance policy becomes
interest in possession)
88. (1) Section 41 of the Principal Act is amended—
          (a) in subsection (1), by the substitution of “Subject to subsection (1A), for the
              purposes of this Act” for “For the purposes of this Act”, and
          (b) by the insertion of the following subsection after subsection (1):
                    “(1A) For the purposes of this Act, where an interest in a policy of assurance
                          on human life is disposed of in whole or in part prior to the occurrence

                                                    119
PT.5 S.88 [No. 18.]                      Finance Act 2025.                                   [2025.]

                           of either of the events specified in paragraph (a) or (b) of
                           subsection (1), then the interest or, as the case may be, that part of the
                           interest, is deemed to become an interest in possession at the time of
                           the disposal.”.
     (2) Subsection (1) shall apply to a disposal referred to in subsection (1A) (inserted by
         subsection (1)(b)) of section 41 of the Principal Act made on or after 1 January 2026.


Amendment of Chapter 2 of Part 10 of Principal Act (business relief)
89. (1) The Principal Act is amended—
          (a) in section 100, by the substitution of the following subsection for subsection (2):
                      “(2) (a) An asset is an excepted asset in relation to any relevant business
                               property unless it was—
                              (i) used wholly or mainly for the purposes of the business
                                  concerned throughout the whole, or the last 2 years, of the
                                  relevant period, or
                             (ii) subject to paragraph (b), required at the date of a gift or
                                  inheritance to be used for a specific purpose of the business
                                  concerned within the period of 6 years commencing on that
                                  date,
                              but where the business concerned is carried on by a company which
                              is a member of a group, the use of an asset for the purposes of a
                              business carried on by another company which at the time of the
                              use and immediately prior to the gift or inheritance was also a
                              member of that group is treated as use for the purposes of the
                              business concerned, unless that other company's membership of the
                              group is to be disregarded under section 99.
                          (b) Notwithstanding paragraph (a)(ii), where, at the date of a gift or
                              inheritance, an asset is required to be used for a specific purpose of
                              the business concerned within the period of 6 years commencing on
                              that date, but the asset is not so used within that period, it shall be
                              presumed, unless the contrary is shown, that the asset was an
                              excepted asset in relation to any relevant business property and the
                              taxable value of the gift or inheritance shall be determined
                              accordingly.
                          (c) Where the taxable value of a gift or inheritance is to be determined
                              in accordance with paragraph (b), an additional return shall be
                              delivered to the Commissioners, and any outstanding tax paid, in
                              accordance with section 46(9).”,
              and
         (b) in section 101, by the substitution of the following subsection for subsection (2):
                      “(2) (a) The reduction which would fall to be made under section 92 in

                                                 120
[2025.]                              Finance Act 2025.                       [No. 18.] PT.5 S.89

                          respect of relevant business property comprised in a gift or
                          inheritance shall cease to be applicable if and to the extent that the
                          property, or any property which directly or indirectly replaces it—
                         (i) would not be relevant business property (apart from section 94
                             and the conditions attached to paragraphs (d) and (f) of
                             section 93(1) and other than by reason of bankruptcy or a bona
                             fide winding-up on grounds of insolvency) in relation to a
                             notional gift of such property taken by the same donee or
                             successor from the same disponer at any time within the
                             relevant period, unless it would be relevant business property
                             (apart from section 94 and the conditions attached to
                             paragraphs (d) and (f) of section 93(1)) in relation to another
                             such notional gift taken within a year after the first-mentioned
                             notional gift, or

                         (ii) is disposed of in whole or in part within the relevant period and
                              the full proceeds of the disposal are not used, within a year after
                              the disposal, to replace the asset disposed of with other property
                              (other than quoted shares or securities or unquoted shares or
                              securities to which section 99(2)(b) relates) which would be
                              relevant business property (apart from section 94 and the
                              condition attached to section 93(1)(d)) in relation to a notional
                              gift of that other property taken by the same donee or successor
                              from the same disponer on the date of the replacement,

                          and tax is chargeable in respect of the gift or inheritance as if the
                          property were not relevant business property, but—
                         (I) any land, building, machinery or plant which are comprised in
                             the gift or inheritance, and which qualify as relevant business
                             property by virtue of section 93(1)(e) shall, together with any
                             similar property which has replaced such property, continue to
                             be relevant business property for the purposes of this section for
                             so long as they are used for the purposes of the business
                             concerned, and
                        (II) this section shall not have effect where the donee or successor
                             dies before the event which would otherwise cause the reduction
                             to cease to be applicable.
                      (b) For the purposes of paragraph (a)(ii), where less than full
                          consideration is received for the disposal, the full proceeds of the
                          disposal shall be deemed to be an amount equal to the market value
                          of the property disposed of immediately before the disposal.”.
     (2) Subsection (1) shall not apply in relation to gifts or inheritances taken before
         1 January 2026.




                                             121
PT.5 [No. 18.]                             Finance Act 2025.                                [2025.]

Assessment of executors and administrators
90. (1) The Taxes Consolidation Act 1997 is amended—
          (a) in section 1048—
                 (i) by the substitution of the following subsection for subsection (2):
                       “(2) Subject to subsection (2A), no assessment under this section shall be
                            made later than 3 years after the expiration of the year of assessment
                            in which the deceased person died in a case in which the grant of
                            probate or letters of administration was made in that year, and no such
                            assessment shall be made later than 2 years after the expiration of the
                            year of assessment in which such grant was made in any other case.”,
                       and
                 (ii) by the insertion of the following subsection after subsection (2):
                    “(2A) (a) In this subsection—
                                 ‘applicant’ has the same meaning as it has in the Regulations of
                                 2020;
                                 ‘Regulations of 2020’ means the Capital Acquisitions Tax
                                 (Electronic Probate) Regulations 2020 (S.I. No. 341 of 2020).

                             (b) Notwithstanding subsection (2), where, in accordance with
                                 paragraph (3) of Regulation 3 of the Regulations of 2020, an
                                 applicant is required to rectify a material error or omission in
                                 information delivered to the Revenue Commissioners in accordance
                                 with paragraph (1) of the said Regulation, an assessment under this
                                 section may be made at any time before the expiration of 2 years
                                 after the end of the year of assessment in which the material error
                                 or omission is so rectified.”,
                 and
          (b) in section 1077D(2), by the substitution of “subsection (2) or (2A), as the case
              may be,” for “subsection (2)”.
     (2) Subsection (1) shall not apply where, in accordance with Regulation 3(3) of the
         Capital Acquisitions Tax (Electronic Probate) Regulations 2020 (S.I. No. 341 of
         2020), an applicant (within the meaning of the said Regulations) rectifies a material
         error or omission in information delivered to the Revenue Commissioners, in
         accordance with Regulation 3(1) of the said Regulations, prior to 1 January 2026.




                                                  122
[2025.]                                  Finance Act 2025.                                [No. 18.]

                                              PART 6

                                           MISCELLANEOUS


Definition (Part 6)
91.   In this Part, “Principal Act” means the Taxes Consolidation Act 1997.


Implementation of Part I of OECD (2023) International Standards for Automatic
Exchange of Information in Tax Matters: Crypto-Asset Reporting Framework
92.   Chapter 3 of Part 38 of the Principal Act is amended by the insertion of the following
      section after section 891H:
          “891HA. (1) This section provides for the collection and reporting of certain
                      information by Reporting Crypto-Asset Service Providers in respect of
                      Crypto-Asset Users that are Reportable Users or that have Controlling
                      Persons that are Reportable Persons.
                      (2) (a) In this section—
                              ‘CARF’ means Part I of the OECD (2023), International Standards
                              for Automatic Exchange of Information in Tax Matters:
                              Crypto-Asset Reporting Framework and 2023 update to the
                              Common Reporting Standard published by the Organisation for
                              Economic Cooperation and Development on 8 June 2023;
                              ‘authorised officer’ means an officer of the Revenue Commissioners
                              authorised under subsection (12);
                              ‘reporting period’ means a calendar year;
                              ‘specified return date’ means 31 May in the year following the year
                              in respect of which a return relates.
                         (b) A word or expression which is used in this section and which is
                             also used in the CARF has, unless the context otherwise requires,
                             the same meaning in this section as it has in the CARF.
                      (3) A Reporting Crypto-Asset Service Provider that—
                          (a) carries out Relevant Transactions, and—
                             (i) is an Entity or individual that is resident in the State for tax
                                 purposes,
                            (ii) is an Entity incorporated in the State, and
                                 (I) has legal personality, or
                                (II) has an obligation to file tax returns or tax information
                                     returns in respect of the income of the Entity,
                            (iii) is an Entity that has a place of management in the State, or


                                                 123
PT.6 S.92 [No. 18.]                     Finance Act 2025.                                 [2025.]

                           (iv) is an Entity or an individual that has a regular place of business
                                in the State,
                             or
                         (b) carries out Relevant Transactions in the State through a Branch,
                          shall register, not later than 31 December in the year in which it first
                          becomes a Reporting Crypto-Asset Service Provider, with the Revenue
                          Commissioners as a Reporting Crypto-Asset Service Provider for the
                          purposes of this section.
                      (4) A Crypto-Asset Operator, other than one that satisfies the condition in
                          subparagraph (i) of paragraph (a) of subsection (3) that is required to
                          register with the Revenue Commissioners under that paragraph, that
                          satisfies one or more of the conditions in subparagraphs (ii) to (iv) of
                          that paragraph and that satisfies one or more of those conditions under
                          provisions similar to those subparagraphs in force in another Partner
                          Jurisdiction, shall not be required to register with the Revenue
                          Commissioners under that paragraph where that Crypto-Asset
                          Operator elects to register as a Reporting Crypto-Asset Operator in the
                          other Partner Jurisdiction for the purposes of the CARF and notifies
                          that election in writing, on or before the specified return date, to the
                          Revenue Commissioners.
                      (5) Subject to subsection (6), a Reporting Crypto-Asset Service Provider
                          registered in the State for the purposes of this section shall by the
                          specified return date—
                         (a) make a return to the Revenue Commissioners, and

                         (b) provide to a Reportable User a copy of the information contained in
                             that return in respect of the Reportable User.
                      (6) A return made under subsection (5) shall contain—
                         (a) the following details in respect of the Reporting Crypto-Asset
                             Service Provider:
                             (i) the name;
                            (ii) the address;
                           (iii) the TIN or equivalent identifying number and country of
                                 issuance;
                           (iv) the electronic addresses, including websites;
                            (v) the global legal entity identifier, where available,
                         (b) the following details in respect of Crypto-Asset Users that are
                             Reportable Users:
                             (i) the name;


                                                124
[2025.]                  Finance Act 2025.                          [No. 18.] PT.6 S.92

             (ii) the address;
            (iii) the jurisdiction or jurisdictions of residence;
            (iv) the TIN, where issued by the relevant Reportable Jurisdiction or
                 where it is required under the domestic law of the relevant
                 Reportable Jurisdiction;
             (v) where the Reportable User is an individual, that person’s—
                 (I) date of birth, and
                (II) place of birth, where it is required under the domestic law of
                     the jurisdiction in which that individual is resident,
          (c) in respect of an Entity that has one or more Controlling Persons
              that are Reportable Persons—
             (i) the following details in respect of the Entity:
                 (I) the name;
                (II) the address;
                (III) the jurisdiction of residence;
               (IV) the TIN, where issued by the relevant Reportable
                    Jurisdiction or where it is required under the domestic law
                    of the relevant Reportable Jurisdiction,
                 and
             (ii) the following details in respect of each Controlling Person that
                  is a Reportable Person:
                 (I) the name;
                (II) the address;
                (III) the jurisdiction of residence;
               (IV) the TIN, where issued by the relevant Reportable Jurisdiction
                    or where it is required under the domestic law of the relevant
                    Reportable Jurisdiction;
                (V) the date of birth;
               (VI) the place of birth, where it is required under the domestic
                    law of the jurisdiction in which that individual is resident;
              (VII) the role by virtue of which each Reportable Person is a
                    Controlling Person,
              and

          (d) in respect of each person to which paragraph (b) or (c) applies, the
              following details in respect of each type of Relevant Crypto-Asset


                                 125
PT.6 S.92 [No. 18.]                Finance Act 2025.                                 [2025.]

                        for which the Reporting Crypto-Asset Service Provider has carried
                        out Relevant Transactions during the reporting period:
                        (i) the full name of the Relevant Crypto-Asset;
                       (ii) in respect of acquisitions against Fiat Currency—
                            (I) the aggregate gross amount paid,
                           (II) the aggregate number of units, and
                          (III) the number of Relevant Transactions;
                       (iii) in respect of disposals against Fiat Currency—
                            (I) the aggregate gross amount received,
                           (II) the aggregate number of units, and
                          (III) the number of Relevant Transactions;
                       (iv) in respect of        acquisitions   against   other   Reportable
                            Crypto-Assets—
                            (I) the aggregate fair market value,
                           (II) the aggregate number of units, and
                          (III) the number of Relevant Transactions;
                        (v) in respect of disposals against other Reportable Crypto-Assets—
                            (I) the aggregate fair market value,
                           (II) the aggregate number of units, and
                          (III) the number of Relevant Transactions;
                       (vi) in respect of Reportable Retail Payment Transactions—
                            (I) the aggregate fair market value,
                           (II) the aggregate number of units, and
                          (III) the number of Reportable Retail Payment Transactions;
                      (vii) in respect of transfers to Reportable Users not covered by
                            subparagraphs (ii) and (iv)—
                            (I) the aggregate fair market value,
                           (II) the aggregate number of units, and
                          (III) the number of Relevant Transactions, subdivided by transfer
                                type where known by the Reporting Crypto-Asset Service
                                Provider;

                      (viii) in respect of transfers by the Reportable User not covered by
                             subparagraphs (iii), (v) and (vi)—


                                           126
[2025.]                    Finance Act 2025.                      [No. 18.] PT.6 S.92

                    (I) the aggregate fair market value,
                   (II) the aggregate number of units, and
                  (III) the number of Relevant Transactions, subdivided by transfer
                        type where known by the Reporting Crypto-Asset Service
                        Provider;

                    and
               (ix) in respect of transfers effectuated by the Reporting Crypto-Asset
                    Service Provider to distributed ledger addresses not known to be
                    associated with a virtual asset service provider or financial
                    institution—
                    (I) the aggregate fair market value, and
                   (II) the aggregate number of units.

            (e) For the purposes of the amounts referred to in subparagraphs (ii)
                and (iii) of paragraph (d)—
                (i) those amounts shall be reported in the Fiat Currency in which
                    they were paid or received, as the case may be,
               (ii) where those amounts were paid or received in multiple Fiat
                    Currencies, those amounts shall be converted at the time of each
                    Relevant Transaction in a consistent manner by the Reporting
                    Crypto-Asset Service Provider and reported in one of the Fiat
                    Currencies in which they were paid or received, as the case may
                    be, and


              (iii) the information reported shall identify the Fiat Currency in
                    which each amount is reported.
             (f) For the purposes of paragraphs (iv) to (ix) of subparagraph (d), the
                 fair market value shall be determined and reported in a single Fiat
                 Currency, valued at the time of each Relevant Transaction in a
                 consistent manner by the Reporting Crypto-Asset Service Provider,
                 and the information reported shall identify the Fiat Currency in
                 which each amount is reported.

          (7) A Reporting Crypto-Asset Service Provider registered under this
              section shall follow the due diligence procedures contained in
              Section III of the CARF—
            (a) to determine if—
                (i) Individual Crypto-Asset Users,
               (ii) Entity Crypto-Asset Users, and



                                   127
PT.6 S.92 [No. 18.]                      Finance Act 2025.                                   [2025.]

                            (iii) Controlling Persons,
                              are Reportable Users, and
                          (b) to confirm that self-certifications provided by—
                              (i) Individual Crypto-Asset Users,
                             (ii) Entity Crypto-Asset Users, and
                            (iii) Controlling Persons,
                              are valid self-certifications for the purposes of the CARF.

                       (8) A Reporting Crypto-Asset Service Provider that—
                          (a) is an Entity which satisfies one or more of the conditions in
                              subparagraphs (i) to (iii) of subsection (3)(a) and is resident for tax
                              purposes in a Partner Jurisdiction,
                          (b) is an Entity which satisfies either of the conditions in subparagraph
                              (ii) or (iii) of subsection (3)(a), and—
                              (i) is incorporated, and
                             (ii) either has legal personality or has an obligation to file tax
                                  returns or tax information returns to tax authorities,
                              in a Partner Jurisdiction,
                          (c) is an Entity which satisfies the condition in subparagraph (iii) of
                              subsection (3)(a) and has a place of management in a Partner
                              Jurisdiction,
                          (d) is an individual that satisfies the condition in subparagraph (iii) of
                              subsection (3)(a) and is resident for tax purposes in a Partner
                              Jurisdiction, or
                          (e) carries out Relevant Transactions through a Branch in a Partner
                              Jurisdiction,
                           is not required to carry out the due diligence requirements as set out in
                           subsection (7) or to make a return under subsection (5) where that
                           Reporting Crypto-Asset Service Provider is required to carry out such
                           due diligence and make such a return in relation to Reportable Users
                           and Controlling Persons under provisions similar to this section in
                           force in that Partner Jurisdiction.
                       (9) Subsection (8) shall only apply to a Crypto-Asset Operator that
                           confirms to the Revenue Commissioners, in such form as may be
                           specified by the Revenue Commissioners for this purpose, that the
                           provisions referred to in subsection (8) have been complied with.
                      (10) (a) A Crypto-Asset User, that is not an Excluded Person, shall provide
                               to the Reporting Crypto-Asset Service Provider such information as


                                                 128
[2025.]                      Finance Act 2025.                       [No. 18.] PT.6 S.92

                  is necessary for that Reporting Crypto-Asset Service Provider to
                  comply with the reporting obligations imposed under subsection (5)
                  (referred to in this subsection as the ‘relevant information’).
              (b) Where a Crypto-Asset User fails to provide the relevant
                  information to the Reporting Crypto-Asset Service Provider, the
                  Reporting Crypto-Asset Service Provider shall, subject to
                  paragraph (c), prevent the Crypto-Asset User from performing
                  Relevant Transactions.
              (c) The Crypto-Asset User shall not be prevented from performing
                  Relevant Transactions before—
                  (i) the Reporting Crypto-Asset Service Provider has issued two
                      reminders in writing to the Crypto-Asset User following the
                      initial request for the relevant information required, and
                 (ii) the expiration of 60 days from the date of the second such
                      reminder referred to in subparagraph (i).
          (11) (a) A Reporting Crypto-Asset Service Provider shall retain such
                   records as are required to enable a full and true return to be made
                   for the purposes of this section.
              (b) Without prejudice to the generality of paragraph (a), the records
                  required to be retained under that paragraph shall include, but are
                  not limited to—
                  (i) books, accounts, documents, relating to the return,
                 (ii) a record of the steps undertaken including any information
                      relied upon for the performance of the reporting requirements
                      and due diligence procedures set out in this section or in
                      Sections II and III of the CARF, and
                (iii) any other data relating to the return.
              (c) Records required to be kept or retained under this section shall be
                  kept—
                  (i) in written form in an official language of the State, or
                 (ii) subject to section 887(2), by means of any electronic,
                      photographic or other process.
              (d) Notwithstanding any other law, records required to be retained
                  under this section shall, subject to paragraph (e), be retained by the
                  Reporting Crypto-Asset Service Provider, for the longer of the
                  following periods:
                  (i) where enquiries into a return are made by an authorised officer,
                      the period ending on the day on which those enquiries are
                      treated as completed by the officer;



                                     129
PT.6 S.92 [No. 18.]                      Finance Act 2025.                                  [2025.]

                             (ii) the period of 6 years beginning from the end of the reporting
                                  period to which they relate or, in the case where they relate to
                                  more than one reporting period, the period of 6 years beginning
                                  from the end of the later reporting period.
                          (e) For the purposes of this section, where a Reporting Crypto-Asset
                              Service Provider is a company and the company—
                             (i) is wound up, the liquidator, or
                             (ii) is dissolved without the appointment of a liquidator, the last
                                  directors, including any person occupying the position of
                                  director by whatever named called, of the company,
                              shall retain the records required to be retained under this subsection
                              for a period of 5 years from the date from which the company is
                              wound up or dissolved.
                          (f) A person who fails to comply with this subsection in respect of the
                              retention of any records relating to a return or the steps referred to
                              in paragraph (b)(ii) shall be liable to a penalty of €3,000.

                      (12) The Revenue Commissioners may authorise in writing any of their
                           officers to exercise any powers to perform any acts or discharge any
                           functions conferred by this section.

                      (13) Subject to subsection (14), an authorised officer may—
                          (a) make such enquiries as he or she considers necessary for the
                              purpose of—
                             (i) satisfying himself or herself as to whether information regarding
                                 a Relevant Transaction—

                                 (I) included in a return made under this section by the
                                     Reporting Crypto-Asset Service Provider, was correct and
                                     complete, or
                                (II) not included in such a return was correctly not so included,
                                 and
                             (ii) examining the procedures put in place by the Reporting
                                  Crypto-Asset Service Provider for the purposes of ensuring
                                  compliance with that Reporting Crypto-Asset Service Provider’s
                                  obligations under this section,
                              and
                          (b) at all reasonable times, enter any premises or place of business of a
                              Reporting Crypto-Asset Service Provider for the purpose of
                              carrying out the enquiries referred to in paragraph (a).



                                                130
[2025.]                      Finance Act 2025.                      [No. 18.] PT.6 S.92

          (14) An authorised officer shall not, other than with the consent of the
               occupier, enter a private dwelling without a warrant issued under
               subsection (15) authorising the entry.
          (15) A judge of the District Court, if satisfied on the sworn evidence of an
               authorised officer that—
              (a) there are reasonable grounds for suspecting that any information or
                  records, as the authorised officer may reasonably require for the
                  purposes of his or her functions under this section, is or are held on
                  any premises or part of any premises, and
              (b) an authorised officer, in the performance of his or her functions
                  under this section has been prevented from entering the premises or
                  any part thereof,
               may issue a warrant authorising the authorised officer, accompanied if
               necessary, by other persons, at any time or times within 30 days from
               the date of issue of the warrant and on production if so requested of
               the warrant, to enter, if need be by reasonable force, the premises or
               part of the premises concerned and perform all or any of the functions
               conferred on the authorised officer under this section.
          (16) (a) Section 898O shall apply to—
                  (i) a failure by a Reporting Crypto-Asset Service Provider to make
                      a return required under subsection (5), and
                 (ii) the making of an incorrect or incomplete return under
                      subsection (5),
                  as it applies to a failure to deliver a return or to the making of an
                  incorrect or incomplete return referred to in section 898O.
              (b) A Reporting Crypto-Asset Service Provider who does not comply
                  with the requirements of an authorised officer in the exercise or
                  performance of the officer’s powers or duties under this section
                  shall be liable to a penalty of €1,265.
              (c) Where a Reporting Crypto-Asset Service Provider—
                  (i) fails to register with the Revenue Commissioners as required
                      under this section, or
                 (ii) does not comply with the obligations imposed under
                      subsection (5),
                  the Reporting Crypto-Asset Service Provider shall be liable to a
                  penalty of €4,000.
          (17) This section shall not apply to a Reporting Crypto-Asset Service
               Provider where the Reporting Crypto-Asset Service Provider has
               included the information required under this section in a return made
               under the provisions of section 891M.


                                    131
PT.6 S.92 [No. 18.]                     Finance Act 2025.                                 [2025.]

                      (18) Where arrangements are entered into by any person and it is
                           reasonable to consider that the main purpose or one of the main
                           purposes of the arrangements, or any part of them, is the avoidance of
                           any of the obligations imposed under this section, then this section
                           shall apply as if the arrangements, or that part of them, had not been
                           entered into.
                      (19) This section shall apply to reporting periods commencing on or after 1
                           January 2026.”.


Amendment of section 811C of Principal Act (transactions to avoid liability to tax)
93.   Section 811C of the Principal Act is amended, in subsection (4), by the substitution of the
      following paragraph for paragraph (a):
                         “(a) Where a person—
                              (i) submits any return, declaration, statement or account or makes
                                  any claim which purports to obtain, or
                             (ii) takes or fails to take any other action which, directly or
                                  indirectly, purports to obtain,
                              the benefit of a tax advantage arising out of or by reason of a tax
                              avoidance transaction, a Revenue officer may at any time deny or
                              withdraw the tax advantage.”.


Amendment of section 891F of Principal Act (returns of certain information by financial
institutions)
94.   Section 891F(2) of the Principal Act is amended by the substitution of the following
      definition for the definition of “the standard”:
                           “ ‘the standard’ means the Standard for Automatic Exchange of
                           Financial Account Information approved on 15 July 2014 by the
                           Council of the Organisation for Economic Cooperation and
                           Development and Part II of the OECD (2023), International Standards
                           for Automatic Exchange of Information in Tax Matters: Crypto-Asset
                           Reporting Framework and 2023 update to the Common Reporting
                           Standard published by the Organisation for Economic Cooperation and
                           Development on 8 June 2023;”.


Amendment of Part 4A of Principal Act (Implementation of Council Directive (EU)
2022/2523 of 15 December 2022 on ensuring a global minimum level of taxation for
multinational enterprise groups and large-scale domestic groups in the Union)
95. (1) Part 4A of the Principal Act is amended—
          (a) in section 111A(1)—
               (i) by the substitution of the following definition for the definition of “ultimate
                   parent entity”:

                                                132
[2025.]                                       Finance Act 2025.                      [No. 18.] PT.6 S.95

                                “ ‘ultimate parent entity’ means—
                               (a) an entity that owns, directly or indirectly, a controlling interest in
                                   any other entity and that is not owned, directly or indirectly, by
                                   another entity with a controlling interest in it, or
                               (b) the main entity of a group referred to in paragraph (b) of the
                                   definition in this subsection of ‘group’,
                                but where an entity (hereinafter referred to as ‘the first-mentioned
                                entity’) meets the conditions of paragraph (a) and is included in the
                                consolidated financial statements of another entity that is a member of
                                the MNE group or large-scale domestic group which meets the
                                conditions of paragraph (a), then, the first-mentioned entity shall not
                                be an ultimate parent entity;”,
                        and
                   (ii) by the insertion of the following definitions:
                                “ ‘Directive on Administrative Cooperation’ means Council Directive
                                2011/16/EU of 15 February 201146 as amended by Council Directive
                                2014/107/EU of 9 December 201447, Council Directive (EU)
                                2015/2376 of 8 December 201548, Council Directive (EU) 2016/881 of
                                25 May 201649, Council Directive (EU) 2016/2258 of 6 December
                                201650, Council Directive (EU) 2018/822 of 25 May 2018 51, Council
                                Directive (EU) 2020/876 of 24 June 202052, Council Directive (EU)
                                2021/514 of 22 March 202153, Council Directive (EU) 2023/2226 of
                                17 October 202354 and Council Directive (EU) 2025/872 of 14 April
                                202555;
                                ‘OECD Pillar Two MCAA’ means the document entitled OECD
                                (2025), Tax Challenges Arising from the Digitalisation of the
                                Economy – Multilateral Competent Authority Agreement on the
                                Exchange of GloBE Information, OECD/G20 Inclusive Framework on
                                BEPS, OECD, Paris, published by the OECD on 15 January 2025;”,

             (b) in section 111B(1), in the definition of “OECD Pillar Two guidance”—
                    (i) by the substitution of the following paragraph for paragraph (b):
                              “(b) the document entitled OECD (2025), Tax Challenges Arising from
                                   the Digitalisation of the Economy – Global Anti-Base Erosion
                                   Model Rules (Pillar Two) Examples, OECD, Paris, published by

46   OJ No. L64, 11.3.2011, p.1
47   OJ No. L359, 16.12.2014, p.1
48   OJ No. L332, 18.12.2015, p.1
49   OJ No. L146, 3.6.2016, p.8
50   OJ No. L342, 16.12.2016, p.1
51   OJ No. L139, 5.6.2018, p.1
52   OJ No. L204, 26.6.2020, p.46
53   OJ No. L104, 25.3.2021, p.1
54   OJ L, 2023/2226, 24.10.2023
55   OJ L, 2025/872, 6.5.2025


                                                     133
PT.6 S.95 [No. 18.]                      Finance Act 2025.                                  [2025.]

                              the OECD on 9 May 2025,”,
                  and
              (ii) by the substitution of the following paragraph for paragraph (f):
                         “(f) the document entitled OECD (2025), Tax Challenges Arising from
                              the Digitalisation of the Economy – GloBE Information Return
                              (January 2025): Inclusive Framework on BEPS, OECD/G20 Base
                              Erosion and Profit Shifting Project, OECD Publishing, Paris,
                              published by the OECD on 15 January 2025, and”,
          (c) in section 111N(1)—
               (i) in paragraph (a), by the substitution of “Subject to paragraph (c), the UTPR
                   top-up tax amount arising pursuant” for “The UTPR top-up tax amount arising
                   pursuant”, and
              (ii) by the insertion of the following paragraph after paragraph (b):
                         “(c) Where all of the constituent entities of an MNE group located in
                              the State (in this paragraph referred to as ‘the domestic constituent
                              entities’) consent, the UTPR top-up tax amount of the MNE group
                              arising pursuant to section 111L(1), 111M(1) or 111AZ(1), as the
                              case may be, may be allocated to the domestic constituent entities
                              for a fiscal year in a manner agreed between all of the domestic
                              constituent entities, provided that the full amount of the UTPR
                              top-up tax amount of the MNE group arising pursuant to
                              section 111L(1), 111M(1) or 111AZ(1), as the case may be—
                              (i) is allocated to one or more of the domestic constituent entities
                                  for the fiscal year, and
                             (ii) is paid to the Revenue Commissioners, by the domestic
                                  constituent entities to which such amounts have been allocated,
                                  on or before the specified return date in respect of the fiscal
                                  year.”,
         (d) in section 111O—
               (i) by the substitution of the following subsection for subsection (3):
                      “(3) Where an ultimate parent entity does not prepare financial statements
                           as referred to in paragraph (a), (b) or (c), as the case may be, of the
                           definition of ‘consolidated financial statements’ in section 111A, for
                           the purposes of determining the financial accounting net income or
                           loss of an entity, the financial statements of the ultimate parent entity
                           referred to in paragraph (d) of that definition shall be those that would
                           have been prepared if the ultimate parent entity were required to
                           prepare such consolidated financial statements in accordance with—
                          (a) an acceptable financial accounting standard, or
                          (b) an authorised financial accounting standard, provided that such


                                                 134
[2025.]                                 Finance Act 2025.                       [No. 18.] PT.6 S.95

                             consolidated financial statements are adjusted to prevent any
                             material competitive distortion.”,
                  and

              (ii) in subsection (4), by the substitution of “referred to in subsection (3)(b) or
                   paragraph (c) of the definition, in section 111A, of ‘consolidated financial
                   statements’, as the case may be” for “referred to in subsection (3)”,

          (e) in section 111P(1), by the substitution of the following definition for the
              definition of “excluded equity gain or loss”:
                          “ ‘excluded equity gain or loss’ means a gain, profit or loss, included
                          in the financial accounting net income or loss of the constituent entity,
                          arising from any of the following:
                         (a) gains and losses arising from changes in the fair value of an
                             ownership interest, other than a portfolio shareholding;
                         (b) profits or losses in respect of an ownership interest that is included
                             under the equity method of accounting;
                         (c) gains and losses from the disposal of an ownership interest, other
                             than the disposal of a portfolio shareholding;”,

          (f) in section 111X(8)—
              (i) in paragraph (b), by the substitution of “Except where the tax law or practice
                  of a jurisdiction provides otherwise in respect of the order of offset of losses
                  against a covered tax, for the purposes”, for “For the purposes”, and

              (ii) by the insertion of the following paragraph after paragraph (b):
                        “(c) For the purposes of determining the total deferred tax adjustment
                             amount for a fiscal year, where a loss deferred tax asset arising in a
                             fiscal year (in this paragraph referred to as the ‘originating fiscal
                             year’) is attributable to both a qualifying loss and a loss that is not
                             a qualifying loss, then, the reversal of that loss deferred tax asset
                             shall be attributable to a qualifying loss in the same proportion as
                             the qualifying loss bears to the sum of the qualifying loss and the
                             loss that is not a qualifying loss in the originating fiscal year.”,
          (g) in section 111AH(1), in the definition of “minority-owned constituent entity”, by
              the insertion of “, including where the ultimate parent entity has no direct or
              indirect ownership interest in the constituent entity,” after “the total ownership
              interests of the constituent entity”,
          (h) in section 111AI—
              (i) in subsection (2), by the substitution of “and subject to subsections (3) to (7)”
                  for “and subject to subsections (3) to (6)”,
              (ii) by the substitution of the following subsection for subsection (7):


                                                135
PT.6 S.95 [No. 18.]                      Finance Act 2025.                                    [2025.]

                      “(7) The QDTT Safe Harbour for a jurisdiction shall not apply where the
                           central, state or local government, or their administration or agencies
                           that carry out government functions, of that jurisdiction provides the
                           tax attributes that result in the deferred tax assets and liabilities
                           described in section 111AW(5) and the jurisdiction does not exclude
                           those tax attributes from the computations in determining the total
                           deferred tax adjustment amount or the simplified covered taxes (within
                           the meaning of section 111AJ) under the transitional CbCR safe
                           harbour (within the said meaning) implemented under the laws of that
                           jurisdiction, when calculating the domestic top-up tax implemented
                           under the laws of that jurisdiction.”,
                  and
             (iii) by the insertion of the following subsection after subsection (7):
                      “(8) All relevant information concerning the application of the QDTT Safe
                           Harbour shall be included in the top-up tax information return for the
                           fiscal year in accordance with section 111AAI.”,
          (i) in section 111AJ, by the substitution of the following definition for the definition
              of “simplified covered taxes”:
                           “ ‘simplified covered taxes’ means the aggregate income tax expense
                           of all constituent entities, or joint venture and joint venture affiliates,
                           as the case may be, of an MNE group in a jurisdiction for a fiscal year,
                           as reported in the MNE group’s qualified financial statements,
                           excluding—
                          (a) any tax that is not a covered tax in accordance with section 111T,
                          (b) uncertain tax positions reported in the MNE group’s qualified
                              financial statements, and
                          (c) deferred tax expense attributable to a deferred tax asset or deferred
                              tax liability set out in subsection (5) of section 111AW, or the
                              reversal thereof, in excess of the maximum amount allowed under
                              subsections (7) to (10) of section 111AW.”,
          (j) in section 111AO—
               (i) in subsection (1)—
                      (I) in the definition of “joint venture”—
                        (A) by the substitution of “an ultimate parent entity” for “its ultimate
                            parent entity”, and
                        (B) by the substitution of “that ultimate parent entity” for “the ultimate
                            parent entity”,
                         and
                  (II) by the insertion of the following definition:


                                                 136
[2025.]                                Finance Act 2025.                       [No. 18.] PT.6 S.95

                        “ ‘joint venture group top-up tax’ means the ultimate parent entity’s
                        allocable share of the top-up tax of the joint venture group;”,
                 and
             (ii) by the substitution of the following subsection for subsection (5):
                  “(5) The joint venture group top-up tax for a fiscal year shall be reduced by
                       each parent entity’s allocable share of the top-up tax of each member
                       of the joint venture group that is brought into charge under a qualified
                       IIR for the fiscal year and any remaining amount of top-up tax shall be
                       added to the total UTPR top-up tax amount pursuant to section
                       111N(3).”,
          (k) in section 111AW—
              (i) by the substitution of the following subsection for subsection (1):
                  “(1) In this section—
                        ‘governmental arrangement’ means any agreement, ruling, decree,
                        grant or similar arrangement, including any amendment or
                        modification thereof, with the central, state or local government, or
                        their administration or agencies that carry out government functions,
                        of a jurisdiction which provides an entitlement to a tax credit or other
                        tax relief where a critical aspect of the credit or relief, such as the
                        eligibility thereto or the amount thereof, relies on discretion exercised
                        by that government or their administration or agencies that carry out
                        government functions;
                        ‘grace period’ means—
                       (a) for deferred tax expense attributable to the reversal of a deferred
                           tax asset described in paragraph (a) or (b) of subsection (5), all
                           fiscal years beginning on or after 1 January 2024 and before
                           1 January 2026 but not including a fiscal year that ends after
                           30 June 2027, and
                       (b) for deferred tax expense attributable to the reversal of a deferred
                           tax asset described in paragraph (c) of subsection (5), all fiscal
                           years beginning on or after 1 January 2025 and before 1 January
                           2027 but not including a fiscal year that ends after 30 June 2028;

                        ‘grace period limitation amount’ means the deferred tax expense
                        attributable to the reversal of deferred tax assets described in
                        subsection (5) that does not exceed the aggregate of 20 percent of the
                        amount of each such deferred tax asset originally recorded and taken
                        into account for the purposes of subsection (2) at the lower of the
                        minimum tax rate or the applicable domestic tax rate;
                        ‘transition year’, for a jurisdiction, means the first fiscal year in which
                        an MNE group or large-scale domestic group falls within the scope of


                                              137
PT.6 S.95 [No. 18.]                      Finance Act 2025.                                     [2025.]

                           a qualified IIR, qualified UTPR or qualified domestic top-up tax, in
                           respect of that jurisdiction.”,
              (ii) in subsection (2)(a), by the substitution of “Subject to subsections (5) to (10),
                   when determining the effective tax rate” for “When determining the effective
                   tax rate”,
             (iii) in subsection (2)(e), by the substitution of “Except where the tax law or
                   practice of a jurisdiction provides otherwise in respect of the order of offset of
                   losses against a covered tax, for the purposes” for “For the purposes”,
             (iv) in subsection (2), by the insertion of the following paragraph after
                  paragraph (e):
                         “(f) For the purposes of determining the total deferred tax adjustment
                              amount, as set out in section 111X, where a loss deferred tax asset
                              arising in a fiscal year (in this paragraph referred to as the
                              ‘originating fiscal year’) is attributable to both a qualifying loss
                              and a loss that is not a qualifying loss, then, the reversal of that loss
                              deferred tax asset, as set out in section 111X, shall be attributable
                              to a qualifying loss in the same proportion as the qualifying loss
                              bears to the sum of the qualifying loss and the loss that is not a
                              qualifying loss in the originating fiscal year.”,
                  and
              (v) by the insertion of the following subsections after subsection (4):
                      “(5) For the purposes of subsection (2) and subject to subsection (7), no
                           account shall be taken of the following deferred tax assets or deferred
                           tax liabilities:
                          (a) a deferred tax asset that is attributable to a governmental
                              arrangement concluded or amended after 30 November 2021;
                          (b) a deferred tax asset that is attributable to an election or choice
                              exercised or changed by a constituent entity, joint venture or joint
                              venture affiliate after 30 November 2021 that retroactively changes
                              the treatment of a transaction in determining its taxable income in a
                              jurisdiction, in a taxable period for which an assessment by the tax
                              authority of the jurisdiction was already made or a tax return was
                              already filed;
                          (c) a deferred tax asset or a deferred tax liability arising from a
                              difference in the tax basis and carrying value of an asset or liability
                              if the tax basis or carrying value was established pursuant to a tax
                              chargeable on profits or gains under the law of a jurisdiction that is
                              similar to corporation tax, that was enacted by a jurisdiction, that
                              did not previously impose such a tax, after 30 November 2021 and
                              before the transition year.
                       (6) For the purposes of subsection (2), no account shall be taken of a


                                                 138
[2025.]                               Finance Act 2025.                        [No. 18.] PT.6 S.95

                       deferred tax asset to the extent that it is attributable to a loss that arose
                       more than 5 fiscal years preceding the effective date of introduction of
                       a new tax chargeable on profits or gains under the law of a jurisdiction
                       that is similar to corporation tax, that was enacted by a jurisdiction
                       that did not previously impose such a tax.
                   (7) Subject to subsections (8) and (9), the deferred tax expense
                       attributable to the reversal of a deferred tax asset described in
                       subsection (5) may be taken into account during the grace period but
                       shall not exceed the grace period limitation amount.
                   (8) Subsection (7) shall not apply to a deferred tax expense attributable to
                       the reversal of a deferred tax asset, or portion thereof, to the extent
                       that such deferred tax asset, or portion thereof, results from—
                      (a) a governmental arrangement concluded or amended                      after
                          18 November 2024,
                      (b) an election or choice described in paragraph (b) of subsection (5)
                          exercised or changed by a constituent entity, joint venture or joint
                          venture affiliate after 18 November 2024, or
                      (c) a difference in the tax basis and carrying value of an asset or
                          liability established pursuant to a tax chargeable on profits or gains
                          under the law of a jurisdiction that is similar to corporation tax that
                          was enacted after 18 November 2024.
                   (9) For the purposes of subsection (7), where, after 18 November 2024,
                       there is a change in—
                      (a) a governmental arrangement, or
                      (b) the law, an election or choice, or accounting methodology,
                       that results in an increase in the amount of a deferred tax asset
                       described in subsection (5) that reverses during the grace period, the
                       additional amount that reverses compared to the amount that would
                       have reversed absent such change shall not be taken into account
                       during the grace period.
                 (10) The sum of the total amount of deferred tax expense that is attributable
                      to the reversal of deferred tax assets described in subsection (5) that a
                      constituent entity, joint venture or joint venture affiliate may include
                      when determining the effective tax rate for a jurisdiction in accordance
                      with section 111AC and the calculation of simplified covered taxes
                      under section 111AJ shall not exceed the maximum amount allowable
                      under subsections (7) to (9) during the grace period.”,
          (l) in section 111AAC(4), by the insertion of the following paragraph after
              paragraph (b):
                     “(c) Where paragraph (a) applies and the securitisation entity is a
                          minority-owned constituent entity, within the meaning of section


                                              139
PT.6 S.95 [No. 18.]                   Finance Act 2025.                                   [2025.]

                           111AH, then in determining the domestic top-up tax of all the other
                           qualifying entities, excluding securitisation entities, of the MNE
                           group or large-scale domestic group for the fiscal year, the top-up
                           tax of the securitisation entity calculated in accordance with section
                           111AH for the fiscal year shall be allocated to the other qualifying
                           entities, excluding securitisation entities, in accordance with the
                           formula in section 111AD(5) where ‘JTUT’ is the top-up tax of the
                           securitisation entity calculated in accordance with section 111AH.”,
         (m) in section 111AAD(2), by the substitution of the following paragraph for
             paragraph (e):
                      “(e) there were inserted in section 111O the following subsections after
                           subsection (3):
                       ‘(3A) (a) Notwithstanding subsections (2) and (3) and subject to
                                 subsection (3B), the financial accounting net income or loss
                                 of a qualifying entity for the fiscal year shall be determined
                                 in accordance with a local accounting standard where—
                                  (i) the qualifying entity is an entity within the meaning of
                                      section 111AAB(1)(c), or
                                 (ii) subject to paragraph (b), all of the qualifying entities of
                                      the MNE group, large-scale domestic group or joint
                                      venture group, as the case may be, located in the State
                                      have financial accounts prepared in accordance with a
                                      local accounting standard and the accounting period of
                                      all such accounts is the same as the fiscal year of the
                                      consolidated financial statements of the MNE group,
                                      large-scale domestic group or joint venture group as the
                                      case may be, and—
                                     (I) all such constituent entities are required to prepare or
                                         use such accounts for the purposes of determining
                                         their liability to tax in the State or to comply with any
                                         other law of the State, or
                                    (II) such financial accounts are subject to an external
                                         financial audit.
                             (b) For the purposes of paragraph (a)(ii), where a qualifying
                                 entity of an MNE group, large-scale domestic group or joint
                                 venture group, as the case may be, located in the State has
                                 financial accounts prepared in accordance with a local
                                 accounting standard, but the accounting period of such
                                 financial accounts is not the same as the fiscal year of the
                                 consolidated financial statements of the MNE group,
                                 large-scale domestic group or joint venture group, as the
                                 case may be, as a result of—



                                             140
[2025.]                                         Finance Act 2025.                      [No. 18.] PT.6 S.95

                                            (i) the qualifying entity being formed or created, or in the
                                                case of a permanent establishment being established,
                                                during the fiscal year,
                                            (ii) the qualifying entity being liquidated, dissolved or
                                                 otherwise ceasing to exist during the fiscal year,
                                           (iii) a merger or division, within the meaning, respectively,
                                                 of section 638A(1), in relation to the qualifying entity
                                                 during the fiscal year,
                                           (iv) a cross-border merger or cross-border division, both
                                                within the meaning, respectively, of the European Union
                                                (Cross-Border Conversions, Mergers and Divisions)
                                                Regulations 2023 (S.I. No. 233 of 2023), or a merger
                                                resulting in the formation of a Societas Europaea in
                                                accordance with the SE Regulation, in relation to the
                                                qualifying entity during the fiscal year, or
                                            (v) the qualifying entity being acquired by the MNE group,
                                                large-scale domestic group or joint venture group, as the
                                                case may be, during the fiscal year,
                                            then, for the purposes of paragraph (a)(ii), the accounting
                                            period of the financial accounts of the qualifying entity shall
                                            be deemed to be the same as the fiscal year of the
                                            consolidated financial statements of the MNE group, large-
                                            scale domestic group or joint venture group, as the case may
                                            be, for that fiscal year and, where subparagraph (v) applies,
                                            for the fiscal year following the fiscal year in which the
                                            qualifying entity is acquired (referred to in this paragraph as
                                            ‘the subsequent fiscal year’), the accounting period of the
                                            financial accounts of the qualifying entity shall also be
                                            deemed to be the same as the fiscal year of the consolidated
                                            financial statements of the MNE group, large-scale domestic
                                            group or joint venture group, as the case may be, for the
                                            subsequent fiscal year.
                                         (c) In this subsection, ‘SE Regulation’ means Council
                                             Regulation (EC) No. 2157/2001 of 8 October 200156 on the
                                             Statute for a European company (SE), as amended by
                                             Council Regulation (EC) No. 885/2004 of 26 April 2004 57,
                                             Council Regulation (EC) No. 1791/2006 of 20 November
                                             200658 and Council Regulation (EC) No. 517/2013 of 13
                                             May 201359.

                                    (3B) (a) Subject to paragraph (b), where any of the qualifying
56   OJ No. L294, 10.11.2001, p.1
57   OJ No. L168, 1.5.2004, p.1
58   OJ No. L363, 20.12.2006, p.1
59   OJ No. L158, 10.6.2013, p.1


                                                       141
PT.6 S.95 [No. 18.]                  Finance Act 2025.                                  [2025.]

                                  entities of an MNE group, large-scale domestic group or
                                  joint venture group, as the case may be, located in the State
                                  prepare financial accounts under more than one local
                                  accounting standard then, for the purposes of subsection
                                  (3A), the financial accounting net income or loss of a
                                  constituent entity for the fiscal year shall be determined in
                                  accordance with—
                                  (i) the local accounting standard used for the purposes of
                                      determining the profits, losses or gains of the qualifying
                                      entity for the purposes of Case I or II of Schedule D, or
                                 (ii) where no such profits, losses or gains exist, the local
                                      accounting standard used for the preparation of the
                                      financial accounts that are annexed to the annual return
                                      to be filed with the Registrar in accordance with the
                                      Companies Act 2014, for the accounting period which
                                      corresponds to the fiscal year.
                              (b) Where a qualifying entity does not prepare financial
                                  accounts—
                                  (i) for the purposes of determining the profits, losses or
                                      gains of the qualifying entity for the purposes of Case I
                                      or II of Schedule D, or
                                 (ii) that are annexed to the annual return to be filed with the
                                      Registrar in accordance with the Companies Act 2014,
                                      for the accounting period which corresponds to the fiscal
                                      year,
                                  the financial accounting net income or loss of a constituent
                                  entity for the fiscal year shall be determined in accordance
                                  with subsections (2) and (3).’,”,
         (n) in section 111AAI—
               (i) in subsection (1), by the substitution of the following paragraph for
                   paragraph (a):
                      “(a) is in accordance with the standard template set out in Section IV of
                           Annex VII of the Directive on Administrative Cooperation, and”,
              (ii) in subsection (2), by the insertion of the following paragraph after
                   paragraph (c):
                      “(d) For the purposes of paragraph (b), a top-up tax information
                           return—
                          (i) shall be prepared in accordance with—
                              (I) the standard template set out in Section IV of Annex VII of
                                  the Directive on Administrative Cooperation, where the


                                             142
[2025.]                              Finance Act 2025.                       [No. 18.] PT.6 S.95

                                  ultimate parent entity or designated filing entity, as the case
                                  may be, which files the return is located in a Member State,
                                  or
                           (II) the standardised GloBE Information Return set out in the
                                document referred to in paragraph (f) of the definition, in
                                section 111B, of ‘OECD Pillar Two guidance’, where the
                                ultimate parent entity or designated filing entity, as the case
                                may be, which files the return is not located in a Member
                                State,
                            and
                       (ii) is not required to contain the information referred to in
                            paragraphs (da) and (e) of subsection (3).”,
          (iii) in subsection (3), by the insertion of the following paragraph after
                paragraph (d):
                  “(da) where the filing constituent entity is an ultimate parent entity or a
                        designated filing entity, as the case may be—
                        (i) confirmation that it is such an entity, and
                       (ii) the identification of the—
                            (I) relevant sections of the top-up tax information return, and
                           (II) jurisdictions that the information shall be distributed to,
                            pursuant to the dissemination approach set out in—
                           (A) Article 8ae(2) of the Directive on Administrative
                               Cooperation, with respect to information to be exchanged in
                               accordance with that Directive with a jurisdiction that is a
                               Member State, and
                           (B) the definition of ‘dissemination approach’ in the OECD
                               Pillar Two MCAA, with respect to information to be
                               exchanged in accordance with the OECD Pillar Two MCAA
                               with a jurisdiction that is not a Member State;”,
               and
          (iv) by the insertion of the following subsection after subsection (8):
                “(9) Notwithstanding section 851A, the Revenue Commissioners are
                     authorised to communicate to the competent authority of a state, other
                     than the State, information which is contained in a top-up tax
                     information return, received pursuant to a filing made in accordance
                     with section 111AAI, provided that there is a qualifying competent
                     authority agreement in place that provides for the exchange of such
                     information.”,



                                             143
PT.6 S.95 [No. 18.]                      Finance Act 2025.                                 [2025.]

         (o) in section 111AAM, by the insertion of the following subsection after
             subsection (3):

                      “(4) A notice in writing shall not be served under subsection (3) on a
                           relevant UTPR member that is a securitisation entity where there is at
                           least one other relevant UTPR member of the UTPR group that is not a
                           UTPR group filer and is not a securitisation entity.”,
         (p) in section 111AAP, by the insertion of the following subsection after
             subsection (3):
                      “(4) A notice in writing shall not be served under subsection (3) on a
                           relevant QDTT member that is a securitisation entity where there is at
                           least one other relevant QDTT member of the QDTT group that is not
                           a QDTT group filer and is not a securitisation entity.”,
              and
         (q) in section 111AAZ—
               (i) by the substitution of the following subsection for subsection (1):
                      “(1) An entity shall retain, or cause to be retained on behalf of the entity,
                           such records as are required to enable—
                          (a) a full and true GloBE return, and
                          (b) a correct and complete top-up tax information return,
                           to be made for the purposes of this Part.”,
              (ii) in subsection (2), by the substitution of “GloBE return, top-up tax information
                   return” for “GloBE return”,
             (iii) in subsection (6), by the substitution of “GloBE return, top-up tax information
                   return” for “GloBE return”, and
             (iv) by the insertion of the following subsection after subsection (6):
                      “(7) Sections 900 and 901 shall apply, with any necessary modifications—
                              (i) to records referred to in subsection (1) as if they were books,
                                  records or other documents within the meaning of section 900,
                                  and
                             (ii) to information, explanations and particulars that the authorised
                                  officer, within the meaning of those sections, may reasonably
                                  require, being information, explanations and particulars which
                                  are related to, or in connection with, a GloBE return or top-up
                                  tax information return referred to in subsection (1).”.
     (2) Subject to subsection (3), subsection (1) shall apply in respect of a fiscal year (within
         the meaning of section 111A of the Principal Act) or an accounting period, as the case
         may be, commencing on or after 31 December 2025.



                                                144
[2025.]                                     Finance Act 2025.                          [No. 18.] PT.6 S.95

      (3) Paragraphs (a), (b)(ii), (c), (d), (e), (g), (h), (i), (j), (k)(i), (k)(ii), (k)(v), (l), (m), (n),
          (o), (p) and (q) of subsection (1) shall apply in respect of a fiscal year (within the
          meaning of section 111A of the Principal Act) or an accounting period, as the case
          may be, commencing on or after 31 December 2023.


Amendment of section 638A of Principal Act (company mergers and divisions)
96. (1) Section 638A(2) of the Principal Act is amended by the substitution of “Part 4A, 38”
        for “Part 38”.
      (2) Subsection (1) shall be deemed to have come in to operation on 31 December 2023.


Amendment of section 851A of Principal Act (confidentiality of taxpayer information)
97.    Section 851A(8) of the Principal Act is amended—
           (a) in paragraph (n)—
                (i) in subparagraph (i)(II), by the substitution of “Article 108 or 109” for “Article
                    109”, and
                (ii) in subparagraph (ii)(II), by the substitution of “Article 108 or 109” for “Article
                     109”,
           (b) in paragraph (o), by the substitution of the following subparagraph for
               subparagraph (ii):
                             “(ii) regulations made pursuant to Article 108 or 109 of the Treaty on
                                   the functioning of the European Union,”,
               and
           (c) by the insertion of the following paragraph after paragraph (o):
                        “(oa) where the taxpayer information is required to be disclosed in
                              accordance with regulations made pursuant to Article 108 or 109 of
                              the Treaty on the functioning of the European Union and is
                              disclosed solely for the purposes of or in connection with the
                              compliance by the State with its obligations under such regulations,
                              and”.


Amendment of section 869 of Principal Act (delivery, service and evidence of notices and
forms)
98.    Section 869(1) of the Principal Act is amended by the insertion of the following
       paragraph after paragraph (d):
                          “(e) (i) Without prejudice to paragraphs (b) and (c), a notice under
                                   section 879 may be given to an individual by electronic means
                                   in accordance with subparagraph (ii) through such online
                                   service as may be operated for that purpose by the Revenue
                                   Commissioners.

                                                    145
PT.6 S.98 [No. 18.]                     Finance Act 2025.                                  [2025.]

                            (ii) For the purposes of subparagraph (i), a notice is given to an
                                 individual by electronic means in accordance with this
                                 subparagraph if—
                                (I) it is sent to an email address or other electronic contact
                                    point at which the individual has agreed in writing to receive
                                    the notice, and
                               (II) a record that the email or other electronic message has been
                                    sent is made for the sender by the email system or other
                                    electronic system used.”.


Amendment of section 959AA of Principal Act (chargeable persons: time limit on
assessment made or amended by Revenue officer)
99.   Section 959AA of the Principal Act is amended, in subsection (2A), by the substitution of
      “subsection (1) or (1B), as the case may be, of section 826” for “section 826(1)”.


Amendment of section 959AP of Principal Act (payment of preliminary tax by direct
debit)
100. Section 959AP of the Principal Act is amended—
          (a) in subsection (1)(a), by the deletion of “in accordance with subsection (2)”, and
         (b) by the deletion of subsections (2), (3) and (4).


Amendment of section 959AU of Principal Act (date for payment of tax: amended
assessments)
101. Section 959AU of the Principal Act is amended—
          (a) in subsection (1), by the substitution of “subsection (2) or (3), as the case may
              be,” for “subsection (2)”, and
         (b) by the insertion of the following subsection after subsection (2):
                      “(3) Where—
                         (a) an assessment is amended for a second or subsequent time, and
                         (b) the return, in respect of the chargeable period for which the
                             assessment is amended as referred to in paragraph (a), did not
                             contain a full and true disclosure of all material facts necessary for
                             the making of the assessment,
                          any additional tax due by reason of the second or subsequent
                          amendment of the assessment shall be deemed to have been due and
                          payable on the same day as the tax due under the assessment before
                          any amendment.”.




                                               146
[2025.]                                Finance Act 2025.                            [No. 18.] PT.6

Amendment of section 959I of Principal Act (obligation to make a return)
102. Section 959I of the Principal Act is amended by the insertion of the following subsection
     after subsection (5):
                   “(6) Where a chargeable person as respects a chargeable period prepares
                        and delivers to the Collector-General after the specified return date for
                        the chargeable period a return in the prescribed form, nothing in this
                        Chapter shall operate so as to prevent the chargeable person from
                        making a claim for an allowance, deduction or relief under the Acts in
                        the return, unless a provision of the Acts (other than this subsection)
                        prevents the chargeable person from making a claim for the allowance,
                        deduction or relief where the return is delivered after the specified
                        return date, or the return is delivered later than the date specified by a
                        provision of the Acts (other than this subsection) for making a claim
                        for an allowance, deduction or relief.”.


Residential zoned land tax
103. Part 22A of the Principal Act is amended—

          (a) in sections 653E, 653I, 653J, 653L, 653AE, 653AF, 653AFA and 653AFB, by the
              substitution of “An Coimisiún Pleanála” for “An Bord Pleanála” in each place
              where it occurs,
          (b) in section 653A—
              (i) in subsection (1)—
                  (I) by the insertion of the following definition:
                        “ ‘Act of 2024’ means the Planning and Development Act 2024;”,
                  (II) by the substitution of the following definition for the definition of “local
                       authority consent”:
                        “ ‘local authority consent’ means—
                       (a) a notice—
                           (i) sent in accordance with the procedure outlined in article 84(1)
                               of the Planning and Development Regulations 2001 (S.I. No.
                               600 of 2001) in respect of local authority own development, as
                               prescribed under section 179 of the Act of 2000 and article
                               80(1) of those Regulations,
                          (ii) sent in accordance with the procedure outlined in article 81A of
                               the Planning and Development Regulations 2001 in respect of
                               housing development (within the meaning of section 179A of
                               the Act of 2000),
                          (iii) published in accordance with section 159(6)(a)(iii) of the Act of
                                2024 in respect of local authority development of a class


                                               147
PT.6 S.103 [No. 18.]                 Finance Act 2025.                                   [2025.]

                              prescribed in regulations made under section 153(1) of the Act
                              of 2024, or
                         (iv) published in accordance with regulations made under subsection
                              (2) of section 161 of the Act of 2024 in respect of local
                              authority housing development (within the meaning of that
                              section),
                           to indicate that, as the case may be, the local authority will carry
                           out the proposed development or carry out the proposed
                           development subject to variations or modifications,
                       (b) where paragraph (d) or (e) of section 179(6) of the Act of 2000
                           applies, an approval granted by An Bord Pleanála in accordance
                           with section 175 or 177AE, as the case may be, of that Act, or
                       (c) a permission granted by An Coimisiún Pleanála in accordance with
                           Chapter 4 of Part 4 of the Act of 2024 for Chapter 4 Local
                           Authority Development (within the meaning of that Part of that
                           Act);”,

                 (III) by the substitution of the following definition for the definition of
                       “permission regulations”:
                        “ ‘permission regulations’ means regulations made under—
                       (a) section 33, 37I, 43, 172(2), 174, 177N or 177AD of the Act of
                           2000, or
                       (b) section 183, 225 or 238 of the Act of 2024;”,

                 (IV) by the substitution of the following definition for the definition of
                      “planning permission”:
                        “ ‘planning permission’ means a permission granted under—
                       (a) section 34, 37, 37G, 170 or 177K of the Act of 2000, or
                       (b) section 98, 109, 123, 124, 131 or 594 of the Act of 2024;”,

                  (V) by the substitution of the following definition for the definition of
                      “planning permission period”:
                        “ ‘planning permission period’ means—
                       (a) in relation to a grant of planning permission under the Act of 2000,
                           the appropriate period (within the meaning of section 40 of that
                           Act), including that period as extended in accordance with section
                           42 of that Act (or that section as modified in accordance with
                           section 42B of that Act), and
                       (b) in relation to a grant of planning permission under the Act of 2024,
                           the period specified in subsection (1) of section 177 of that Act or


                                             148
[2025.]                                  Finance Act 2025.                    [No. 18.] PT.6 S.103

                              in accordance with subsection (3) of that section, as the case may
                              be, including that period as extended in accordance with section
                              142 or 143 of that Act;”,
                        and

                 (VI) by the substitution of the following definition for the definition of
                      “vacant or idle land”:
                         “ ‘vacant or idle land’ means land which, having regard only to
                         development (within the meaning of the Act of 2000 or, on and from
                         the commencement of Part 4 of the Act of 2024, within the meaning of
                         the Act of 2024) which is not unauthorised development (within the
                         meaning of the Act of 2000 or, on and from the commencement of Part
                         4 of the Act of 2024, within the meaning of the Act of 2024), is not
                         required for, or integral to, the operation of a trade or profession being
                         carried out on, or adjacent to, the land;”,
                  and
             (ii) by the insertion of the following subsection after subsection (2):
                   “(3) In this Part, a reference to ‘An Coimisiún Pleanála’ shall be construed
                        as including a reference to ‘An Bord Pleanála’.”,
          (c) in section 653B—
              (i) in paragraph (a), by the substitution of “a development plan, in accordance
                  with section 10(2)(a) of the Act of 2000 or section 43(6) of the Act of 2024”
                  for “a development plan, in accordance with section 10(2)(a) of the Act of
                  2000”,
             (ii) in paragraph (i), by the substitution of “within the meaning of the Act of 2000
                  or, on and from the commencement of Part 4 of the Act of 2024, within the
                  meaning of the Act of 2024” for “within the meaning of the Act of 2000” in
                  each place where it occurs, and
             (iii) in paragraph (iia)—
                  (I) in subparagraph (I)—
                     (A) by the substitution of “zoned in a development plan under the Act of
                         2000” for “zoned in a development plan”, and
                     (B) by the substitution of “Act of 2000,” for “Act of 2000, or”,
                  (II) in subparagraph (II), by the substitution of “Act of 2000, or” for “Act of
                       2000,”, and
                 (III) by the insertion of the following subparagraph after subparagraph (II):
                              “(III) in a case in which the land is zoned in a development plan
                                     under the Act of 2024, the order of priority or phasing
                                     (where such order of priority or phasing is based on the


                                               149
PT.6 S.103 [No. 18.]                   Finance Act 2025.                                   [2025.]

                                   timing of the provision of any public infrastructure and
                                   facilities, as referred to in paragraph (b)), if any, for
                                   development indicated in the development plan or an urban
                                   area plan, priority area plan or coordinated area plan (in
                                   each case within the meaning of the Act of 2024) for an area
                                   within which the land is situated.”,

         (d) in section 653C(4), by the substitution of the following paragraph for
             paragraph (f):
                       “(f) where land is included in a development plan in accordance with
                            section 10(2)(a) of the Act of 2000 or section 43(6) of the Act of
                            2024, or a local area plan in accordance with section 19(2)(a) of the
                            Act of 2000, zoned—
                           (i) solely or primarily for residential use, or
                           (ii) for a mixture of uses, including residential use,
                            a statement that a person may, in respect of land that such a person
                            owns, make a submission to the local authority requesting a
                            variation of the zoning of that land.”,

         (e) in section 653I—
              (i) in subsection (1)—
                   (I) in paragraph (c), by the substitution of “section 653M(1),” for
                       “section 653M(1), or”,
                  (II) in paragraph (d), by the substitution of “section 653M(1), or” for
                       “section 653M(1),”, and
                 (III) by the insertion of the following paragraph after paragraph (d):
                       “(e) during the period beginning on 1 February 2026 and ending on
                            1 April 2026, to a local authority on a revised map for the year
                            2026 published in accordance with section 653M(1),”,
              (ii) in subsection (3), by the substitution of “Subsection (3A) of section 13 of the
                   Act of 2000 or, on and from the commencement of subsection (10) of section
                   58 of the Act of 2024, that subsection,” for “Subsection (3A) of section 13 of
                   the Act of 2000”,
             (iii) in subsection (3A)—
                   (I) by the substitution of the following paragraph for paragraph (a):
                       “(a) The local authority concerned shall acknowledge, in writing,
                            receipt of a submission to the person who made the submission—
                           (i) in a case in which the submission is made under subsection (1)
                               (d), not later than 30 April 2025, and
                           (ii) in a case in which the submission is made under subsection(1)

                                               150
[2025.]                                  Finance Act 2025.                      [No. 18.] PT.6 S.103

                                  (e), not later than 30 April 2026.”,
                        and
                  (II) in paragraph (b)(ii)(I), by the substitution of “section 7 of the Act of
                       2000 or section 382 of the Act of 2024” for “section 7 of the Act of
                       2000”,
                  and
             (iv) in subsection (4)—
                  (I) in paragraph (b), by the substitution of “section 13 of the Act of 2000 or
                      section 58 of the Act of 2024” for “section 13 of the Act of 2000”, and
                  (II) by the substitution of the following paragraph for paragraph (c):
                        “(c) notify the owner concerned of its decision to—
                              (i) reject the request for a change to the zoning of lands, or
                              (ii) propose to make a variation to a development plan under
                                   section 13 of the Act of 2000 or section 58 of the Act of 2024,
                               as follows:
                              (I) in a case in which a submission is made under subsection (1)(c),
                                  not later than July 2024;
                              (II) in a case in which a submission is made under subsection (1)(d),
                                   not later than 30 June 2025;
                          (III) in a case in which a submission is made under subsection (1)(e),
                                not later than 30 June 2026.”,
          (f) in section 653IA—
              (i) in subsection (1)(a), by the substitution of “under paragraph (d) or (e) of
                  subsection (1)” for “under subsection (1)(d)”,
             (ii) by the substitution of the following subsection for subsection (2):
                   “(2) Where subsection (1) applies to a relevant site, notwithstanding
                        section 653Q, on the making of a claim by a liable person under this
                        Part in relation to the relevant site, residential zoned land tax shall not
                        be charged and levied in respect of that site—
                         (a) in a case in which the submission concerned is made under
                             paragraph (d) of section 653I(1), on 1 February 2025, and
                        (b) in a case in which the submission concerned is made under
                            paragraph (e) of section 653I(1), on 1 February 2026.”,
            (iii) in subsection (3)(a), by the substitution of “under paragraph (d) or (e) of
                  subsection (1)” for “under subsection (1)(d)”, and
             (iv) by the substitution of the following subsection for subsection (5):


                                                 151
PT.6 S.103 [No. 18.]                   Finance Act 2025.                                   [2025.]

                   “(5) Where subsection (3) applies to a relevant site, notwithstanding
                        section 653Q, on the making of a claim by a liable person under this
                        Part in relation to the relevant site, residential zoned land tax shall not
                        be charged and levied in respect of the eligible part of the relevant
                        site—
                        (a) in a case in which the submission concerned is made under
                            paragraph (d) of section 653I(1), on 1 February 2025, and
                        (b) in a case in which the submission concerned is made under
                            paragraph (e) of section 653I(1), on 1 February 2026.”,
         (g) in section 653K—
              (i) in paragraph (d)—
                   (I) in subparagraph (i), by the substitution of “under section 11 of the Act of
                       2000 or section 42 of the Act of 2024” for “under section 11 of the Act
                       of 2000”, and
                  (II) in subparagraph (ii), by the substitution of “under section 13 of the Act
                       of 2000 or section 58 of the Act of 2024” for “under section 13 of the
                       Act of 2000”,
              (ii) in paragraph (e)—
                   (I) in subparagraph (i), by the substitution of “pursuant to section 34(12C)
                       of the Act of 2000 or Chapter 3 of Part 4 of the Act of 2024” for
                       “pursuant to section 34(12C) of the Act of 2000”, and
                  (II) by the substitution of the following subparagraph for subparagraph (ii):
                         “(ii) for substitute consent, in accordance with section 177E of the
                               Act of 2000, or retrospective consent, in accordance with
                               Chapter 4 of Part 4 of the Act of 2024,”,
                  and
             (iii) in paragraph (f), by the substitution of “within the meaning of the Act of 2024”
                   for “within the meaning of the Act of 2000”,
         (h) in section 653AE, by the substitution of “section 13 of the Act of 2000 or section
             58 of the Act of 2024” for “section 13 of the Act of 2000” in each place where it
             occurs,
          (i) in section 653AF—
              (i) by the insertion of the following subsection after subsection (2):
                 “(2A) Where this section applies, on the making of a claim by a liable
                       person, any residential zoned land tax that arises in respect of a
                       liability date between—
                        (a) the date on which the planning permission referred to in subsection
                            (2) is granted, and


                                               152
[2025.]                                 Finance Act 2025.                     [No. 18.] PT.6 S.103

                         (b) the date on which the relevant appeal or relevant petition, as the
                             case may be, is determined,
                          shall not be due and payable.”,
                  and
             (ii) by the deletion of subsections (3), (4) and (5),
          (j) in section 653AFA(1)—
              (i) in paragraph (a), by the substitution of “pursuant to section 34(12C) of the Act
                  of 2000 or Chapter 3 of Part 4 of the Act of 2024” for “pursuant to section
                  34(12C) of the Act of 2000”,
             (ii) by the substitution of the following paragraph for paragraph (b):
                        “(b) an application for substitute consent, in accordance with section
                             177E of the Act of 2000, or retrospective consent, in accordance
                             with Chapter 4 of Part 4 of the Act of 2024,”,
                  and
             (iii) by the substitution of “(within the meaning of the Act of 2000 or, on and from
                   the commencement of Part 4 of the Act of 2024, within the meaning of the Act
                   of 2024)” for “(within the meaning of the Act of 2000)”,
          (k) in section 653AFB—
              (i) in subsection (2), by the substitution of “(within the meaning of the Act of
                  2000 or, on and from the commencement of Part 4 of the Act of 2024, within
                  the meaning of the Act of 2024)” for “(within the meaning of the Act of
                  2000)”, and
             (ii) in subsection (11)—
                  (I) in paragraph (a), by the substitution of “pursuant to section 34(12C) of
                      the Act of 2000 or Chapter 3 of Part 4 of the Act of 2024” for “pursuant
                      to section 34(12C) of the Act of 2000”, and
                  (II) by the substitution of the following paragraph for paragraph (b):
                        “(b) an application for substitute consent, in accordance with section
                             177E of the Act of 2000, or retrospective consent, in accordance
                             with Chapter 4 of Part 4 of the Act of 2024,”,
          (l) in section 653AG—
              (i) in subsection (1)(a), by the substitution of “in accordance with section 10(2)(a)
                  of the Act of 2000 or section 43(6) of the Act of 2024,” for “in accordance
                  with section 10(2)(a) of the Act of 2000,”, and
             (ii) by the substitution of the following subsection for subsection (7):
                  “(7) (a) An owner of a relevant site to which this section applies shall make
                           a declaration to the Revenue Commissioners, in such form and


                                               153
PT.6 S.103 [No. 18.]                    Finance Act 2025.                                   [2025.]

                            containing such information as they may prescribe, that this section
                            applies to the relevant site—
                            (i) in a case in which a commencement notice is lodged subsequent
                                to the site becoming a relevant site, within 30 days of the date
                                on which the commencement notice, or the first such notice, as
                                the case may be, referred to in subsection (2) is lodged, or
                           (ii) in all other cases, within 30 days of the site becoming a relevant
                                site.
                        (b) The owner of a relevant site to which this section applies shall
                            maintain and have available such records as may reasonably be
                            required for the purposes of determining whether the requirements
                            of this section are met.”,
         (m) in section 653AGA—
              (i) in subsection (3)—
                   (I) by the substitution of “Subject to subsections (3A), (4), (5) and (6),” for
                       “Subject to subsections (4), (5) and (6),”,
                  (II) in paragraph (b), by the substitution of “part thereof.” for “part thereof,”,
                       and
                 (III) by the deletion of “and residential zoned land tax so deferred shall be
                       referred to in this section as ‘pre-development deferred residential zoned
                       land tax’.”,
              (ii) by the insertion of the following subsections after subsection (3):

                 “(3A) Where pre-development deferred residential zoned land tax would, but
                       for this subsection, become due and payable in accordance with
                       subsection (3)(a) on a date which occurs prior to the return date
                       relating to the liability date referred to in subsection (3), such
                       pre-development deferred residential zoned land tax shall be due and
                       payable on or before the return date.

                   (3B) Residential zoned land tax deferred in accordance with subsection (3)
                        or (3A) shall be referred to in this section as ‘pre-development
                        deferred residential zoned land tax’.”,
             (iii) in paragraph (d) of subsection (4), by the substitution of “in accordance with
                   subsection (3), (3A) or (6)” for “in accordance with subsection (3) or (6)”,
             (iv) in subsection (6)—
                   (I) in paragraph (a), by the substitution of “in accordance with subsection
                       (3) or (3A)” for “in accordance with subsection (3)”, and
                  (II) in paragraph (b), by the substitution of “subsections (3) and (3A) shall
                       continue to apply” for “subsection (3) shall continue to apply”,


                                               154
[2025.]                                 Finance Act 2025.                      [No. 18.] PT.6 S.103

              (v) in subsection (7), by the substitution of “in accordance with subsection (3),
                  (3A) or (6)” for “in accordance with subsection (3) or (6)”, and
             (vi) in subsection (8), by the substitution of “notwithstanding subsections (3) and
                  (3A)” for “notwithstanding subsection (3)”,


          (n) in section 653AH(3)(a), by the substitution of “within the meaning of the Act of
              2024” for “within the meaning of the Act of 2000”, and


          (o) in section 653AI—
              (i) in subsection (5), by the substitution of “Notwithstanding sections 653Q and
                  653Z, and subject to subsections (5A), (6) and (7),” for “Notwithstanding
                  section 653Q, and subject to subsections (6) and (7),”,
              (ii) by the insertion of the following subsection after subsection (5):
                 “(5A) Subject to subsection (6), where the return date in respect of a liability
                       date referred to in subsection (5) occurs after the earlier of the dates
                       specified in paragraphs (a) and (b) of subsection (5), residential zoned
                       land tax arising in respect of that liability date shall be payable on or
                       before the return date in the year in respect of which the tax is
                       charged.”,
             (iii) in subsection (7), by the substitution of “section 653T” for “section 653U”,
             (iv) by the substitution of the following subsection for subsection (10):
                  “(10) Where, on the date of death of a deceased person, section 653AF
                        applies to a relevant site in respect of which the deceased person was
                        the liable person immediately prior to their death, the personal
                        representatives may, during the administration period, make a claim
                        under section 653AF(2A) that the deceased person would have been
                        entitled to make.”,
              (v) in subsection (12)—
                   (I) by the substitution of “653AF(2A)” for “653AF(4) and (5)”, and
                  (II) by the substitution of “section 653AF(2A)” for “653AF(4) or (5)”,
                  and
             (vi) in subsection (13) by the deletion of “653AF(4)(a)”.

Technical amendments to de minimis aid provisions
104. (1) The Principal Act is amended—
          (a) in section 216F(7), by the deletion of paragraphs (b) and (d), and
          (b) in section 667C(1), by the substitution of the following definition for the
              definition of “Commission Regulation (EU) No. 1408/2013”:



                                               155
PT.6 S.104 [No. 18.]                        Finance Act 2025.                                   [2025.]

                                “ ‘Commission Regulation (EU) No. 1408/2013’ means Commission
                                Regulation (EU) No. 1408/2013 of 18 December 201360 as amended
                                by Commission Regulation (EU) 2019/316 of 21 February 201961,
                                Commission Regulation (EU) 2022/2046 of 24 October 202262,
                                Commission Regulation (EU) 2023/2391 of 4 October 202363 and
                                Commission Regulation (EU) 2024/3118 of 10 December 202464;”.
       (2) Section 81D(1) of the Stamp Duties Consolidation Act 1999 is amended by the
           substitution of the following definition for the definition of “Commission Regulation
           (EU) No. 1408/2013”:
                                “ ‘Commission Regulation (EU) No. 1408/2013’ means Commission
                                Regulation (EU) No. 1408/2013 of 18 December 201365 as amended
                                by Commission Regulation (EU) 2019/316 of 21 February 201966,
                                Commission Regulation (EU) 2022/2046 of 24 October 202267,
                                Commission Regulation (EU) 2023/2391 of 4 October 202368 and
                                Commission Regulation (EU) 2024/3118 of 10 December 202469;”.


Miscellaneous technical amendments in relation to tax
105. The enactments specified in the Schedule—
             (a) are amended to the extent and in the manner specified in paragraphs 1 to 5 of
                 that Schedule, and
             (b) apply and come into operation in accordance with paragraph 6 of that Schedule.


Care and management of taxes and duties
106. All taxes and duties imposed by this Act are placed under the care and management of
     the Revenue Commissioners.

Short title, construction and commencement
107. (1) This Act may be cited as the Finance Act 2025.
       (2) Part 1 shall be construed together with—
             (a) in so far as it relates to income tax, the Income Tax Acts,
             (b) in so far as it relates to universal social charge, Part 18D of the Principal Act,
             (c) in so far as it relates to corporation tax, the Corporation Tax Acts, and
             (d) in so far as it relates to capital gains tax, the Capital Gains Tax Acts.


60   OJ No. L352, 24.12.2013, p.9
61   OJ No. L51 I, 22.2.2019, p.1
62   OJ No. L275, 25.10.2022, p.55
63   OJ L2023/2391, 5.10.2023
64   OJ L2024/3118, 13.12.2024
65   OJ No. L352, 24.12.2013, p.9
66   OJ No. L51 I, 22.2.2019, p.1
67   OJ No. L275, 25.10.2022, p.55
68   OJ L2023/2391, 5.10.2023
69   OJ L2024/3118, 13.12.2024


                                                   156
[2025.]                                Finance Act 2025.                     [No. 18.] PT.6 S.107

     (3) Part 2, in so far as it relates to duties of excise, shall be construed together with the
         statutes which relate to those duties and to the management of those duties.
     (4) Part 3 shall be construed together with the Value-Added Tax Acts.
     (5) Part 4 shall be construed together with the Stamp Duties Consolidation Act 1999 and
         the enactments amending or extending that Act.
     (6) Part 5 shall be construed together with the Capital Acquisitions Tax Consolidation
         Act 2003 and the enactments amending or extending that Act.
     (7) Part 6 in so far as it relates to—
          (a) income tax, shall be construed together with the Income Tax Acts,
          (b) residential zoned land tax, shall be construed together with Part 22A of the
              Principal Act,
          (c) corporation tax, shall be construed together with the Corporation Tax Acts,
          (d) capital gains tax, shall be construed together with the Capital Gains Tax Acts,
          (e) duties of excise, shall be construed together with the statutes which relate to
              duties of excise and the management of those duties,
          (f) value-added tax, shall be construed together with the Value-Added Tax Acts,
          (g) stamp duty, shall be construed together with the Stamp Duties Consolidation Act
              1999 and the enactments amending or extending that Act, and
          (h) gift tax or inheritance tax, shall be construed together with the Capital
              Acquisitions Tax Consolidation Act 2003 and the enactments amending or
              extending that Act.
     (8) Except where otherwise expressly provided for in Part 1, that Part shall come into
         operation on 1 January 2026.
     (9) Except where otherwise expressly provided for, where a provision of this Act is to
         come into operation on the making of an order by the Minister for Finance, that
         provision shall come into operation on such day or days as the Minister for Finance
         shall appoint either generally or with reference to any particular purpose or provision
         and different days may be so appointed for different purposes or different provisions.




                                              157
[No. 18.]                                    Finance Act 2025.                               [2025.]

                                               SCHEDULE
                                                                                         Section 105
                          MISCELLANEOUS TECHNICAL AMENDMENTS IN RELATION TO TAX
        1. The Taxes Consolidation Act 1997 is amended—
                  (a) in section 208(4)(a)
                        (i) by the substitution of “paragraphs (a) and (b) of subsection (2)” for
                            “paragraphs (a) and (b) of subsection (1)”,
                       (ii) in subparagraph (i), by the substitution of “subsection (2)(a),” for
                            “subsection (1)(a),”, and
                      (iii) in subparagraph (ii), by the substitution of “subsection (2)(b)” for
                            “subsection (1)(b)”,
                  (b) in section 216A(8), by the substitution of “section 473C” for “section 244”,
                  (c) in section 1024(2)(a), by the deletion of subparagraph (xa), and
                  (d) in section 1031I(2)(a), by the deletion of subparagraph (xi).
        2. The Capital Acquisitions Tax Consolidation Act 2003 is amended, in paragraph 7(1)
           of Part 1 of Schedule 2, in the definition of “relevant period”—
                  (a) by the substitution of “subparagraph (2)(i)” for “subparagraph (2)(a)”, and
                  (b) by the substitution of “subparagraph (2)(ii)” for “subparagraph (2)(b)”.
        3. The Finance Act 1999 is amended—
                  (a) in section 94(1), by the substitution of the following definition for the
                      definition of “greenhouse gas emissions permit”:
                       “ ‘greenhouse gas emissions permit’ means a permit granted under
                       Regulation 7 of the European Communities (Greenhouse Gas Emissions
                       Trading) Regulations 2024 (S.I. No. 470 of 2024);”,
                       and
                  (b) in section 104(1A), by the substitution of “Commission Implementing
                      Decision (EU) 2022/197 of 17 January 202270” for “Commission Decision
                      No. 2001/574/EC of 13 July 200171”.
        4. The Finance Act 2010 is amended—
                  (a) in section 66(1), by the substitution of the following definition for the
                      definition of “greenhouse gas emissions permit”:
                       “ ‘greenhouse gas emissions permit’ means a permit granted under
                       Regulation 7 of the European Communities (Greenhouse Gas Emissions
                       Trading) Regulations 2024 (S.I. No. 470 of 2024);”,
                       and

70 OJ No. L31, 14.2.2022, p. 52.
71 OJ No. L203, 28.7.2001, p. 20.


                                                   158
[2025.]                                Finance Act 2025.                            [No. 18.] SCH.

              (b) in section 77, by the substitution of the following definition for the definition
                  of “greenhouse gas emissions permit”:
                  “ ‘greenhouse gas emissions permit’ means a permit granted under
                  Regulation 7 of the European Communities (Greenhouse Gas Emissions
                  Trading) Regulations 2024 (S.I. No. 470 of 2024);”.
      5. The Value-Added Tax Consolidation Act 2010 is amended, in paragraph 16(2) of Part
         4 of Schedule 3, by the substitution of “Irish Standard I.S. EN 771-3: 2011+A1:2015
         Specification for masonry units – Part 3: Aggregate concrete masonry units (dense
         and lightweight aggregates)” for “Irish Standard I.S. EN 771-3: 2011 Specification for
         masonry units – Part 3: Aggregate concrete masonry units (dense and lightweight
         aggregates)”.
      6. This Schedule shall have effect on and from the date of the passing of this Act.




                                               159
